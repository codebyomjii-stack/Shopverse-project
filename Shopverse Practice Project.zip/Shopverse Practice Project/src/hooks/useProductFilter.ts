import { useMemo } from "react";
import { Product, Category } from "../types";

interface FilterParams {
  products: Product[];
  searchQuery: string;
  selectedCategory?: Category;
}

export function useProductFilter({
  products,
  searchQuery,
  selectedCategory,
}: FilterParams) {
  return useMemo(() => {
    let result = products;

    if (selectedCategory && selectedCategory !== "All") {
      result = result.filter((p) => p.category === selectedCategory);
    }

    if (searchQuery) {
      result = result.filter((p) =>
        p.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    return result;
  }, [products, searchQuery, selectedCategory]);
}

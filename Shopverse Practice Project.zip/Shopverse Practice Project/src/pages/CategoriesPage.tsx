import React from "react";
import { Link } from "react-router-dom";
import {
  FiShoppingBag,
  FiUsers,
  FiStar,
  FiClock,
  FiCheckCircle,
  FiArrowRight,
} from "react-icons/fi";
import { MdOutlineLocalShipping, MdOutlineVerified } from "react-icons/md";
import { RiSparklingFill } from "react-icons/ri";

const categories = [
  {
    name: "Electronics",
    description: "Smartphones, laptops, gadgets & premium accessories",
    icon: "📱",
    color: "from-blue-500 to-indigo-500",
    bg: "bg-gradient-to-br from-blue-50 to-indigo-50",
    border: "border-blue-100",
    iconBg: "bg-gradient-to-br from-blue-500 to-indigo-500",
  },
  {
    name: "Fashion",
    description: "Premium clothing, footwear & luxury accessories",
    icon: "👗",
    color: "from-pink-500 to-rose-500",
    bg: "bg-gradient-to-br from-pink-50 to-rose-50",
    border: "border-pink-100",
    iconBg: "bg-gradient-to-br from-pink-500 to-rose-500",
  },
  {
    name: "Home",
    description: "Modern furniture, decor & essential home items",
    icon: "🏠",
    color: "from-emerald-500 to-teal-500",
    bg: "bg-gradient-to-br from-emerald-50 to-teal-50",
    border: "border-emerald-100",
    iconBg: "bg-gradient-to-br from-emerald-500 to-teal-500",
  },
  {
    name: "Sports",
    description: "Fitness equipment, outdoor gear & sports accessories",
    icon: "🏀",
    color: "from-orange-500 to-amber-500",
    bg: "bg-gradient-to-br from-orange-50 to-amber-50",
    border: "border-orange-100",
    iconBg: "bg-gradient-to-br from-orange-500 to-amber-500",
  },
  {
    name: "Beauty",
    description: "Skincare, premium makeup & wellness products",
    icon: "💄",
    color: "from-purple-500 to-fuchsia-500",
    bg: "bg-gradient-to-br from-purple-50 to-fuchsia-50",
    border: "border-purple-100",
    iconBg: "bg-gradient-to-br from-purple-500 to-fuchsia-500",
  },
];

const CategoriesPage: React.FC = () => {
  return (
    <div className="bg-gradient-to-b from-gray-50 to-white min-h-screen">
      {/* Enhanced Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 text-white">
        {/* Advanced Background Effects */}
        <div className="absolute inset-0">
          <div className="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-blue-500/30 to-blue-400/20 rounded-full blur-3xl animate-pulse"></div>
          <div
            className="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-br from-pink-500/30 to-pink-400/20 rounded-full blur-3xl animate-pulse"
            style={{ animationDelay: "1s" }}
          ></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-gradient-to-r from-blue-600/10 via-purple-600/10 to-pink-600/10 blur-3xl rounded-full"></div>

          {/* Floating Elements */}
          <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-white/40 rounded-full animate-bounce"></div>
          <div
            className="absolute top-1/3 right-1/3 w-3 h-3 bg-white/30 rounded-full animate-bounce"
            style={{ animationDelay: "0.5s" }}
          ></div>
          <div
            className="absolute bottom-1/4 left-1/3 w-2 h-2 bg-white/40 rounded-full animate-bounce"
            style={{ animationDelay: "1s" }}
          ></div>
          <div
            className="absolute top-1/2 right-1/4 w-3 h-3 bg-white/30 rounded-full animate-bounce"
            style={{ animationDelay: "1.5s" }}
          ></div>
        </div>

        {/* Shiny Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-white/10 via-transparent to-white/10"></div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-28 lg:py-36 text-center">
          {/* Premium Badge */}
          <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-gradient-to-r from-white/20 to-white/10 backdrop-blur-md border border-white/30 mb-10 animate-slideInUp">
            <RiSparklingFill className="w-4 h-4 text-yellow-300 animate-pulse" />
            <span className="text-sm font-bold text-white/95 tracking-wider">
              PREMIUM CATEGORIES
            </span>
            <div className="w-2 h-2 bg-gradient-to-r from-yellow-300 to-yellow-400 rounded-full"></div>
          </div>

          {/* Enhanced Title */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 leading-tight tracking-tight animate-slideInUp">
            <span className="relative">
              Discover Premium
              <span className="absolute -top-2 -right-6">
                <FiStar className="w-6 h-6 text-yellow-300 animate-spin-slow" />
              </span>
            </span>
            <br />
            <span className="bg-gradient-to-r from-white via-blue-100 to-purple-100 bg-clip-text text-transparent">
              Collections
            </span>
          </h1>

          {/* Enhanced Description */}
          <p
            className="text-base sm:text-lg lg:text-xl text-white/90 max-w-3xl mx-auto leading-relaxed mb-12 animate-slideInUp"
            style={{ animationDelay: "0.1s" }}
          >
            Explore our meticulously curated categories featuring products that
            blend
            <span className="font-semibold text-white">
              {" "}
              exceptional craftsmanship{" "}
            </span>
            with
            <span className="font-semibold text-white"> innovative design</span>
            . Each category is handpicked for quality and excellence.
          </p>

          {/* Trust Indicators */}
          <div
            className="flex flex-wrap items-center justify-center gap-6 mb-10 animate-slideInUp"
            style={{ animationDelay: "0.2s" }}
          >
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20">
              <MdOutlineVerified className="w-4 h-4 text-green-300" />
              <span className="text-xs font-medium text-white/90">
                Quality Guaranteed
              </span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20">
              <MdOutlineLocalShipping className="w-4 h-4 text-blue-300" />
              <span className="text-xs font-medium text-white/90">
                Fast Shipping
              </span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20">
              <FiCheckCircle className="w-4 h-4 text-purple-300" />
              <span className="text-xs font-medium text-white/90">
                Secure Checkout
              </span>
            </div>
          </div>
        </div>

        {/* Bottom Wave Transition */}
        <div className="absolute -bottom-1 left-0 right-0">
          <svg
            className="w-full h-12 sm:h-16"
            viewBox="0 0 1200 120"
            preserveAspectRatio="none"
          >
            <path
              fill="rgb(249 250 251)"
              d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z"
              opacity=".25"
            ></path>
            <path
              fill="rgb(249 250 251)"
              d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z"
              opacity=".5"
            ></path>
            <path
              fill="rgb(249 250 251)"
              d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z"
            ></path>
          </svg>
        </div>
      </div>

      {/* Enhanced Stats Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 -mt-2">
        <div className="bg-gradient-to-r from-white to-gray-50 rounded-2xl border border-gray-200 p-6 sm:p-8 shadow-lg">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 sm:gap-6">
            {[
              {
                number: "5",
                label: "Premium Categories",
                icon: <FiShoppingBag className="w-6 h-6" />,
              },
              {
                number: "5K+",
                label: "Quality Products",
                icon: <FiStar className="w-6 h-6" />,
              },
              {
                number: "100K+",
                label: "Happy Customers",
                icon: <FiUsers className="w-6 h-6" />,
              },
              {
                number: "99%",
                label: "Satisfaction Rate",
                icon: <MdOutlineVerified className="w-6 h-6" />,
              },
              {
                number: "24/7",
                label: "Support",
                icon: <FiClock className="w-6 h-6" />,
              },
            ].map((stat, idx) => (
              <div key={idx} className="text-center group">
                <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-50 to-purple-50 mb-4 group-hover:scale-110 transition-transform duration-300 mx-auto">
                  <div className="text-gradient-to-r from-blue-500 to-purple-500">
                    {stat.icon}
                  </div>
                </div>
                <p className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
                  {stat.number}
                </p>
                <p className="text-sm text-gray-600 font-medium group-hover:text-gray-900 transition-colors duration-300">
                  {stat.label}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Enhanced Categories Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="w-1.5 h-10 bg-gradient-to-b from-blue-500 to-purple-500 rounded-full"></div>
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900">
              Browse Our Collections
            </h2>
            <div className="w-1.5 h-10 bg-gradient-to-b from-purple-500 to-pink-500 rounded-full"></div>
          </div>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            Each category features handpicked items designed for quality and
            performance
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {categories.map((category, idx) => (
            <Link
              key={category.name}
              to={`/products?category=${category.name}`}
              className="group relative overflow-hidden bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-gray-200"
              style={{ animationDelay: `${idx * 100}ms` }}
            >
              {/* Glow Effect on Hover */}
              <div
                className="absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-10 transition-opacity duration-500 z-0"
                style={{
                  background: `linear-gradient(135deg, ${category.color
                    .replace("from-", "")
                    .replace("to-", "")
                    .split(" ")
                    .map((c) => `var(--tw-gradient-${c})`)
                    .join(", ")})`,
                }}
              ></div>

              {/* Category Header with Gradient */}
              <div
                className={`relative h-48 bg-gradient-to-br ${category.color} flex items-center justify-center overflow-hidden`}
              >
                {/* Animated Background Pattern */}
                <div className="absolute inset-0 opacity-10">
                  <div className="absolute top-4 left-4 w-20 h-20 border-2 border-white rounded-full"></div>
                  <div className="absolute bottom-4 right-4 w-16 h-16 border-2 border-white rounded-full"></div>
                </div>

                {/* Icon Container */}
                <div className="relative z-10">
                  <div className="w-24 h-24 rounded-2xl bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-500">
                    <span className="text-4xl">{category.icon}</span>
                  </div>
                </div>

                {/* Category Name Overlay */}
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/40 to-transparent p-6">
                  <h3 className="text-2xl font-bold text-white">
                    {category.name}
                  </h3>
                </div>
              </div>

              {/* Content Section */}
              <div className="relative p-6 z-10">
                <p className="text-gray-600 mb-6 leading-relaxed">
                  {category.description}
                </p>

                {/* Features List */}
                <div className="space-y-2 mb-6">
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <div
                      className={`w-2 h-2 rounded-full bg-gradient-to-r ${category.color}`}
                    ></div>
                    <span>Premium quality products</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <div
                      className={`w-2 h-2 rounded-full bg-gradient-to-r ${category.color}`}
                    ></div>
                    <span>Fast shipping available</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <div
                      className={`w-2 h-2 rounded-full bg-gradient-to-r ${category.color}`}
                    ></div>
                    <span>24/7 customer support</span>
                  </div>
                </div>

                {/* CTA Button */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-blue-600 font-semibold group-hover:gap-3 transition-all duration-300">
                    <span>Explore Collection</span>
                    <FiArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" />
                  </div>
                  <div className="text-xs px-3 py-1 rounded-full bg-gradient-to-r from-gray-100 to-gray-50 border border-gray-200 font-medium text-gray-600">
                    500+ items
                  </div>
                </div>

                {/* Animated Bottom Bar */}
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-gray-200 to-gray-300 overflow-hidden">
                  <div
                    className={`absolute inset-0 bg-gradient-to-r ${category.color} transform -translate-x-full group-hover:translate-x-0 transition-transform duration-700`}
                  ></div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Enhanced Bottom CTA Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20">
        <div className="relative overflow-hidden bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 rounded-3xl p-8 sm:p-12 lg:p-16 text-center text-white">
          {/* Background Effects */}
          <div className="absolute inset-0">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
          </div>

          <div className="relative z-10">
            <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/20 backdrop-blur-sm border border-white/30 mb-8">
              <RiSparklingFill className="w-4 h-4 text-yellow-300 animate-pulse" />
              <span className="text-sm font-bold text-white/95">
                LIMITED TIME OFFER
              </span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6 leading-tight">
              Ready to Experience
              <br />
              <span className="bg-gradient-to-r from-cyan-300 via-blue-300 to-purple-300 bg-clip-text text-transparent">
                Premium Shopping?
              </span>
            </h2>

            <p className="text-lg sm:text-xl text-blue-100 mb-10 max-w-2xl mx-auto leading-relaxed">
              Browse our complete product collection and find exactly what
              you're looking for. Enjoy fast shipping, secure checkout, and 24/7
              premium support.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/products"
                className="group relative px-8 py-4 bg-white text-blue-600 font-bold rounded-xl hover:shadow-2xl hover:shadow-white/20 transition-all duration-300 hover:scale-105 active:scale-95"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-white to-white/80 rounded-xl opacity-0 group-hover:opacity-30 blur-xl transition-opacity duration-500"></div>
                <div className="relative flex items-center justify-center gap-3">
                  <FiShoppingBag className="w-5 h-5" />
                  <span>Shop All Products</span>
                </div>
              </Link>

              <Link
                to="/"
                className="px-8 py-4 bg-transparent border-2 border-white text-white font-bold rounded-xl hover:bg-white/10 transition-all duration-300 hover:scale-105 active:scale-95"
              >
                <div className="flex items-center justify-center gap-3">
                  <span>Back to Home</span>
                  <FiArrowRight className="w-5 h-5" />
                </div>
              </Link>
            </div>

            {/* Trust Badges */}
            <div className="flex flex-wrap items-center justify-center gap-6 mt-10 pt-10 border-t border-white/20">
              <div className="flex items-center gap-2">
                <MdOutlineVerified className="w-5 h-5 text-green-300" />
                <span className="text-sm">Secure Payment</span>
              </div>
              <div className="flex items-center gap-2">
                <MdOutlineLocalShipping className="w-5 h-5 text-blue-300" />
                <span className="text-sm">Fast Delivery</span>
              </div>
              <div className="flex items-center gap-2">
                <FiCheckCircle className="w-5 h-5 text-purple-300" />
                <span className="text-sm">Quality Guarantee</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CategoriesPage;

import React, { useState } from "react";
import {
  MapPin,
  Phone,
  Mail,
  Send,
  Clock,
  MessageSquare,
  Headphones,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Zap,
} from "lucide-react";
import { RiSparklingFill } from "react-icons/ri";
import { FiCheckCircle, FiClock } from "react-icons/fi";

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setFormData({ name: "", email: "", message: "" });
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <div className="bg-gradient-to-b from-gray-50 to-white min-h-screen">
      {/* Enhanced Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 text-white">
        {/* Advanced Background Effects */}
        <div className="absolute inset-0">
          <div className="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-blue-500/30 to-blue-400/20 rounded-full blur-3xl animate-pulse"></div>
          <div
            className="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-br from-pink-500/30 to-pink-400/20 rounded-full blur-3xl animate-pulse"
            style={{ animationDelay: "1s" }}
          ></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-gradient-to-r from-blue-600/10 via-purple-600/10 to-pink-600/10 blur-3xl rounded-full"></div>

          {/* Floating Particles */}
          <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-white/40 rounded-full animate-bounce"></div>
          <div
            className="absolute top-1/3 right-1/3 w-3 h-3 bg-white/30 rounded-full animate-bounce"
            style={{ animationDelay: "0.5s" }}
          ></div>
          <div
            className="absolute bottom-1/4 left-1/3 w-2 h-2 bg-white/40 rounded-full animate-bounce"
            style={{ animationDelay: "1s" }}
          ></div>
          <div
            className="absolute top-1/2 right-1/4 w-3 h-3 bg-white/30 rounded-full animate-bounce"
            style={{ animationDelay: "1.5s" }}
          ></div>
        </div>

        {/* Shiny Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-white/10 via-transparent to-white/10"></div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-28 lg:py-36 text-center">
          {/* Premium Badge */}
          <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-gradient-to-r from-white/20 to-white/10 backdrop-blur-md border border-white/30 mb-10 animate-slideInUp">
            <RiSparklingFill className="w-4 h-4 text-yellow-300 animate-pulse" />
            <span className="text-sm font-bold text-white/95 tracking-wider">
              CONTACT US
            </span>
            <div className="w-2 h-2 bg-gradient-to-r from-yellow-300 to-yellow-400 rounded-full"></div>
          </div>

          {/* Enhanced Title */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 leading-tight tracking-tight animate-slideInUp">
            <span className="relative">
              Let's Connect
              <span className="absolute -top-2 -right-6">
                <MessageSquare className="w-6 h-6 text-yellow-300 animate-spin-slow" />
              </span>
            </span>
            <br />
            <span className="bg-gradient-to-r from-white via-blue-100 to-purple-100 bg-clip-text text-transparent">
              And Collaborate
            </span>
          </h1>

          {/* Enhanced Description */}
          <p
            className="text-base sm:text-lg lg:text-xl text-white/90 max-w-3xl mx-auto leading-relaxed mb-12 animate-slideInUp"
            style={{ animationDelay: "0.1s" }}
          >
            Have questions or need support? Our dedicated team is here to help
            you
            <span className="font-semibold text-white"> 24/7</span>. Reach out
            anytime for personalized assistance.
          </p>

          {/* Trust Indicators */}
          <div
            className="flex flex-wrap items-center justify-center gap-6 mb-10 animate-slideInUp"
            style={{ animationDelay: "0.2s" }}
          >
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20">
              <Clock className="w-4 h-4 text-green-300" />
              <span className="text-xs font-medium text-white/90">
                24/7 Support
              </span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20">
              <ShieldCheck className="w-4 h-4 text-blue-300" />
              <span className="text-xs font-medium text-white/90">
                Secure Communication
              </span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20">
              <Zap className="w-4 h-4 text-purple-300" />
              <span className="text-xs font-medium text-white/90">
                Quick Response
              </span>
            </div>
          </div>
        </div>

        {/* Bottom Wave Transition */}
        <div className="absolute -bottom-1 left-0 right-0">
          <svg
            className="w-full h-12 sm:h-16"
            viewBox="0 0 1200 120"
            preserveAspectRatio="none"
          >
            <path
              fill="rgb(249 250 251)"
              d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z"
              opacity=".25"
            ></path>
            <path
              fill="rgb(249 250 251)"
              d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z"
              opacity=".5"
            ></path>
            <path
              fill="rgb(249 250 251)"
              d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z"
            ></path>
          </svg>
        </div>
      </section>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-24 -mt-2">
        {/* Enhanced Contact Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 mb-16">
          {[
            {
              icon: MapPin,
              title: "Location",
              info: "New Delhi, India",
              description: "Corporate Headquarters",
              gradient: "from-blue-500 to-cyan-500",
              bg: "from-blue-50 to-cyan-50",
              border: "border-blue-100",
            },
            {
              icon: Mail,
              title: "Email",
              info: "support@shopverse.com",
              description: "24/7 Email Support",
              gradient: "from-purple-500 to-pink-500",
              bg: "from-purple-50 to-pink-50",
              border: "border-purple-100",
            },
            {
              icon: Phone,
              title: "Phone",
              info: "+91 98765 43210",
              description: "Mon-Sun, 9AM-9PM",
              gradient: "from-pink-500 to-rose-500",
              bg: "from-pink-50 to-rose-50",
              border: "border-pink-100",
            },
          ].map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="group relative bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-gray-200"
              >
                {/* Background Glow */}
                <div
                  className={`absolute inset-0 bg-gradient-to-br ${item.bg} rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10`}
                ></div>

                <div className="relative z-10">
                  <div
                    className={`inline-block bg-gradient-to-r ${item.gradient} p-4 rounded-2xl mb-6 text-white group-hover:scale-110 transition-transform duration-500 shadow-lg`}
                  >
                    <Icon size={28} />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    {item.title}
                  </h3>
                  <p className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent mb-3">
                    {item.info}
                  </p>
                  <p className="text-gray-600 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                {/* Animated Bottom Bar */}
                <div
                  className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${item.gradient} rounded-b-2xl transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500`}
                ></div>
              </div>
            );
          })}
        </div>

        {/* Form Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Enhanced Contact Info Box */}
          <div className="relative bg-gradient-to-br from-blue-50 to-indigo-50 rounded-3xl p-8 sm:p-10 border border-blue-100 shadow-lg">
            {/* Glow Effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-purple-500/10 blur-3xl rounded-3xl"></div>

            <div className="relative z-10">
              <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">
                Why Choose
                <br />
                <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                  Our Support?
                </span>
              </h2>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                We're committed to providing exceptional customer service. Our
                team is dedicated to ensuring you receive prompt and helpful
                assistance whenever you need it.
              </p>

              <div className="space-y-6">
                <div className="flex items-start gap-4 p-4 bg-white/80 rounded-2xl border border-blue-100 backdrop-blur-sm">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-green-500 to-emerald-500 flex items-center justify-center flex-shrink-0">
                    <Zap className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="font-bold text-gray-900 text-lg mb-1">
                      Quick Response
                    </p>
                    <p className="text-gray-600">
                      We typically respond within 24 hours
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 bg-white/80 rounded-2xl border border-purple-100 backdrop-blur-sm">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0">
                    <Headphones className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="font-bold text-gray-900 text-lg mb-1">
                      Expert Support
                    </p>
                    <p className="text-gray-600">
                      Our team knows everything about our products
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 bg-white/80 rounded-2xl border border-pink-100 backdrop-blur-sm">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 flex items-center justify-center flex-shrink-0">
                    <Clock className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="font-bold text-gray-900 text-lg mb-1">
                      Always Available
                    </p>
                    <p className="text-gray-600">
                      24/7 customer support for your convenience
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Enhanced Contact Form */}
          <div className="bg-white rounded-3xl p-8 sm:p-10 shadow-xl border border-gray-200">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-1.5 h-10 bg-gradient-to-b from-blue-500 to-purple-500 rounded-full"></div>
              <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">
                Send a Message
              </h2>
            </div>

            {submitted && (
              <div className="mb-8 p-4 bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-2xl animate-slideInUp">
                <div className="flex items-center gap-3">
                  <FiCheckCircle className="w-6 h-6 text-green-600" />
                  <div>
                    <p className="font-bold text-green-700 text-lg">
                      Message Sent Successfully!
                    </p>
                    <p className="text-green-600 text-sm">
                      We'll be in touch within 24 hours.
                    </p>
                  </div>
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-bold text-gray-900 mb-3 flex items-center gap-2">
                  <div className="w-2 h-2 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full"></div>
                  Full Name
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Enter your name"
                  required
                  className="w-full px-5 py-4 border-2 border-gray-200 rounded-2xl focus:border-blue-500 focus:ring-4 focus:ring-blue-100 focus:outline-none transition-all duration-300 text-base hover:border-blue-300"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-900 mb-3 flex items-center gap-2">
                  <div className="w-2 h-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"></div>
                  Email Address
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="Enter your email"
                  required
                  className="w-full px-5 py-4 border-2 border-gray-200 rounded-2xl focus:border-purple-500 focus:ring-4 focus:ring-purple-100 focus:outline-none transition-all duration-300 text-base hover:border-purple-300"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-900 mb-3 flex items-center gap-2">
                  <div className="w-2 h-2 bg-gradient-to-r from-pink-500 to-rose-500 rounded-full"></div>
                  Message
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={4}
                  placeholder="Tell us how we can help you..."
                  required
                  className="w-full px-5 py-4 border-2 border-gray-200 rounded-2xl focus:border-pink-500 focus:ring-4 focus:ring-pink-100 focus:outline-none transition-all duration-300 text-base hover:border-pink-300 resize-none"
                />
              </div>

              <button
                type="submit"
                className="group relative w-full bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 text-white py-4 rounded-2xl font-bold text-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 active:scale-95"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 rounded-2xl opacity-0 group-hover:opacity-30 blur-xl transition-opacity duration-500"></div>
                <div className="relative flex items-center justify-center gap-3">
                  <Send className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  <span>Send Message</span>
                </div>
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Enhanced Location Section - COLOR THEME MATCHED */}
      <section className="bg-gradient-to-b from-white to-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-24">
          <div className="text-center mb-16">
            {/* Premium Badge - MATCHED COLOR THEME */}
            <div className="inline-flex items-center gap-3 bg-gradient-to-r from-blue-50 to-purple-50 px-6 py-3 rounded-full border border-blue-100 mb-6">
              <MapPin className="w-5 h-5 text-blue-600" />
              <span className="text-sm font-bold text-blue-600 tracking-wider">
                VISIT US
              </span>
              <Sparkles className="w-4 h-4 text-purple-500" />
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
              Find Our
              <br />
              <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                Headquarters
              </span>
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Visit our corporate office or reach out via any communication
              channel. We're always ready to welcome you.
            </p>
          </div>

          <div className="relative overflow-hidden bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 rounded-3xl p-8 sm:p-12 lg:p-16 text-center text-white shadow-2xl">
            {/* Background Effects */}
            <div className="absolute inset-0">
              <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
              <div className="absolute bottom-0 left-0 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
            </div>

            <div className="relative z-10">
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-white/20 backdrop-blur-sm border border-white/30 mb-8">
                <MapPin className="w-10 h-10" />
              </div>

              <p className="text-3xl sm:text-4xl font-bold mb-4">
                New Delhi, India
              </p>
              <p className="text-blue-100 text-lg mb-8 max-w-md mx-auto">
                Corporate Headquarters - Available for meetings by appointment
              </p>

              <button className="group inline-flex items-center gap-3 px-8 py-4 bg-white text-blue-600 font-bold rounded-2xl hover:shadow-xl transition-all duration-300 hover:scale-105">
                <span>Get Directions</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Additional Contact Channels */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-24">
        <div className="text-center mb-12">
          <h3 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4">
            Other Ways to Connect
          </h3>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Choose your preferred communication channel. We're available across
            multiple platforms.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <div className="p-6 bg-gradient-to-br from-gray-50 to-white rounded-2xl border border-gray-200 text-center">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 flex items-center justify-center mx-auto mb-4">
              <MessageSquare className="w-6 h-6 text-white" />
            </div>
            <h4 className="font-bold text-gray-900 mb-2">Live Chat</h4>
            <p className="text-gray-600 text-sm">
              Available 24/7 on our website
            </p>
          </div>

          <div className="p-6 bg-gradient-to-br from-gray-50 to-white rounded-2xl border border-gray-200 text-center">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center mx-auto mb-4">
              <Headphones className="w-6 h-6 text-white" />
            </div>
            <h4 className="font-bold text-gray-900 mb-2">Phone Support</h4>
            <p className="text-gray-600 text-sm">Mon-Sun, 9AM-9PM IST</p>
          </div>

          <div className="p-6 bg-gradient-to-br from-gray-50 to-white rounded-2xl border border-gray-200 text-center">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 flex items-center justify-center mx-auto mb-4">
              <Mail className="w-6 h-6 text-white" />
            </div>
            <h4 className="font-bold text-gray-900 mb-2">Email</h4>
            <p className="text-gray-600 text-sm">Response within 24 hours</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;

import React, { useState, useEffect, useCallback } from "react";
import ProductCard from "../components/ProductCard";
import { apiService } from "../services/api";
import { Product, Category, CartItem } from "../types";
import { useDebounce } from "../hooks/useDebounce";
import {
  FiSearch,
  FiFilter,
  FiShoppingBag,
  FiTruck,
  FiShield,
  FiAward,
  FiStar,
  FiArrowRight,
  FiChevronRight,
  FiCheck,
  FiMail,
  FiMenu,
  FiX,
  FiChevronLeft,
} from "react-icons/fi";
import {
  MdOutlineElectricalServices,
  MdOutlineCheckCircle,
  MdOutlineDiscount,
} from "react-icons/md";
import { GiClothes, GiSparkles } from "react-icons/gi";
import { IoHomeOutline, IoFitnessOutline } from "react-icons/io5";
import { RiEmotionHappyLine, RiCustomerService2Line } from "react-icons/ri";
import { BsArrowRight, BsChevronLeft, BsChevronRight } from "react-icons/bs";

interface HomeProps {
  addToCart: (item: CartItem) => void;
}

const Home: React.FC<HomeProps> = ({ addToCart }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<Category>("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [emailSubscribed, setEmailSubscribed] = useState(false);
  const [subscribeEmail, setSubscribeEmail] = useState("");
  const [currentSlide, setCurrentSlide] = useState(0);

  const debouncedSearch = useDebounce(searchQuery, 300);

  const categories: { name: Category; icon: React.ReactNode }[] = [
    { name: "All", icon: <FiShoppingBag className="w-4 h-4 sm:w-5 sm:h-5" /> },
    {
      name: "Electronics",
      icon: <MdOutlineElectricalServices className="w-4 h-4 sm:w-5 sm:h-5" />,
    },
    { name: "Fashion", icon: <GiClothes className="w-4 h-4 sm:w-5 sm:h-5" /> },
    { name: "Home", icon: <IoHomeOutline className="w-4 h-4 sm:w-5 sm:h-5" /> },
    {
      name: "Sports",
      icon: <IoFitnessOutline className="w-4 h-4 sm:w-5 sm:h-5" />,
    },
    {
      name: "Beauty",
      icon: <RiEmotionHappyLine className="w-4 h-4 sm:w-5 sm:h-5" />,
    },
  ];

  // Hero Slider Data
  const heroSlides = [
    {
      id: 1,
      title: "Summer Collection 2024",
      subtitle: "Discover the Latest Trends",
      description:
        "Up to 50% off on premium fashion items. Limited time offer!",
      buttonText: "Shop Now",
      image:
        "https://images.unsplash.com/photo-1445205170230-053b83016050?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&q=80",
      color: "from-blue-500 to-purple-600",
    },
    {
      id: 2,
      title: "Tech Gadgets Sale",
      subtitle: "Innovation at Your Fingertips",
      description: "Latest electronics with premium quality and warranty",
      buttonText: "Explore Tech",
      image:
        "https://images.unsplash.com/photo-1498049794561-7780e7231661?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&q=80",
      color: "from-purple-500 to-pink-600",
    },
    {
      id: 3,
      title: "Home Essentials",
      subtitle: "Create Your Dream Space",
      description: "Premium home decor with free shipping on all orders",
      buttonText: "Browse Home",
      image:
        "https://images.unsplash.com/photo-1556228453-efd6c1ff04f6?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&q=80",
      color: "from-emerald-500 to-cyan-600",
    },
    {
      id: 4,
      title: "Fitness Gear",
      subtitle: "Train Like a Pro",
      description: "Professional sports equipment with 30-day returns",
      buttonText: "Shop Fitness",
      image:
        "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&q=80",
      color: "from-orange-500 to-red-600",
    },
  ];

  // Auto slide every 3 seconds
  useEffect(() => {
    const slideInterval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
    }, 3000);

    return () => clearInterval(slideInterval);
  }, []);

  // Manual slide control
  const goToSlide = useCallback((index: number) => {
    setCurrentSlide(index);
  }, []);

  const nextSlide = useCallback(() => {
    setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
  }, []);

  const prevSlide = useCallback(() => {
    setCurrentSlide(
      (prev) => (prev - 1 + heroSlides.length) % heroSlides.length,
    );
  }, []);

  // Fetch products
  useEffect(() => {
    const fetchProducts = async () => {
      setIsLoading(true);
      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 800));
      const data = apiService.getFeaturedProducts();
      setProducts(data);
      setFilteredProducts(data);
      setIsLoading(false);
    };
    fetchProducts();
  }, []);

  // Filter products
  useEffect(() => {
    let result = products;

    if (selectedCategory !== "All") {
      result = result.filter((p) => p.category === selectedCategory);
    }

    if (debouncedSearch) {
      result = result.filter((p) =>
        p.name.toLowerCase().includes(debouncedSearch.toLowerCase()),
      );
    }

    setFilteredProducts(result);
  }, [selectedCategory, debouncedSearch, products]);

  // Testimonials data
  const testimonials = [
    {
      id: 1,
      text: "The quality exceeded my expectations! Fast shipping and excellent customer service.",
      author: "Sarah Johnson",
      role: "Verified Buyer",
      rating: 5,
      image:
        "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400&q=80",
    },
    {
      id: 2,
      text: "Best shopping experience ever! Found everything I needed at great prices.",
      author: "Michael Chen",
      role: "Premium Member",
      rating: 5,
      image:
        "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400&q=80",
    },
    {
      id: 3,
      text: "ShopVerse has become my go-to for all shopping needs. Highly recommended!",
      author: "Emma Davis",
      role: "Loyal Customer",
      rating: 5,
      image:
        "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400&q=80",
    },
  ];

  // Features data
  const features = [
    {
      icon: <MdOutlineCheckCircle className="w-6 h-6 sm:w-8 sm:h-8" />,
      title: "Premium Quality",
      description: "Every product is carefully curated and quality-checked",
    },
    {
      icon: <FiShield className="w-6 h-6 sm:w-8 sm:h-8" />,
      title: "Verified Sellers",
      description: "100% authentic products from trusted sellers",
    },
    {
      icon: <FiTruck className="w-6 h-6 sm:w-8 sm:h-8" />,
      title: "Fast Shipping",
      description: "Free delivery on orders above $50",
    },
    {
      icon: <MdOutlineDiscount className="w-6 h-6 sm:w-8 sm:h-8" />,
      title: "Best Prices",
      description: "Price match guarantee on all items",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* ==================== HERO SLIDER SECTION ==================== */}
      <section className="relative overflow-hidden bg-gradient-to-br from-gray-900 to-gray-800">
        {/* Animated background particles */}
        <div className="absolute inset-0 overflow-hidden z-0">
          <div className="absolute top-20 left-10 w-72 h-72 bg-blue-500/20 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
          <div className="absolute top-1/2 left-1/2 w-80 h-80 bg-pink-500/15 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>
        </div>

        {/* Slider Container */}
        <div className="relative h-[500px] sm:h-[600px] lg:h-[700px] overflow-hidden">
          {heroSlides.map((slide, index) => (
            <div
              key={slide.id}
              className={`absolute inset-0 transition-all duration-700 ease-in-out ${
                index === currentSlide
                  ? "opacity-100 translate-x-0 scale-100"
                  : "opacity-0 translate-x-full scale-105"
              }`}
            >
              {/* Background Image with Overlay */}
              <div className="absolute inset-0">
                <img
                  src={slide.image}
                  alt={slide.title}
                  className="w-full h-full object-cover transform scale-110 transition-transform duration-1000"
                />
                <div
                  className={`absolute inset-0 bg-gradient-to-r ${slide.color} mix-blend-multiply opacity-85`}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                <div className="absolute inset-0 bg-gradient-to-r from-black/40 via-transparent to-transparent" />
              </div>

              {/* Content */}
              <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center z-10">
                <div className="max-w-2xl text-white space-y-6 sm:space-y-10 animate-fadeIn">
                  {/* Badge */}
                  <div className="inline-flex items-center px-5 py-2.5 rounded-full bg-white/20 backdrop-blur-xl border border-white/30 shadow-2xl hover:bg-white/30 transition-all duration-300 transform hover:scale-105">
                    <GiSparkles className="w-5 h-5 sm:w-6 sm:h-6 text-yellow-300 mr-2.5 animate-pulse" />
                    <span className="text-sm sm:text-base font-bold tracking-wider text-white">
                      ✨ New Arrival
                    </span>
                  </div>

                  {/* Heading */}
                  <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black leading-tight tracking-tight">
                    <span className="block drop-shadow-2xl animate-slideInUp" style={{ animationDelay: '0.1s' }}>
                      {slide.title}
                    </span>
                    <span className="block mt-3 text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-yellow-300 to-pink-300 drop-shadow-2xl font-black animate-slideInUp" style={{ animationDelay: '0.2s' }}>
                      {slide.subtitle}
                    </span>
                  </h1>

                  {/* Description */}
                  <p className="text-lg sm:text-xl text-white/95 max-w-xl leading-relaxed font-semibold drop-shadow-xl animate-slideInUp" style={{ animationDelay: '0.3s' }}>
                    {slide.description}
                  </p>

                  {/* CTA Button */}
                  <div className="animate-slideInUp" style={{ animationDelay: '0.4s' }}>
                    <button
                      onClick={() =>
                        document
                          .getElementById("products")
                          ?.scrollIntoView({ behavior: "smooth" })
                      }
                      className="group relative inline-flex items-center px-8 py-4 sm:px-10 sm:py-5 text-base sm:text-lg font-bold text-white bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 rounded-2xl hover:from-blue-700 hover:via-purple-700 hover:to-pink-700 focus:outline-none focus:ring-4 focus:ring-white/50 transition-all duration-300 shadow-2xl hover:shadow-blue-500/50 transform hover:scale-105 active:scale-95 overflow-hidden"
                    >
                      {/* Shine effect */}
                      <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></span>
                      <span className="relative z-10">{slide.buttonText}</span>
                      <FiArrowRight className="ml-3 w-6 h-6 group-hover:translate-x-2 transition-transform duration-300 relative z-10" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}

          {/* Navigation Arrows */}
          <button
            onClick={prevSlide}
            className="absolute left-4 sm:left-6 top-1/2 transform -translate-y-1/2 w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-white/25 backdrop-blur-xl border-2 border-white/40 flex items-center justify-center text-white hover:bg-white/40 hover:scale-110 transition-all duration-300 z-20 shadow-2xl group"
            aria-label="Previous slide"
          >
            <FiChevronLeft className="w-6 h-6 sm:w-7 sm:h-7 group-hover:-translate-x-1 transition-transform" />
          </button>

          <button
            onClick={nextSlide}
            className="absolute right-4 sm:right-6 top-1/2 transform -translate-y-1/2 w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-white/25 backdrop-blur-xl border-2 border-white/40 flex items-center justify-center text-white hover:bg-white/40 hover:scale-110 transition-all duration-300 z-20 shadow-2xl group"
            aria-label="Next slide"
          >
            <FiChevronRight className="w-6 h-6 sm:w-7 sm:h-7 group-hover:translate-x-1 transition-transform" />
          </button>

          {/* Dots Indicator with Enhanced Styling */}
          <div className="absolute bottom-6 sm:bottom-8 left-1/2 transform -translate-x-1/2 flex items-center space-x-3 z-20 px-5 py-3.5 rounded-full bg-black/30 backdrop-blur-xl border-2 border-white/30 shadow-2xl">
            {heroSlides.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`rounded-full transition-all duration-300 transform hover:scale-125 ${
                  index === currentSlide
                    ? "bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 w-10 h-3 sm:w-12 sm:h-3 shadow-xl shadow-blue-400/60 ring-2 ring-white/30"
                    : "bg-white/50 hover:bg-white/80 w-2.5 h-2.5 sm:w-3 sm:h-3 hover:shadow-lg hover:shadow-white/40"
                }`}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* ==================== SEARCH & FILTERS ==================== */}
      <section className="py-12 sm:py-16 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-8">
            {/* Search Bar */}
            <div className="flex-1 w-full max-w-2xl">
              <div className="relative group">
                <label className="text-xs font-bold text-gray-600 uppercase tracking-wider block mb-2.5">
                  🔍 Search Products
                </label>
                <FiSearch className="absolute left-4 top-11 transform -translate-y-1/2 text-gray-400 w-5 h-5 group-focus-within:text-blue-600 transition-colors duration-300" />
                <input
                  type="text"
                  placeholder="Search by name, brand, category..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-5 py-3.5 sm:py-4 text-sm sm:text-base border-2 border-gray-300 rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-blue-600 focus:outline-none transition-all duration-300 shadow-sm hover:shadow-md hover:border-blue-400 group-focus-within:border-blue-600 group-focus-within:shadow-lg group-focus-within:shadow-blue-300/40 font-medium"
                />
              </div>
            </div>

            {/* Categories Filter */}
            <div className="flex flex-col gap-2.5">
              <label className="text-xs font-bold text-gray-600 uppercase tracking-wider flex items-center gap-2">
                <FiFilter className="w-4 h-4" />
                Filter by Category
              </label>
              <div className="flex flex-wrap gap-2 sm:gap-3">
                {categories.map(({ name, icon }) => (
                  <button
                    key={name}
                    onClick={() => setSelectedCategory(name)}
                    className={`inline-flex items-center px-4 py-2 sm:px-5 sm:py-2.5 rounded-lg text-sm sm:text-base font-medium transition-all duration-300 transform ${
                      selectedCategory === name
                        ? "bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg shadow-blue-500/25 scale-105"
                        : "bg-gray-50 text-gray-700 hover:bg-gray-100 border border-gray-200 hover:border-blue-300 hover:shadow-md hover:scale-102 group-hover:shadow-md"
                    }`}
                  >
                    <span className="mr-2 transition-transform duration-300 group-hover:scale-110">
                      {icon}
                    </span>
                    {name}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ==================== FEATURED PRODUCTS ==================== */}
      <section
        id="products"
        className="py-16 sm:py-20 lg:py-24 bg-gradient-to-br from-gray-50 via-white to-blue-50/20 relative overflow-hidden"
      >
        {/* Background decorations - more vibrant */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-blue-200/20 to-transparent rounded-full blur-3xl -mr-48"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-purple-200/20 to-transparent rounded-full blur-3xl -ml-48"></div>
        <div className="absolute top-1/2 left-1/2 w-80 h-80 bg-pink-100/10 rounded-full blur-3xl -translate-x-1/2"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-14 sm:mb-18 lg:mb-24 animate-fade-in">
            <div className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-gradient-to-r from-blue-100 to-cyan-100 border border-blue-300/70 mb-6 bounce-pop shadow-md">
              <span className="w-3 h-3 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-full animate-pulse shadow-lg"></span>
              <span className="text-xs sm:text-sm font-bold bg-gradient-to-r from-blue-700 to-cyan-700 bg-clip-text text-transparent uppercase tracking-wider">
                ⭐ Featured Collection
              </span>
            </div>
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-black text-gray-900 mb-5 tracking-tight">
              <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent drop-shadow-sm">
                Trending Products
              </span>
            </h2>
            <p className="text-lg sm:text-xl text-gray-700 max-w-3xl mx-auto font-medium leading-relaxed">
              Discover our hand-picked collection of premium, verified products
            </p>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-2 xs:grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-2 xs:gap-3 sm:gap-4 lg:gap-6 animate-pulse">
              {[...Array(8)].map((_, i) => (
                <div
                  key={i}
                  className="bg-gradient-to-br from-gray-100 to-gray-50 rounded-lg sm:rounded-xl shadow-sm p-3 border border-gray-200 overflow-hidden"
                  style={{
                    animation: `shimmer 2s infinite`,
                    animationDelay: `${i * 0.1}s`,
                  }}
                >
                  <div className="aspect-square sm:aspect-[4/3] bg-gradient-to-r from-gray-200 to-gray-100 rounded-lg mb-3"></div>
                  <div className="h-3 bg-gray-200 rounded mb-2"></div>
                  <div className="h-2 bg-gray-100 rounded w-4/5 mb-2"></div>
                  <div className="flex gap-2 mt-3">
                    <div className="h-2 bg-gray-100 rounded flex-1"></div>
                    <div className="h-6 w-20 bg-gradient-to-r from-blue-200 to-purple-200 rounded"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : filteredProducts.length > 0 ? (
            <div className="grid grid-cols-2 xs:grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-2 xs:gap-3 sm:gap-4 lg:gap-6">
              {filteredProducts.map((product, idx) => (
                <div
                  key={product.id}
                  className="animate-fade-in transform transition-all duration-500 hover:scale-105"
                  style={{
                    animationDelay: `${idx * 40}ms`,
                  }}
                >
                  <ProductCard product={product} onAddToCart={addToCart} />
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 sm:py-24">
              <div className="inline-flex items-center justify-center w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-gradient-to-br from-blue-100 to-purple-100 mb-8 animate-bounce">
                <FiSearch className="w-10 h-10 sm:w-12 sm:h-12 text-blue-500" />
              </div>
              <h3 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-3">
                No products found
              </h3>
              <p className="text-gray-600 mb-8 max-w-md mx-auto">
                Try adjusting your search or filter to find what you're looking
                for.
              </p>
              <button
                onClick={() => {
                  setSearchQuery("");
                  setSelectedCategory("All");
                }}
                className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold rounded-xl hover:from-blue-600 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-300 hover:shadow-lg hover:shadow-blue-500/30 transform hover:scale-105"
              >
                Reset Filters
                <FiArrowRight className="ml-2 w-5 h-5" />
              </button>
            </div>
          )}
        </div>
      </section>

      {/* ==================== WHY CHOOSE US ==================== */}
      <section className="py-16 sm:py-20 lg:py-24 bg-gradient-to-br from-white via-blue-50/10 to-purple-50/10 border-t border-gray-100 relative overflow-hidden">
        {/* Background decorations */}
        <div className="absolute top-20 left-10 w-64 h-64 bg-blue-100/15 rounded-full blur-3xl -z-10"></div>
        <div className="absolute bottom-20 right-10 w-72 h-72 bg-purple-100/15 rounded-full blur-3xl -z-10"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16 sm:mb-22 lg:mb-28">
            <div className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-gradient-to-r from-purple-100 to-blue-100 border border-purple-300/70 mb-7 bounce-pop shadow-md">
              <span className="w-3 h-3 rounded-full bg-gradient-to-r from-purple-600 to-blue-600 animate-pulse shadow-lg"></span>
              <span className="text-xs sm:text-sm font-bold bg-gradient-to-r from-purple-700 to-blue-700 bg-clip-text text-transparent uppercase tracking-wider">
                🏆 Our Advantage
              </span>
            </div>
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-black mb-5 tracking-tight">
              <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent drop-shadow-sm">
                Why Choose ShopVerse?
              </span>
            </h2>
            <p className="text-lg sm:text-xl text-gray-700 max-w-3xl mx-auto font-medium leading-relaxed">
              We're committed to delivering excellence in every shopping
              experience
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="group relative bg-white p-6 sm:p-8 rounded-2xl transition-all duration-500 border border-gray-100 hover:border-transparent overflow-hidden animate-fade-in hover:bounce-soft"
                style={{
                  animationDelay: `${index * 100}ms`,
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.animation =
                    "bounce-soft 2s ease-in-out infinite";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.animation = "none";
                }}
              >
                {/* Background gradient overlay - changes on hover */}
                <div
                  className="absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-100 transition-all duration-500 -z-10"
                  style={{
                    backgroundImage: [
                      "linear-gradient(135deg, rgba(59, 130, 246, 0.08) 0%, rgba(139, 92, 246, 0.05) 100%)",
                      "linear-gradient(135deg, rgba(139, 92, 246, 0.08) 0%, rgba(236, 72, 153, 0.05) 100%)",
                      "linear-gradient(135deg, rgba(34, 197, 94, 0.08) 0%, rgba(59, 130, 246, 0.05) 100%)",
                      "linear-gradient(135deg, rgba(236, 72, 153, 0.08) 0%, rgba(249, 115, 22, 0.05) 100%)",
                    ][index],
                  }}
                ></div>

                {/* Top accent gradient bar */}
                <div
                  className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r opacity-0 group-hover:opacity-100 transition-all duration-500"
                  style={{
                    backgroundImage: [
                      "linear-gradient(90deg, #3b82f6, #8b5cf6)",
                      "linear-gradient(90deg, #8b5cf6, #ec4899)",
                      "linear-gradient(90deg, #22c55e, #3b82f6)",
                      "linear-gradient(90deg, #ec4899, #f97316)",
                    ][index],
                  }}
                ></div>

                {/* Number badge */}
                <div
                  className="absolute -top-3 -right-3 w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center text-xs sm:text-sm font-bold text-white shadow-lg transition-all duration-500 group-hover:scale-110"
                  style={{
                    backgroundImage: [
                      "linear-gradient(135deg, #3b82f6, #8b5cf6)",
                      "linear-gradient(135deg, #8b5cf6, #ec4899)",
                      "linear-gradient(135deg, #22c55e, #3b82f6)",
                      "linear-gradient(135deg, #ec4899, #f97316)",
                    ][index],
                  }}
                >
                  {index + 1}
                </div>

                {/* Icon container with glow */}
                <div className="relative mb-6">
                  <div
                    className="absolute inset-0 bg-gradient-to-r opacity-0 group-hover:opacity-75 blur-lg transition-all duration-500 rounded-2xl"
                    style={{
                      backgroundImage: [
                        "linear-gradient(135deg, #3b82f6, #8b5cf6)",
                        "linear-gradient(135deg, #8b5cf6, #ec4899)",
                        "linear-gradient(135deg, #22c55e, #3b82f6)",
                        "linear-gradient(135deg, #ec4899, #f97316)",
                      ][index],
                    }}
                  ></div>
                  <div
                    className="relative inline-flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-2xl text-white transition-all duration-500 group-hover:scale-125"
                    style={{
                      backgroundImage: [
                        "linear-gradient(135deg, #3b82f6, #8b5cf6)",
                        "linear-gradient(135deg, #8b5cf6, #ec4899)",
                        "linear-gradient(135deg, #22c55e, #3b82f6)",
                        "linear-gradient(135deg, #ec4899, #f97316)",
                      ][index],
                    }}
                  >
                    {feature.icon}
                  </div>
                </div>

                {/* Content */}
                <h3
                  className="text-lg sm:text-xl font-bold text-gray-900 mb-3 transition-all duration-300 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r"
                  style={{
                    backgroundImage: [
                      "linear-gradient(90deg, #3b82f6, #8b5cf6)",
                      "linear-gradient(90deg, #8b5cf6, #ec4899)",
                      "linear-gradient(90deg, #22c55e, #3b82f6)",
                      "linear-gradient(90deg, #ec4899, #f97316)",
                    ][index],
                  }}
                >
                  {feature.title}
                </h3>
                <p className="text-sm sm:text-base text-gray-600 transition-colors duration-300 group-hover:text-gray-700">
                  {feature.description}
                </p>

                {/* Bottom border expansion effect */}
                <div
                  className="absolute bottom-0 left-0 w-0 h-1 group-hover:w-full transition-all duration-500"
                  style={{
                    backgroundImage: [
                      "linear-gradient(90deg, #3b82f6, #8b5cf6)",
                      "linear-gradient(90deg, #8b5cf6, #ec4899)",
                      "linear-gradient(90deg, #22c55e, #3b82f6)",
                      "linear-gradient(90deg, #ec4899, #f97316)",
                    ][index],
                  }}
                ></div>

                {/* Shadow effect on hover */}
                <div
                  className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                  style={{
                    boxShadow: [
                      "0 20px 40px rgba(59, 130, 246, 0.15)",
                      "0 20px 40px rgba(139, 92, 246, 0.15)",
                      "0 20px 40px rgba(34, 197, 94, 0.15)",
                      "0 20px 40px rgba(236, 72, 153, 0.15)",
                    ][index],
                  }}
                ></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ==================== TESTIMONIALS ==================== */}
      <section className="py-16 sm:py-20 lg:py-24 bg-gradient-to-br from-white via-blue-50/30 to-purple-50/30 relative overflow-hidden">
        {/* Background decorations */}
        <div className="absolute top-0 right-0 w-72 h-72 bg-blue-200/10 rounded-full blur-3xl -mr-36"></div>
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-purple-200/10 rounded-full blur-3xl -ml-40"></div>
        <div className="absolute top-1/2 left-1/3 w-96 h-96 bg-pink-100/5 rounded-full blur-3xl"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16 sm:mb-22 lg:mb-28">
            <div className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-gradient-to-r from-blue-100 to-purple-100 border border-blue-300/70 mb-7 bounce-pop shadow-md">
              <span className="w-3 h-3 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 animate-pulse shadow-lg"></span>
              <span className="text-xs sm:text-sm font-bold bg-gradient-to-r from-blue-700 to-purple-700 bg-clip-text text-transparent uppercase tracking-wider">
                ⭐⭐⭐ Customer Reviews
              </span>
            </div>
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-black mb-5 tracking-tight">
              <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent drop-shadow-sm">
                What Our Customers Say
              </span>
            </h2>
            <p className="text-lg sm:text-xl text-gray-700 max-w-3xl mx-auto font-medium leading-relaxed">
              Trusted by thousands of satisfied customers and verified buyers
              worldwide
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {testimonials.map((testimonial, idx) => (
              <div
                key={testimonial.id}
                className="group relative bg-white p-6 sm:p-8 rounded-2xl transition-all duration-500 border border-gray-200/70 overflow-hidden animate-fade-in h-full flex flex-col hover:bounce-soft"
                style={{
                  animationDelay: `${idx * 100}ms`,
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.animation =
                    "bounce-soft 2s ease-in-out infinite";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.animation = "none";
                }}
              >
                {/* Background gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-50/0 via-purple-50/0 to-pink-50/0 group-hover:from-blue-50/50 group-hover:via-purple-50/30 group-hover:to-pink-50/20 transition-all duration-500 -z-10"></div>

                {/* Top accent line with gradient */}
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left"></div>

                {/* Testimonial number badge */}
                <div className="absolute -top-2 -right-2 w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center text-xs sm:text-sm font-bold text-white bg-gradient-to-r from-blue-500 to-purple-600 shadow-lg transform scale-75 group-hover:scale-100 transition-transform duration-500">
                  {idx + 1}
                </div>

                {/* Star rating with enhanced styling */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <FiStar
                        key={i}
                        className="w-5 h-5 text-yellow-400 fill-yellow-400 transition-all duration-300 group-hover:scale-110"
                        style={{ transitionDelay: `${i * 50}ms` }}
                      />
                    ))}
                  </div>
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-gradient-to-r from-blue-100 to-purple-100 text-blue-700 group-hover:from-purple-100 group-hover:to-pink-100 group-hover:text-purple-700 transition-all">
                    ⭐ {testimonial.rating}.0
                  </span>
                </div>

                {/* Quote icon and text with enhanced styling */}
                <div className="mb-6 flex-grow">
                  <svg
                    className="w-8 h-8 text-blue-300 mb-3 opacity-50 group-hover:opacity-100 group-hover:text-purple-300 transition-all duration-300 transform group-hover:scale-110"
                    fill="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path d="M3 21c3 0 7-1 7-8V5c0-1.25-4.5-5-7-5-1 0-2 .5-2 1.972V11c0 1-1 4-1 6s.57 6 3 6zm16 0c3 0 7-1 7-8V5c0-1.25-4.5-5-7-5-1 0-2 .5-2 1.972V11c0 1-1 4-1 6s.57 6 3 6z" />
                  </svg>
                  <p className="text-gray-700 text-sm sm:text-base leading-relaxed font-medium group-hover:text-gray-900 transition-colors">
                    "{testimonial.text}"
                  </p>
                </div>

                {/* Author info with enhanced styling */}
                <div className="flex items-center gap-4 pt-6 border-t border-gray-200/50 group-hover:border-purple-200/50 transition-colors">
                  <div className="relative flex-shrink-0">
                    {/* Glow effect on hover */}
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-full blur-md opacity-0 group-hover:opacity-60 transition-opacity duration-300"></div>

                    {/* Avatar */}
                    <div className="relative w-12 h-12 sm:w-14 sm:h-14 rounded-full overflow-hidden border-2 border-gray-300 group-hover:border-purple-400 transition-all duration-300">
                      <img
                        src={testimonial.image}
                        alt={testimonial.author}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                    </div>
                  </div>

                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-gray-900 text-sm sm:text-base group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-blue-600 group-hover:to-purple-600 transition-all duration-300">
                      {testimonial.author}
                    </h4>
                    <p className="text-gray-500 text-xs sm:text-sm group-hover:text-purple-600 transition-colors duration-300">
                      {testimonial.role}
                    </p>
                  </div>

                  {/* Verified badge */}
                  <div className="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-x-2 group-hover:translate-x-0">
                    <div className="w-6 h-6 rounded-full bg-gradient-to-r from-green-400 to-emerald-500 flex items-center justify-center shadow-lg">
                      <svg
                        className="w-3.5 h-3.5 text-white"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path
                          fillRule="evenodd"
                          d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                  </div>
                </div>

                {/* Bottom shadow effect */}
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left opacity-0 group-hover:opacity-60"></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ==================== NEWSLETTER ==================== */}
      <section className="py-16 sm:py-20 lg:py-28 bg-gradient-to-br from-white via-blue-50/40 to-purple-50/40 relative overflow-hidden">
        {/* Background decorative elements */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-gradient-to-bl from-blue-300/15 to-transparent rounded-full blur-3xl -mr-40"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-purple-300/15 to-transparent rounded-full blur-3xl -ml-40"></div>
        <div className="absolute top-1/2 left-1/2 w-72 h-72 bg-pink-200/10 rounded-full blur-3xl -translate-x-1/2"></div>

        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          {/* Main Newsletter Card */}
          <div className="bg-gradient-to-br from-white to-blue-50/30 backdrop-blur-sm rounded-3xl border border-white/80 shadow-2xl overflow-hidden">
            {/* Top gradient bar */}
            <div className="h-1.5 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600"></div>

            <div className="p-8 sm:p-12 lg:p-16">
              <div className="text-center">
                {/* Icon */}
                <div className="relative inline-flex items-center justify-center mb-8 group bounce-medium">
                  {/* Animated outer ring 1 */}
                  <div
                    className="absolute w-32 h-32 sm:w-40 sm:h-40 rounded-full border-2 border-blue-200/30 group-hover:border-blue-300/60 transition-all duration-300 animate-spin"
                    style={{ animationDuration: "8s" }}
                  ></div>

                  {/* Animated outer ring 2 */}
                  <div
                    className="absolute w-28 h-28 sm:w-36 sm:h-36 rounded-full border-2 border-purple-200/30 group-hover:border-purple-300/60 transition-all duration-300 animate-spin"
                    style={{
                      animationDuration: "6s",
                      animationDirection: "reverse",
                    }}
                  ></div>

                  {/* Glow effect */}
                  <div className="absolute inset-0 w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-gradient-to-r from-blue-400/20 via-purple-400/20 to-pink-400/20 blur-xl group-hover:from-blue-400/40 group-hover:via-purple-400/40 group-hover:to-pink-400/40 transition-all duration-300"></div>

                  {/* Main icon box */}
                  <div className="relative inline-flex items-center justify-center w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-gradient-to-br from-blue-100 to-purple-100 border-2 border-blue-200/60 shadow-xl transform hover:scale-110 transition-all duration-300 group-hover:shadow-2xl group-hover:shadow-blue-500/30">
                    <FiMail className="w-10 h-10 sm:w-12 sm:h-12 text-blue-600 group-hover:text-purple-600 transition-colors duration-300" />
                  </div>
                </div>

                {/* Badge */}
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-blue-100 to-cyan-100 border border-blue-200/60 mb-6 bounce-pop">
                  <span className="w-2 h-2 bg-blue-600 rounded-full animate-pulse"></span>
                  <span className="text-sm font-semibold bg-gradient-to-r from-blue-700 to-cyan-700 bg-clip-text text-transparent">
                    EXCLUSIVE OFFERS
                  </span>
                </div>

                {/* Heading */}
                <h2 className="text-4xl sm:text-5xl lg:text-6xl font-black mb-6 tracking-tight">
                  <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent drop-shadow-sm">
                    Unlock Exclusive Deals
                  </span>
                </h2>

                {/* Description */}
                <p className="text-lg sm:text-xl text-gray-700 mb-5 font-semibold max-w-2xl mx-auto leading-relaxed">
                  Join thousands of smart shoppers and get instant access to:
                </p>
                <div className="flex flex-wrap gap-4 justify-center mb-12 text-sm sm:text-base">
                  <div className="flex items-center gap-3 px-5 py-3 rounded-xl bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-300/60 shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-600 flex items-center justify-center">
                      <svg
                        className="w-4 h-4 text-white"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path
                          fillRule="evenodd"
                          d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <span className="text-gray-800 font-bold">
                      15% Off First Order
                    </span>
                  </div>
                  <div className="flex items-center gap-3 px-5 py-3 rounded-xl bg-gradient-to-br from-purple-50 to-purple-100 border-2 border-purple-300/60 shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex-shrink-0 w-6 h-6 rounded-full bg-purple-600 flex items-center justify-center">
                      <svg
                        className="w-4 h-4 text-white"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path
                          fillRule="evenodd"
                          d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <span className="text-gray-800 font-bold">
                      Early Access to Sales
                    </span>
                  </div>
                  <div className="flex items-center gap-3 px-5 py-3 rounded-xl bg-gradient-to-br from-pink-50 to-pink-100 border-2 border-pink-300/60 shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex-shrink-0 w-6 h-6 rounded-full bg-pink-600 flex items-center justify-center">
                      <svg
                        className="w-4 h-4 text-white"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path
                          fillRule="evenodd"
                          d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <span className="text-gray-800 font-bold">
                      Weekly Updates & Tips
                    </span>
                  </div>
                </div>

                {emailSubscribed ? (
                  <div className="bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200/60 rounded-2xl p-8 max-w-md mx-auto shadow-md animate-fade-in">
                    <div className="flex items-center justify-center gap-3 mb-4">
                      <div className="w-16 h-16 rounded-full bg-gradient-to-br from-green-400 to-emerald-500 flex items-center justify-center shadow-lg transform scale-100 animate-bounce">
                        <FiCheck className="w-8 h-8 text-white font-bold" />
                      </div>
                    </div>
                    <h3 className="text-2xl sm:text-3xl font-bold mb-2 bg-gradient-to-r from-green-600 to-emerald-700 bg-clip-text text-transparent">
                      Success! 🎉
                    </h3>
                    <p className="text-gray-700 font-medium mb-2">
                      Check your email for a special welcome offer!
                    </p>
                    <p className="text-sm text-gray-600 mb-6">
                      We've sent you an exclusive 15% discount code
                    </p>
                    <button
                      onClick={() => {
                        setEmailSubscribed(false);
                        setSubscribeEmail("");
                      }}
                      className="w-full px-6 py-3 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 hover:from-blue-700 hover:via-purple-700 hover:to-pink-700 text-white rounded-xl font-semibold transition-all duration-300 shadow-md hover:shadow-lg transform hover:scale-105"
                    >
                      Subscribe Another Email
                    </button>
                  </div>
                ) : (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (subscribeEmail) {
                        setEmailSubscribed(true);
                      }
                    }}
                    className="flex flex-col sm:flex-row gap-3 max-w-2xl mx-auto"
                  >
                    <div className="flex-1 relative group">
                      <input
                        type="email"
                        placeholder="Enter your email address"
                        value={subscribeEmail}
                        onChange={(e) => setSubscribeEmail(e.target.value)}
                        required
                        className="w-full px-6 py-4 text-gray-900 rounded-xl font-medium placeholder-gray-500 bg-white border-2 border-gray-200 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-200 transition-all shadow-sm group-hover:border-blue-300 group-hover:shadow-md"
                      />
                    </div>
                    <button
                      type="submit"
                      className="group px-8 py-4 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 hover:from-blue-700 hover:via-purple-700 hover:to-pink-700 text-white font-bold rounded-xl shadow-lg hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-blue-300 focus:ring-offset-2 transition-all duration-300 active:scale-95 flex items-center justify-center gap-2 whitespace-nowrap transform hover:scale-105"
                    >
                      Subscribe Now
                      <FiArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                    </button>
                  </form>
                )}

                {/* Trust indicators */}
                <div className="mt-10 pt-8 border-t border-gray-200/50">
                  <p className="text-xs sm:text-sm text-gray-600 mb-4">
                    🔒 We respect your privacy. Unsubscribe anytime.
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-6 text-gray-600">
                    <div className="flex items-center gap-2">
                      <svg
                        className="w-4 h-4 text-green-600"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path
                          fillRule="evenodd"
                          d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                      <span className="text-xs sm:text-sm font-medium">
                        Secure
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <svg
                        className="w-4 h-4 text-green-600"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path
                          fillRule="evenodd"
                          d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                      <span className="text-xs sm:text-sm font-medium">
                        No Spam
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <svg
                        className="w-4 h-4 text-green-600"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path
                          fillRule="evenodd"
                          d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                      <span className="text-xs sm:text-sm font-medium">
                        Instant Updates
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom gradient bar */}
            <div className="h-1.5 bg-gradient-to-r from-pink-600 via-purple-600 to-blue-600"></div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;

import React, { useState, useEffect } from "react";
import { apiService } from "../services/api";
import { Product, Order } from "../types";
import {
  FiPackage,
  FiShoppingBag,
  FiEdit,
  FiTrash2,
  FiEye,
  FiPlus,
  FiDollarSign,
  FiBarChart2,
  FiUsers,
  FiTrendingUp,
  FiChevronRight,
  FiCheckCircle,
  FiTruck,
  FiClock,
  FiCalendar,
} from "react-icons/fi";
import { MdOutlineInventory, MdOutlineLocalShipping } from "react-icons/md";
import { RiSparklingFill } from "react-icons/ri";

const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"products" | "orders">("products");
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Load data with error handling
    try {
      const loadedProducts = apiService.getProducts();
      const loadedOrders = apiService.getOrders();

      console.log("Products loaded:", loadedProducts.length);
      console.log("Orders loaded:", loadedOrders.length);

      setProducts(loadedProducts);

      // Sort orders by date (newest first)
      const sortedOrders = loadedOrders.sort(
        (a, b) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
      );

      setOrders(sortedOrders);

      // If no orders from API, show sample data for demo
      if (sortedOrders.length === 0) {
        console.log("No orders found, using sample data");
        const sampleOrders = getSampleOrders();
        setOrders(sampleOrders);
      }
    } catch (error) {
      console.error("Error loading data:", error);
      // Fallback to sample data
      setProducts(apiService.getProducts());
      setOrders(getSampleOrders());
    } finally {
      setLoading(false);
    }
  }, []);

  // Sample orders for demo when API returns empty
  const getSampleOrders = (): Order[] => {
    const sampleProducts =
      products.length > 0
        ? products.slice(0, 3)
        : [
            {
              id: "1",
              name: "Sample Product 1",
              price: 99.99,
              image:
                "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400",
              category: "Electronics",
              description: "",
              rating: 4.5,
              stock: 10,
            },
            {
              id: "2",
              name: "Sample Product 2",
              price: 149.99,
              image:
                "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w-400",
              category: "Electronics",
              description: "",
              rating: 4.2,
              stock: 15,
            },
          ];

    return [
      {
        id: "ORD-001",
        userId: "user1",
        items: [
          {
            id: sampleProducts[0]?.id || "1",
            name: sampleProducts[0]?.name || "Wireless Headphones",
            price: sampleProducts[0]?.price || 99.99,
            quantity: 2,
            image:
              sampleProducts[0]?.image ||
              "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400",
          },
        ],
        total: 199.98,
        status: "delivered",
        shippingAddress: {
          street: "123 Main St",
          city: "New York",
          state: "NY",
          zipCode: "10001",
          country: "USA",
        },
        createdAt: new Date(Date.now() - 86400000 * 2).toISOString(), // 2 days ago
      },
      {
        id: "ORD-002",
        userId: "user2",
        items: [
          {
            id: sampleProducts[1]?.id || "2",
            name: sampleProducts[1]?.name || "Smart Watch",
            price: sampleProducts[1]?.price || 149.99,
            quantity: 1,
            image:
              sampleProducts[1]?.image ||
              "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400",
          },
          {
            id: sampleProducts[0]?.id || "1",
            name: sampleProducts[0]?.name || "Wireless Headphones",
            price: sampleProducts[0]?.price || 99.99,
            quantity: 1,
            image:
              sampleProducts[0]?.image ||
              "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400",
          },
        ],
        total: 249.98,
        status: "shipped",
        shippingAddress: {
          street: "456 Oak Ave",
          city: "Los Angeles",
          state: "CA",
          zipCode: "90001",
          country: "USA",
        },
        createdAt: new Date(Date.now() - 86400000).toISOString(), // 1 day ago
      },
      {
        id: "ORD-003",
        userId: "user3",
        items: [
          {
            id: sampleProducts[0]?.id || "1",
            name: sampleProducts[0]?.name || "Wireless Headphones",
            price: sampleProducts[0]?.price || 99.99,
            quantity: 3,
            image:
              sampleProducts[0]?.image ||
              "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400",
          },
        ],
        total: 299.97,
        status: "pending",
        shippingAddress: {
          street: "789 Pine Rd",
          city: "Chicago",
          state: "IL",
          zipCode: "60601",
          country: "USA",
        },
        createdAt: new Date().toISOString(), // Today
      },
    ];
  };

  const handleDeleteProduct = (id: string) => {
    if (
      confirm(
        "Are you sure you want to delete this product? This action cannot be undone.",
      )
    ) {
      apiService.deleteProduct(id);
      setProducts(apiService.getProducts());
    }
  };

  const handleUpdateStatus = (orderId: string, status: Order["status"]) => {
    apiService.updateOrderStatus(orderId, status);
    setOrders((prevOrders) =>
      prevOrders
        .map((order) => (order.id === orderId ? { ...order, status } : order))
        .sort(
          (a, b) =>
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
        ),
    );
  };

  // Calculate stats
  const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);
  const totalOrders = orders.length;
  const totalProducts = products.length;
  const pendingOrders = orders.filter((o) => o.status === "pending").length;

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 text-white">
        {/* Background Bubbles */}
        <div className="absolute inset-0">
          <div className="absolute top-20 right-10 w-72 h-72 bg-gradient-to-br from-blue-500/30 to-purple-500/20 rounded-full blur-3xl animate-pulse"></div>
          <div
            className="absolute bottom-10 left-10 w-96 h-96 bg-gradient-to-br from-purple-500/30 to-pink-500/20 rounded-full blur-3xl animate-pulse"
            style={{ animationDelay: "1s" }}
          ></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full max-w-4xl h-64 bg-gradient-to-r from-blue-500/20 to-purple-500/20 blur-3xl"></div>

          {/* Floating Bubbles */}
          <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-white/40 rounded-full animate-bounce"></div>
          <div
            className="absolute top-1/3 right-1/3 w-3 h-3 bg-white/30 rounded-full animate-bounce"
            style={{ animationDelay: "0.5s" }}
          ></div>
          <div
            className="absolute bottom-1/4 left-1/3 w-2 h-2 bg-white/40 rounded-full animate-bounce"
            style={{ animationDelay: "1s" }}
          ></div>
          <div
            className="absolute top-1/2 right-1/4 w-3 h-3 bg-white/30 rounded-full animate-bounce"
            style={{ animationDelay: "1.5s" }}
          ></div>
        </div>

        {/* Shiny Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-white/10 via-transparent to-white/10"></div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-28 lg:py-36">
          <div className="text-center">
            {/* Premium Badge */}
            <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-gradient-to-r from-white/20 to-white/10 backdrop-blur-md border border-white/30 mb-10 animate-slideInUp">
              <RiSparklingFill className="w-4 h-4 text-yellow-300 animate-pulse" />
              <span className="text-sm font-bold text-white/95 tracking-wider">
                ADMIN DASHBOARD
              </span>
              <div className="w-2 h-2 bg-gradient-to-r from-yellow-300 to-yellow-400 rounded-full"></div>
            </div>

            {/* Main Heading */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 leading-tight tracking-tight animate-slideInUp">
              <span className="relative">
                Control Center
                <span className="absolute -top-2 -right-6">
                  <FiBarChart2 className="w-6 h-6 text-yellow-300 animate-spin-slow" />
                </span>
              </span>
              <br />
              <span className="bg-gradient-to-r from-white via-blue-100 to-purple-100 bg-clip-text text-transparent">
                Manage & Monitor
              </span>
            </h1>

            {/* Description */}
            <p
              className="text-base sm:text-lg lg:text-xl text-white/90 max-w-3xl mx-auto leading-relaxed mb-12 animate-slideInUp"
              style={{ animationDelay: "0.1s" }}
            >
              Monitor your store performance, manage inventory, and process
              orders from a single dashboard.
            </p>
          </div>
        </div>

        {/* Bottom Wave Transition */}
        <div className="absolute -bottom-1 left-0 right-0">
          <svg
            className="w-full h-12 sm:h-16"
            viewBox="0 0 1200 120"
            preserveAspectRatio="none"
          >
            <path
              fill="rgb(249 250 251)"
              d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z"
              opacity=".25"
            ></path>
            <path
              fill="rgb(249 250 251)"
              d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z"
              opacity=".5"
            ></path>
            <path
              fill="rgb(249 250 251)"
              d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z"
            ></path>
          </svg>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20 -mt-2">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl p-6 border border-blue-100 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 font-medium mb-2">
                  Total Revenue
                </p>
                <p className="text-3xl font-bold text-gray-900">
                  ${totalRevenue.toFixed(2)}
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 flex items-center justify-center">
                <FiDollarSign className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6 border border-purple-100 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 font-medium mb-2">
                  Total Orders
                </p>
                <p className="text-3xl font-bold text-gray-900">
                  {totalOrders}
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center">
                <FiPackage className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-pink-50 to-rose-50 rounded-2xl p-6 border border-pink-100 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 font-medium mb-2">
                  Total Products
                </p>
                <p className="text-3xl font-bold text-gray-900">
                  {totalProducts}
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 flex items-center justify-center">
                <MdOutlineInventory className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-2xl p-6 border border-emerald-100 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 font-medium mb-2">
                  Pending Orders
                </p>
                <p className="text-3xl font-bold text-gray-900">
                  {pendingOrders}
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 flex items-center justify-center">
                <FiClock className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="mb-8">
          <div className="flex items-center gap-6 mb-8">
            <h2 className="text-2xl font-bold text-gray-900">
              Management Panel
            </h2>
            <div className="flex bg-gradient-to-r from-gray-50 to-gray-100 p-1 rounded-2xl">
              <button
                onClick={() => setActiveTab("products")}
                className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-sm transition-all duration-300 ${
                  activeTab === "products"
                    ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg"
                    : "text-gray-500 hover:text-gray-700"
                }`}
              >
                <FiShoppingBag className="w-4 h-4" />
                Products
              </button>
              <button
                onClick={() => setActiveTab("orders")}
                className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-sm transition-all duration-300 ${
                  activeTab === "orders"
                    ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg"
                    : "text-gray-500 hover:text-gray-700"
                }`}
              >
                <FiPackage className="w-4 h-4" />
                Orders
              </button>
            </div>
          </div>
        </div>

        {activeTab === "products" ? (
          <div className="bg-white rounded-2xl shadow-xl border border-gray-200 overflow-hidden">
            {/* Table Header */}
            <div className="bg-gradient-to-r from-gray-50 to-white p-6 border-b border-gray-200 flex flex-col sm:flex-row justify-between items-center gap-4">
              <h2 className="text-xl font-bold text-gray-900 flex items-center gap-3">
                <FiShoppingBag className="w-5 h-5 text-blue-500" />
                Inventory Management
              </h2>
              <button
                className="group flex items-center gap-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white px-5 py-3 rounded-xl text-sm font-bold hover:shadow-xl transition-all duration-300 hover:scale-105"
                onClick={() => alert("Add product modal would open here!")}
              >
                <FiPlus className="w-4 h-4" />
                New Product
                <FiChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>

            {/* Products Table */}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gradient-to-r from-gray-50 to-gray-100">
                    <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">
                      Product
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">
                      Category
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">
                      Price
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">
                      Stock
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">
                      Rating
                    </th>
                    <th className="px-6 py-4 text-right text-xs font-bold text-gray-600 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {products.length > 0 ? (
                    products.map((p, index) => (
                      <tr
                        key={p.id}
                        className="hover:bg-gray-50 transition-colors animate-slideInUp"
                        style={{ animationDelay: `${index * 50}ms` }}
                      >
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <img
                              src={p.image}
                              className="w-14 h-14 rounded-lg object-cover border border-gray-200 shadow-sm"
                              alt={p.name}
                              onError={(e) => {
                                (e.target as HTMLImageElement).src =
                                  "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400";
                              }}
                            />
                            <div>
                              <p className="font-semibold text-gray-900">
                                {p.name}
                              </p>
                              <p className="text-xs text-gray-500 truncate max-w-xs">
                                {p.description?.substring(0, 50) ||
                                  "No description"}
                                ...
                              </p>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className="px-3 py-1 text-xs font-medium rounded-full bg-gradient-to-r from-gray-50 to-gray-100 text-gray-600">
                            {p.category}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-lg font-bold text-gray-900">
                            ${p.price.toFixed(2)}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span
                            className={`px-3 py-1.5 rounded-lg text-sm font-bold ${
                              p.stock < 10
                                ? "bg-gradient-to-r from-red-50 to-rose-50 text-red-600 border border-red-200"
                                : p.stock < 20
                                  ? "bg-gradient-to-r from-amber-50 to-orange-50 text-amber-600 border border-amber-200"
                                  : "bg-gradient-to-r from-green-50 to-emerald-50 text-green-600 border border-green-200"
                            }`}
                          >
                            {p.stock} units
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-1">
                            <FiTrendingUp className="w-4 h-4 text-green-500" />
                            <span className="font-semibold text-gray-900">
                              {p.rating}
                            </span>
                            <span className="text-gray-400">/5</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex items-center justify-end gap-3">
                            <button className="group flex items-center gap-1 text-blue-600 hover:text-blue-700 text-sm font-semibold">
                              <FiEdit className="w-4 h-4" />
                              Edit
                            </button>
                            <button
                              onClick={() => handleDeleteProduct(p.id)}
                              className="group flex items-center gap-1 text-red-600 hover:text-red-700 text-sm font-semibold"
                            >
                              <FiTrash2 className="w-4 h-4" />
                              Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={6} className="px-6 py-12 text-center">
                        <div className="text-gray-500">
                          No products found. Add some products to get started.
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {orders.length > 0 ? (
              orders.map((order, index) => (
                <div
                  key={order.id}
                  className="bg-white rounded-2xl border border-gray-200 shadow-lg overflow-hidden animate-slideInUp"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  {/* Order Header */}
                  <div className="bg-gradient-to-r from-gray-50 to-gray-100 p-6 border-b border-gray-200">
                    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                      <div className="flex flex-wrap gap-6">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-blue-500 to-cyan-500 flex items-center justify-center">
                            <FiPackage className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <p className="text-xs font-bold text-gray-500 uppercase">
                              Order ID
                            </p>
                            <p className="font-bold text-gray-900">
                              #{order.id}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center">
                            <FiCalendar className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <p className="text-xs font-bold text-gray-500 uppercase">
                              Order Date
                            </p>
                            <p className="text-sm font-semibold text-gray-900">
                              {new Date(order.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-pink-500 to-rose-500 flex items-center justify-center">
                            <FiDollarSign className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <p className="text-xs font-bold text-gray-500 uppercase">
                              Total Amount
                            </p>
                            <p className="text-lg font-bold text-gray-900">
                              ${order.total.toFixed(2)}
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Status Selector */}
                      <div className="flex items-center gap-4">
                        <select
                          value={order.status}
                          onChange={(e) =>
                            handleUpdateStatus(
                              order.id,
                              e.target.value as Order["status"],
                            )
                          }
                          className="bg-gradient-to-r from-gray-50 to-gray-100 border border-gray-300 text-gray-700 rounded-xl px-4 py-2.5 text-sm font-semibold focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:outline-none"
                        >
                          <option value="pending">⏳ Pending</option>
                          <option value="paid">✅ Paid</option>
                          <option value="shipped">🚚 Shipped</option>
                          <option value="delivered">📦 Delivered</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* Order Details */}
                  <div className="p-6">
                    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                      <div>
                        <p className="text-sm text-gray-500 mb-2">
                          Items ({order.items.length})
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {order.items.map((item, idx) => (
                            <div
                              key={idx}
                              className="flex items-center gap-2 bg-gray-50 rounded-lg px-3 py-2"
                            >
                              <img
                                src={item.image}
                                alt={item.name}
                                className="w-8 h-8 rounded-md object-cover"
                                onError={(e) => {
                                  (e.target as HTMLImageElement).src =
                                    "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400";
                                }}
                              />
                              <span className="text-sm font-medium text-gray-700">
                                {item.name}
                              </span>
                              <span className="text-xs text-gray-500">
                                x{item.quantity}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <button className="group flex items-center gap-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white px-5 py-2.5 rounded-xl text-sm font-bold hover:shadow-lg transition-all duration-300">
                          <FiEye className="w-4 h-4" />
                          View Details
                          <FiChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                        </button>
                        <button className="flex items-center gap-2 px-5 py-2.5 text-gray-600 font-semibold rounded-xl border border-gray-200 hover:bg-gray-50 transition-all duration-300">
                          <FiTruck className="w-4 h-4" />
                          Track
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12 bg-white rounded-2xl border border-gray-200">
                <div className="w-20 h-20 rounded-full bg-gradient-to-r from-gray-100 to-gray-200 flex items-center justify-center mx-auto mb-4">
                  <FiPackage className="w-10 h-10 text-gray-400" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  No Orders Yet
                </h3>
                <p className="text-gray-600 max-w-md mx-auto mb-6">
                  No orders have been placed yet. Orders will appear here once
                  customers start shopping.
                </p>
              </div>
            )}
          </div>
        )}

        {/* Quick Stats */}
        <div className="mt-12 pt-8 border-t border-gray-200">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl border border-blue-100 text-center">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 flex items-center justify-center mx-auto mb-4">
                <FiTrendingUp className="w-6 h-6 text-white" />
              </div>
              <h4 className="font-bold text-gray-900 mb-2">Performance</h4>
              <p className="text-gray-600 text-sm">
                Monitor real-time analytics
              </p>
            </div>

            <div className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl border border-purple-100 text-center">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center mx-auto mb-4">
                <MdOutlineLocalShipping className="w-6 h-6 text-white" />
              </div>
              <h4 className="font-bold text-gray-900 mb-2">Shipping</h4>
              <p className="text-gray-600 text-sm">
                Manage deliveries & tracking
              </p>
            </div>

            <div className="p-6 bg-gradient-to-br from-pink-50 to-rose-50 rounded-2xl border border-pink-100 text-center">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 flex items-center justify-center mx-auto mb-4">
                <FiUsers className="w-6 h-6 text-white" />
              </div>
              <h4 className="font-bold text-gray-900 mb-2">Customers</h4>
              <p className="text-gray-600 text-sm">View customer insights</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;

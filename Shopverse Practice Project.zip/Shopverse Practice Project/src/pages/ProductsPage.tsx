import React, { useState } from "react";
import ProductCard from "../components/ProductCard";
import { apiService } from "../services/api";
import { Product, CartItem } from "../types";
import { useDebounce } from "../hooks/useDebounce";
import { useProductFilter } from "../hooks/useProductFilter";
import {
  FiSearch,
  FiFilter,
  FiChevronDown,
  FiStar,
  FiShoppingBag,
} from "react-icons/fi";
import {
  MdOutlineElectricalServices,
  MdOutlineDiscount,
  MdOutlineLocalShipping,
  MdOutlineVerified,
} from "react-icons/md";
import { GiClothes } from "react-icons/gi";
import { IoHomeOutline, IoFitnessOutline } from "react-icons/io5";
import { RiEmotionHappyLine, RiSparklingFill } from "react-icons/ri";

interface ProductsPageProps {
  addToCart: (item: CartItem) => void;
}

const ProductsPage: React.FC<ProductsPageProps> = ({ addToCart }) => {
  const products: Product[] = apiService.getProducts();
  const [search, setSearch] = useState("");
  const [selectedSort, setSelectedSort] = useState("featured");
  const [showFilters, setShowFilters] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // 🔥 Debounced search
  const debouncedSearch = useDebounce(search, 300);

  // 🔁 Reused filter logic from hooks
  const filteredProducts = useProductFilter({
    products,
    searchQuery: debouncedSearch,
  });

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (selectedSort) {
      case "price-low":
        return a.price - b.price;
      case "price-high":
        return b.price - a.price;
      case "rating":
        return b.rating - a.rating;
      default:
        return 0;
    }
  });

  const categories = [
    {
      name: "Electronics",
      icon: <MdOutlineElectricalServices className="w-5 h-5" />,
      color: "from-blue-500 to-blue-400",
      bg: "bg-gradient-to-br from-blue-500/10 to-blue-400/5",
      border: "border-blue-200",
    },
    {
      name: "Fashion",
      icon: <GiClothes className="w-5 h-5" />,
      color: "from-purple-500 to-pink-400",
      bg: "bg-gradient-to-br from-purple-500/10 to-pink-400/5",
      border: "border-purple-200",
    },
    {
      name: "Home",
      icon: <IoHomeOutline className="w-5 h-5" />,
      color: "from-pink-500 to-rose-400",
      bg: "bg-gradient-to-br from-pink-500/10 to-rose-400/5",
      border: "border-pink-200",
    },
    {
      name: "Sports",
      icon: <IoFitnessOutline className="w-5 h-5" />,
      color: "from-blue-400 to-cyan-400",
      bg: "bg-gradient-to-br from-blue-400/10 to-cyan-400/5",
      border: "border-blue-200",
    },
    {
      name: "Beauty",
      icon: <RiEmotionHappyLine className="w-5 h-5" />,
      color: "from-purple-400 to-violet-400",
      bg: "bg-gradient-to-br from-purple-400/10 to-violet-400/5",
      border: "border-purple-200",
    },
  ];

  const categorizedProducts = selectedCategory
    ? sortedProducts.filter((product) => product.category === selectedCategory)
    : sortedProducts;

  return (
    <div className="bg-gradient-to-b from-gray-50 to-white min-h-screen">
      {/* ENHANCED HERO SECTION */}
      <div className="relative overflow-hidden bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 text-white">
        {/* Enhanced Background Effects */}
        <div className="absolute inset-0">
          <div className="absolute top-20 right-10 w-72 h-72 bg-gradient-to-br from-white/15 to-white/5 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-10 left-10 w-96 h-96 bg-gradient-to-br from-white/10 to-white/5 rounded-full blur-3xl"></div>
          <div className="absolute top-1/3 left-1/4 w-64 h-64 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-full blur-3xl"></div>
          <div className="absolute bottom-1/3 right-1/4 w-80 h-80 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-full blur-3xl"></div>

          {/* Floating Particles */}
          <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-white/40 rounded-full animate-bounce"></div>
          <div
            className="absolute top-1/3 right-1/3 w-3 h-3 bg-white/30 rounded-full animate-bounce"
            style={{ animationDelay: "0.5s" }}
          ></div>
          <div
            className="absolute bottom-1/4 left-1/3 w-2 h-2 bg-white/40 rounded-full animate-bounce"
            style={{ animationDelay: "1s" }}
          ></div>
          <div
            className="absolute top-1/2 right-1/4 w-3 h-3 bg-white/30 rounded-full animate-bounce"
            style={{ animationDelay: "1.5s" }}
          ></div>
        </div>

        {/* Shiny Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-white/5 via-transparent to-white/5"></div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-28">
          <div className="text-center max-w-4xl mx-auto">
            {/* Premium Badge with Sparkle */}
            <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-gradient-to-r from-white/20 to-white/10 backdrop-blur-md border border-white/30 mb-8 animate-slideInUp shadow-lg">
              <RiSparklingFill className="w-4 h-4 text-yellow-300 animate-pulse" />
              <span className="text-sm font-bold text-white/95 tracking-wider">
                PREMIUM COLLECTION
              </span>
              <div className="w-2 h-2 bg-gradient-to-r from-yellow-300 to-yellow-400 rounded-full"></div>
            </div>

            {/* Enhanced Main Heading */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 leading-tight tracking-tight animate-slideInUp">
              <span className="relative">
                Explore Our
                <span className="absolute -top-2 -right-6">
                  <FiStar className="w-6 h-6 text-yellow-300 animate-spin-slow" />
                </span>
              </span>
              <br />
              <span className="bg-gradient-to-r from-white via-blue-100 to-purple-100 bg-clip-text text-transparent">
                Exclusive Collections
              </span>
            </h1>

            {/* Enhanced Subtitle */}
            <p
              className="text-base sm:text-lg lg:text-xl text-white/90 max-w-2xl mx-auto leading-relaxed mb-10 animate-slideInUp"
              style={{ animationDelay: "0.1s" }}
            >
              Discover meticulously curated products that blend
              <span className="font-semibold text-white">
                {" "}
                exceptional quality{" "}
              </span>
              with
              <span className="font-semibold text-white"> timeless design</span>
            </p>

            {/* Stats Row */}
            <div
              className="grid grid-cols-2 sm:grid-cols-4 gap-6 max-w-2xl mx-auto mb-12 animate-slideInUp"
              style={{ animationDelay: "0.2s" }}
            >
              <div className="text-center p-4 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20">
                <div className="text-2xl font-bold text-white mb-1">500+</div>
                <div className="text-xs text-white/70 uppercase tracking-wide">
                  Products
                </div>
              </div>
              <div className="text-center p-4 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20">
                <div className="text-2xl font-bold text-white mb-1">4.8★</div>
                <div className="text-xs text-white/70 uppercase tracking-wide">
                  Rating
                </div>
              </div>
              <div className="text-center p-4 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20">
                <div className="text-2xl font-bold text-white mb-1">24/7</div>
                <div className="text-xs text-white/70 uppercase tracking-wide">
                  Support
                </div>
              </div>
              <div className="text-center p-4 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20">
                <div className="text-2xl font-bold text-white mb-1">Free</div>
                <div className="text-xs text-white/70 uppercase tracking-wide">
                  Shipping
                </div>
              </div>
            </div>

            {/* Trust Badges */}
            <div
              className="flex flex-wrap items-center justify-center gap-4 mb-8 animate-slideInUp"
              style={{ animationDelay: "0.3s" }}
            >
              <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20">
                <MdOutlineVerified className="w-4 h-4 text-green-300" />
                <span className="text-xs font-medium text-white/90">
                  Quality Guaranteed
                </span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20">
                <MdOutlineLocalShipping className="w-4 h-4 text-blue-300" />
                <span className="text-xs font-medium text-white/90">
                  Fast Delivery
                </span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20">
                <MdOutlineDiscount className="w-4 h-4 text-purple-300" />
                <span className="text-xs font-medium text-white/90">
                  Best Price
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Wave Transition */}
        <div className="absolute -bottom-1 left-0 right-0">
          <svg
            className="w-full h-12 sm:h-16"
            viewBox="0 0 1200 120"
            preserveAspectRatio="none"
          >
            <path
              fill="rgb(249 250 251)"
              d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z"
              opacity=".25"
            ></path>
            <path
              fill="rgb(249 250 251)"
              d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z"
              opacity=".5"
            ></path>
            <path
              fill="rgb(249 250 251)"
              d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z"
            ></path>
          </svg>
        </div>
      </div>

      {/* CONTENT */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-8 sm:py-12 lg:py-16 -mt-2">
        {/* SEARCH & FILTER BAR */}
        <div className="space-y-4 sm:space-y-0 sm:flex sm:items-center sm:justify-between gap-4 mb-8 sm:mb-12">
          {/* Search Box */}
          <div className="relative flex-1 min-w-0">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/5 to-purple-500/5 rounded-xl blur-sm"></div>
            <FiSearch className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5 z-10" />
            <input
              type="text"
              placeholder="Search products..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="relative w-full pl-12 pr-4 py-3 sm:py-4 text-sm sm:text-base border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:outline-none transition-all duration-300 shadow-sm hover:shadow-md bg-white z-20"
            />
          </div>

          {/* Sort Dropdown */}
          <div className="relative min-w-fit">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2 px-4 sm:px-6 py-3 sm:py-4 bg-white border border-gray-200 rounded-xl hover:border-blue-300 hover:bg-blue-50 transition-all duration-300 shadow-sm text-sm sm:text-base font-medium text-gray-700 hover:shadow-md"
            >
              <FiFilter className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="hidden sm:inline">Sort</span>
              <FiChevronDown
                className={`w-4 h-4 sm:w-5 sm:h-5 transition-transform duration-300 ${showFilters ? "rotate-180" : ""}`}
              />
            </button>

            {showFilters && (
              <div className="absolute top-full right-0 mt-2 w-48 bg-white border border-gray-200 rounded-xl shadow-xl z-10 animate-slideDown overflow-hidden">
                <div className="py-2">
                  {[
                    { value: "featured", label: "Featured", icon: "🌟" },
                    {
                      value: "price-low",
                      label: "Price: Low to High",
                      icon: "↗️",
                    },
                    {
                      value: "price-high",
                      label: "Price: High to Low",
                      icon: "↘️",
                    },
                    { value: "rating", label: "Highest Rated", icon: "⭐" },
                  ].map((option) => (
                    <button
                      key={option.value}
                      onClick={() => {
                        setSelectedSort(option.value);
                        setShowFilters(false);
                      }}
                      className={`w-full text-left px-4 py-3 text-sm transition-all duration-200 flex items-center gap-3 hover:bg-gray-50 ${
                        selectedSort === option.value
                          ? "bg-gradient-to-r from-blue-50 to-blue-100 text-blue-600 font-semibold border-r-4 border-blue-500"
                          : "text-gray-700"
                      }`}
                    >
                      <span className="text-base">{option.icon}</span>
                      <span>{option.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* CATEGORY TAGS */}
        <div className="mb-8 sm:mb-12">
          <div className="flex items-center gap-3 mb-4">
            <span className="text-xs sm:text-sm font-semibold text-gray-600 uppercase tracking-wide">
              Browse Categories
            </span>
            <div className="flex-1 h-px bg-gradient-to-r from-gray-300 to-transparent"></div>
            <FiShoppingBag className="w-4 h-4 text-gray-400" />
          </div>
          <div className="flex flex-wrap gap-2 sm:gap-3">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`flex items-center gap-2 px-4 sm:px-5 py-2.5 sm:py-3 rounded-xl text-xs sm:text-sm font-medium border transition-all duration-300 shadow-sm hover:shadow-md ${
                selectedCategory === null
                  ? "bg-gradient-to-r from-blue-500 to-purple-500 text-white border-blue-500 shadow-blue-200"
                  : "bg-white border-gray-200 text-gray-700 hover:border-blue-300 hover:bg-blue-50 hover:text-blue-600"
              }`}
            >
              <span>All Products</span>
              {selectedCategory === null && (
                <RiSparklingFill className="w-3 h-3 animate-pulse" />
              )}
            </button>

            {categories.map((cat) => (
              <button
                key={cat.name}
                onClick={() => setSelectedCategory(cat.name)}
                className={`flex items-center gap-2 px-3 sm:px-4 py-2 sm:py-2.5 rounded-xl text-xs sm:text-sm font-medium border transition-all duration-300 shadow-sm hover:shadow-md ${
                  selectedCategory === cat.name
                    ? `${cat.bg} ${cat.border} font-semibold`
                    : "bg-white border-gray-200 text-gray-700 hover:border-blue-300 hover:bg-blue-50 hover:text-blue-600"
                }`}
              >
                {cat.icon}
                <span className="hidden xs:inline">{cat.name}</span>
                {selectedCategory === cat.name && (
                  <div
                    className={`w-2 h-2 rounded-full bg-gradient-to-r ${cat.color}`}
                  ></div>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* PRODUCTS COUNT & FILTER INFO */}
        <div className="mb-6 sm:mb-8 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl border border-blue-100">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <p className="text-sm text-gray-600 font-medium">
                Showing{" "}
                <span className="font-bold text-gray-900">
                  {categorizedProducts.length}
                </span>{" "}
                of {products.length} products
                {selectedCategory && (
                  <span className="text-blue-600 ml-2">
                    in {selectedCategory}
                  </span>
                )}
              </p>
              <p className="text-xs text-gray-500 mt-1">
                Sorted by:{" "}
                <span className="font-medium text-gray-700">
                  {selectedSort === "featured" && "Featured"}
                  {selectedSort === "price-low" && "Price: Low to High"}
                  {selectedSort === "price-high" && "Price: High to Low"}
                  {selectedSort === "rating" && "Highest Rated"}
                </span>
              </p>
            </div>
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span>All items are in stock</span>
            </div>
          </div>
        </div>

        {/* PRODUCTS GRID */}
        {categorizedProducts.length > 0 ? (
          <div className="grid grid-cols-2 xs:grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4 lg:gap-6">
            {categorizedProducts.map((product, idx) => (
              <div
                key={product.id}
                className="animate-fade-in"
                style={{
                  animationDelay: `${idx * 50}ms`,
                }}
              >
                <ProductCard product={product} onAddToCart={addToCart} />
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-16 sm:py-24">
            <div className="relative inline-flex items-center justify-center w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-gradient-to-br from-blue-100 to-purple-100 mb-6">
              <FiSearch className="w-12 h-12 sm:w-14 sm:h-14 text-blue-500" />
              <div className="absolute inset-0 rounded-full border-4 border-white/50 animate-ping"></div>
            </div>
            <h3 className="text-xl sm:text-2xl lg:text-3xl font-bold text-gray-900 mb-2 sm:mb-3 bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
              No products found
            </h3>
            <p className="text-sm sm:text-base text-gray-600 max-w-md mx-auto mb-6 sm:mb-8">
              {selectedCategory
                ? `No ${selectedCategory.toLowerCase()} products match "${search}". Try different keywords or browse other categories.`
                : `Try adjusting your search keywords or explore different categories`}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => setSearch("")}
                className="inline-flex items-center gap-2 px-6 sm:px-8 py-3 sm:py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300 hover:shadow-lg active:scale-95 text-sm sm:text-base shadow-md"
              >
                <FiSearch className="w-4 h-4" />
                Clear Search
              </button>
              <button
                onClick={() => setSelectedCategory(null)}
                className="inline-flex items-center gap-2 px-6 sm:px-8 py-3 sm:py-4 bg-white border border-gray-200 text-gray-700 font-semibold rounded-xl hover:border-blue-300 hover:bg-blue-50 hover:text-blue-600 transition-all duration-300 hover:shadow-lg active:scale-95 text-sm sm:text-base shadow-sm"
              >
                <FiShoppingBag className="w-4 h-4" />
                View All Products
              </button>
            </div>
          </div>
        )}

        {/* Bottom Info Section */}
        {categorizedProducts.length > 0 && categorizedProducts.length >= 4 && (
          <div className="mt-12 pt-8 border-t border-gray-200">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              <div className="flex items-center gap-4 p-4 bg-gradient-to-r from-blue-50 to-blue-100/50 rounded-xl border border-blue-100">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-r from-blue-500 to-blue-400 flex items-center justify-center">
                  <MdOutlineLocalShipping className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Free Shipping</h4>
                  <p className="text-sm text-gray-600">On orders over $50</p>
                </div>
              </div>
              <div className="flex items-center gap-4 p-4 bg-gradient-to-r from-purple-50 to-purple-100/50 rounded-xl border border-purple-100">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-r from-purple-500 to-purple-400 flex items-center justify-center">
                  <MdOutlineVerified className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">
                    Quality Checked
                  </h4>
                  <p className="text-sm text-gray-600">
                    Every product inspected
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-4 p-4 bg-gradient-to-r from-pink-50 to-pink-100/50 rounded-xl border border-pink-100">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-r from-pink-500 to-pink-400 flex items-center justify-center">
                  <MdOutlineDiscount className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Best Price</h4>
                  <p className="text-sm text-gray-600">30-day price match</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductsPage;

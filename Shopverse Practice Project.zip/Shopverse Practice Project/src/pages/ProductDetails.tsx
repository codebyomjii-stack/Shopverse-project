import React, { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { apiService } from "../services/api";
import { Product, CartItem } from "../types";
import {
  FiShoppingCart,
  FiStar,
  FiPackage,
  FiTruck,
  FiShield,
  FiArrowLeft,
  FiArrowRight,
  FiPlus,
  FiMinus,
  FiHeart,
  FiShare2,
  FiCheck,
} from "react-icons/fi";
import { MdOutlineLocalShipping, MdOutlineVerified } from "react-icons/md";
import { RiSparklingFill } from "react-icons/ri";

interface ProductDetailsProps {
  addToCart: (item: CartItem) => void;
}

const ProductDetails: React.FC<ProductDetailsProps> = ({ addToCart }) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);
  const [isWishlist, setIsWishlist] = useState(false);
  const [showNotification, setShowNotification] = useState(false);

  useEffect(() => {
    if (id) {
      const data = apiService.getProductById(id);
      if (data) setProduct(data);
    }
  }, [id]);

  // Product images for gallery (using same image for demo, in real app would have multiple)
  const productImages = product
    ? [product.image, product.image, product.image]
    : [];

  const handleAddToCart = () => {
    if (product) {
      addToCart({ ...product, quantity });
      setShowNotification(true);
      setTimeout(() => setShowNotification(false), 3000);
    }
  };

  const handleBuyNow = () => {
    if (product) {
      addToCart({ ...product, quantity });
      navigate("/cart");
    }
  };

  if (!product) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Product not found
          </h2>
          <button
            onClick={() => navigate("/")}
            className="mt-4 text-blue-600 hover:text-blue-700 font-semibold inline-flex items-center gap-2"
          >
            <FiArrowLeft className="w-4 h-4" />
            Return to Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Product Notification */}
      {showNotification && (
        <div className="fixed top-4 right-4 z-50 animate-slideInUp">
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-2xl p-4 shadow-xl">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-r from-green-500 to-emerald-500 flex items-center justify-center">
                <FiCheck className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="font-bold text-green-700">Added to Cart!</p>
                <p className="text-sm text-green-600">
                  {quantity} × {product.name}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 text-white">
        {/* Background Bubbles */}
        <div className="absolute inset-0">
          <div className="absolute top-20 right-10 w-72 h-72 bg-gradient-to-br from-blue-500/30 to-purple-500/20 rounded-full blur-3xl animate-pulse"></div>
          <div
            className="absolute bottom-10 left-10 w-96 h-96 bg-gradient-to-br from-purple-500/30 to-pink-500/20 rounded-full blur-3xl animate-pulse"
            style={{ animationDelay: "1s" }}
          ></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full max-w-4xl h-64 bg-gradient-to-r from-blue-500/20 to-purple-500/20 blur-3xl"></div>

          {/* Floating Bubbles */}
          <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-white/40 rounded-full animate-bounce"></div>
          <div
            className="absolute top-1/3 right-1/3 w-3 h-3 bg-white/30 rounded-full animate-bounce"
            style={{ animationDelay: "0.5s" }}
          ></div>
          <div
            className="absolute bottom-1/4 left-1/3 w-2 h-2 bg-white/40 rounded-full animate-bounce"
            style={{ animationDelay: "1s" }}
          ></div>
          <div
            className="absolute top-1/2 right-1/4 w-3 h-3 bg-white/30 rounded-full animate-bounce"
            style={{ animationDelay: "1.5s" }}
          ></div>
        </div>

        {/* Shiny Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-white/10 via-transparent to-white/10"></div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-28">
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8">
            <div className="text-center lg:text-left">
              {/* Premium Badge */}
              <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-gradient-to-r from-white/20 to-white/10 backdrop-blur-md border border-white/30 mb-6">
                <RiSparklingFill className="w-4 h-4 text-yellow-300 animate-pulse" />
                <span className="text-sm font-bold text-white/95 tracking-wider">
                  PREMIUM PRODUCT
                </span>
                <div className="w-2 h-2 bg-gradient-to-r from-yellow-300 to-yellow-400 rounded-full"></div>
              </div>

              {/* Breadcrumb */}
              <div className="flex items-center justify-center lg:justify-start gap-2 text-white/70 text-sm mb-4">
                <Link to="/" className="hover:text-white transition-colors">
                  Home
                </Link>
                <FiArrowRight className="w-3 h-3" />
                <Link
                  to="/products"
                  className="hover:text-white transition-colors"
                >
                  Products
                </Link>
                <FiArrowRight className="w-3 h-3" />
                <span className="text-white">{product.category}</span>
              </div>

              {/* Product Name */}
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4 leading-tight">
                {product.name}
              </h1>

              {/* Rating & Stock */}
              <div className="flex flex-wrap items-center gap-4 justify-center lg:justify-start">
                <div className="flex items-center gap-2">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <FiStar
                        key={i}
                        className={`w-5 h-5 ${i < Math.floor(product.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                      />
                    ))}
                  </div>
                  <span className="font-bold text-white/90">
                    {product.rating}/5
                  </span>
                </div>
                <div
                  className={`px-3 py-1.5 rounded-full text-sm font-bold ${
                    product.stock > 10
                      ? "bg-green-500/20 text-green-300 border border-green-500/30"
                      : product.stock > 0
                        ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                        : "bg-red-500/20 text-red-300 border border-red-500/30"
                  }`}
                >
                  {product.stock > 0
                    ? `${product.stock} in stock`
                    : "Out of Stock"}
                </div>
                <span className="text-2xl font-bold text-white">
                  ${product.price.toFixed(2)}
                </span>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex flex-col gap-4">
              <button
                onClick={() => setIsWishlist(!isWishlist)}
                className={`flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-bold transition-all duration-300 ${
                  isWishlist
                    ? "bg-gradient-to-r from-pink-500 to-rose-500 text-white"
                    : "bg-white/10 backdrop-blur-sm border border-white/20 text-white hover:bg-white/20"
                }`}
              >
                <FiHeart
                  className={`w-5 h-5 ${isWishlist ? "fill-white" : ""}`}
                />
                {isWishlist ? "Saved" : "Save to Wishlist"}
              </button>
              <button className="flex items-center justify-center gap-2 px-6 py-3 bg-white/10 backdrop-blur-sm border border-white/20 text-white rounded-xl font-bold hover:bg-white/20 transition-all duration-300">
                <FiShare2 className="w-5 h-5" />
                Share
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Wave Transition */}
        <div className="absolute -bottom-1 left-0 right-0">
          <svg
            className="w-full h-12 sm:h-16"
            viewBox="0 0 1200 120"
            preserveAspectRatio="none"
          >
            <path
              fill="rgb(249 250 251)"
              d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z"
              opacity=".25"
            ></path>
            <path
              fill="rgb(249 250 251)"
              d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z"
              opacity=".5"
            ></path>
            <path
              fill="rgb(249 250 251)"
              d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z"
            ></path>
          </svg>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20 -mt-2">
        <div className="flex flex-col lg:flex-row gap-12">
          {/* Left Column - Product Images */}
          <div className="lg:w-1/2">
            <div className="bg-white rounded-2xl shadow-xl border border-gray-200 overflow-hidden">
              {/* Main Image */}
              <div className="aspect-square bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-8">
                <img
                  src={productImages[selectedImage]}
                  alt={product.name}
                  className="max-h-[400px] w-auto rounded-xl shadow-lg hover:scale-105 transition-transform duration-500"
                />
              </div>

              {/* Thumbnail Gallery */}
              <div className="p-6 border-t border-gray-200">
                <div className="flex gap-4 overflow-x-auto pb-2">
                  {productImages.map((img, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedImage(index)}
                      className={`flex-shrink-0 w-20 h-20 rounded-xl border-2 overflow-hidden transition-all duration-300 ${
                        selectedImage === index
                          ? "border-blue-500 shadow-lg scale-105"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      <img
                        src={img}
                        alt={`View ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Product Features */}
            <div className="mt-6 grid grid-cols-2 gap-4">
              <div className="p-4 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl border border-blue-100">
                <FiPackage className="w-8 h-8 text-blue-500 mb-2" />
                <h4 className="font-bold text-gray-900 mb-1">Free Shipping</h4>
                <p className="text-sm text-gray-600">On orders over $50</p>
              </div>
              <div className="p-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl border border-purple-100">
                <MdOutlineVerified className="w-8 h-8 text-purple-500 mb-2" />
                <h4 className="font-bold text-gray-900 mb-1">
                  1-Year Warranty
                </h4>
                <p className="text-sm text-gray-600">Quality guaranteed</p>
              </div>
            </div>
          </div>

          {/* Right Column - Product Details */}
          <div className="lg:w-1/2">
            <div className="bg-white rounded-2xl shadow-xl border border-gray-200 p-8">
              {/* Category Badge */}
              <div className="mb-6">
                <span className="px-4 py-2 bg-gradient-to-r from-blue-50 to-purple-50 text-blue-600 font-bold rounded-full text-sm">
                  {product.category}
                </span>
              </div>

              {/* Description */}
              <div className="mb-8">
                <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <div className="w-1.5 h-6 bg-gradient-to-b from-blue-500 to-purple-500 rounded-full"></div>
                  Product Description
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {product.description}
                  <br />
                  <br />
                  Our products are sourced from premium suppliers ensuring high
                  quality and durability. Experience the difference with our{" "}
                  {product.category.toLowerCase()} selection.
                </p>
              </div>

              {/* Specifications */}
              <div className="mb-8">
                <h4 className="font-bold text-gray-900 mb-4">Specifications</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 bg-gray-50 rounded-xl">
                    <p className="text-sm text-gray-500">Category</p>
                    <p className="font-semibold text-gray-900">
                      {product.category}
                    </p>
                  </div>
                  <div className="p-3 bg-gray-50 rounded-xl">
                    <p className="text-sm text-gray-500">Stock Status</p>
                    <p
                      className={`font-semibold ${product.stock > 0 ? "text-green-600" : "text-red-600"}`}
                    >
                      {product.stock > 0 ? "In Stock" : "Out of Stock"}
                    </p>
                  </div>
                  <div className="p-3 bg-gray-50 rounded-xl">
                    <p className="text-sm text-gray-500">Customer Rating</p>
                    <p className="font-semibold text-gray-900">
                      {product.rating}/5 Stars
                    </p>
                  </div>
                  <div className="p-3 bg-gray-50 rounded-xl">
                    <p className="text-sm text-gray-500">Delivery</p>
                    <p className="font-semibold text-gray-900">2-5 Days</p>
                  </div>
                </div>
              </div>

              {/* Quantity & Actions */}
              <div className="space-y-6">
                <div>
                  <h4 className="font-bold text-gray-900 mb-3">Quantity</h4>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center bg-gradient-to-r from-gray-50 to-white border border-gray-200 rounded-2xl">
                      <button
                        onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                        className="px-4 py-3 text-xl font-bold text-gray-400 hover:text-blue-600 transition-colors"
                      >
                        <FiMinus />
                      </button>
                      <span className="px-6 py-3 font-bold text-gray-900 text-xl min-w-[60px] text-center">
                        {quantity}
                      </span>
                      <button
                        onClick={() => setQuantity((q) => q + 1)}
                        className="px-4 py-3 text-xl font-bold text-gray-400 hover:text-blue-600 transition-colors"
                      >
                        <FiPlus />
                      </button>
                    </div>
                    <div className="text-2xl font-bold text-gray-900">
                      ${(product.price * quantity).toFixed(2)}
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row gap-4">
                  <button
                    onClick={handleAddToCart}
                    disabled={product.stock <= 0}
                    className="group flex-1 bg-gradient-to-r from-blue-600 to-purple-600 text-white py-4 rounded-xl font-bold text-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 disabled:opacity-70 disabled:cursor-not-allowed disabled:hover:scale-100"
                  >
                    <div className="flex items-center justify-center gap-3">
                      <FiShoppingCart className="w-5 h-5" />
                      {product.stock > 0 ? "Add to Cart" : "Out of Stock"}
                    </div>
                  </button>

                  <button
                    onClick={handleBuyNow}
                    disabled={product.stock <= 0}
                    className="group flex-1 bg-gradient-to-r from-green-600 to-emerald-600 text-white py-4 rounded-xl font-bold text-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 disabled:opacity-70 disabled:cursor-not-allowed disabled:hover:scale-100"
                  >
                    <div className="flex items-center justify-center gap-3">
                      <span>Buy Now</span>
                      <FiArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </button>
                </div>
              </div>

              {/* Trust Badges */}
              <div className="mt-8 pt-8 border-t border-gray-200">
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center">
                    <FiShield className="w-6 h-6 text-green-500 mx-auto mb-2" />
                    <p className="text-xs text-gray-600">Secure Payment</p>
                  </div>
                  <div className="text-center">
                    <FiTruck className="w-6 h-6 text-blue-500 mx-auto mb-2" />
                    <p className="text-xs text-gray-600">Fast Delivery</p>
                  </div>
                  <div className="text-center">
                    <MdOutlineLocalShipping className="w-6 h-6 text-purple-500 mx-auto mb-2" />
                    <p className="text-xs text-gray-600">Easy Returns</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Related Info */}
            <div className="mt-6 p-6 bg-gradient-to-br from-gray-50 to-white rounded-2xl border border-gray-200">
              <h4 className="font-bold text-gray-900 mb-4">Need Help?</h4>
              <p className="text-gray-600 text-sm mb-4">
                Our support team is available 24/7 to answer any questions about
                this product.
              </p>
              <button className="inline-flex items-center gap-2 text-blue-600 font-medium hover:text-blue-700 transition-colors">
                <span>Contact Support</span>
                <FiArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;

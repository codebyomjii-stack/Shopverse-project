import {
  SAMPLE_PRODUCTS,
  FEATURED_PRODUCTS,
  SAMPLE_USERS,
  SAMPLE_ORDERS,
} from "../../mockData";
import { Product, User, Order, CartItem } from "../types";

const STORAGE_KEYS = {
  PRODUCTS: "sv_products",
  USERS: "sv_users",
  ORDERS: "sv_orders",
  CURRENT_USER: "sv_current_user",
  CART: "sv_cart",
};

// Initialize Storage
const initStorage = () => {
  // Always reinitialize products to get latest data
  localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(SAMPLE_PRODUCTS));
  if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(SAMPLE_USERS));
  }
  if (!localStorage.getItem(STORAGE_KEYS.ORDERS)) {
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(SAMPLE_ORDERS));
  }
};

initStorage();

export const apiService = {
  // Auth
  getCurrentUser: (): User | null => {
    const user = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    return user ? JSON.parse(user) : null;
  },
  login: (email: string): User | null => {
    const users: User[] = JSON.parse(
      localStorage.getItem(STORAGE_KEYS.USERS) || "[]",
    );
    const user = users.find((u) => u.email === email);
    if (user) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    }
    return user || null;
  },
  logout: () => {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
  },
  signup: (userData: Partial<User>): User => {
    const users: User[] = JSON.parse(
      localStorage.getItem(STORAGE_KEYS.USERS) || "[]",
    );
    const newUser: User = {
      id: `u${Date.now()}`,
      name: userData.name || "Unknown",
      email: userData.email || "",
      role: "user",
      createdAt: new Date().toISOString(),
    };
    users.push(newUser);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(newUser));
    return newUser;
  },

  // Products
  getProducts: (): Product[] => {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.PRODUCTS) || "[]");
  },
  getFeaturedProducts: (): Product[] => {
    return FEATURED_PRODUCTS;
  },
  getProductById: (id: string): Product | undefined => {
    const products = apiService.getProducts();
    return products.find((p) => p.id === id);
  },
  updateProduct: (product: Product) => {
    const products = apiService.getProducts();
    const index = products.findIndex((p) => p.id === product.id);
    if (index !== -1) {
      products[index] = product;
      localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
    }
  },
  deleteProduct: (id: string) => {
    const products = apiService.getProducts();
    const filtered = products.filter((p) => p.id !== id);
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(filtered));
  },
  addProduct: (product: Omit<Product, "id">) => {
    const products = apiService.getProducts();
    const newProduct = { ...product, id: Date.now().toString() };
    products.push(newProduct);
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
    return newProduct;
  },

  // Cart
  getCart: (): CartItem[] => {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.CART) || "[]");
  },
  saveCart: (items: CartItem[]) => {
    localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(items));
  },

  // Orders
  getOrders: (): Order[] => {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.ORDERS) || "[]");
  },
  getUserOrders: (userId: string): Order[] => {
    const orders = apiService.getOrders();
    return orders.filter((o) => o.userId === userId);
  },
  placeOrder: (order: Omit<Order, "id" | "createdAt">): Order => {
    const orders = apiService.getOrders();
    const newOrder: Order = {
      ...order,
      id: `ORD-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    orders.push(newOrder);
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
    // Clear cart after order
    localStorage.setItem(STORAGE_KEYS.CART, "[]");
    return newOrder;
  },
  updateOrderStatus: (orderId: string, status: Order["status"]) => {
    const orders = apiService.getOrders();
    const index = orders.findIndex((o) => o.id === orderId);
    if (index !== -1) {
      orders[index].status = status;
      localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
    }
  },
};

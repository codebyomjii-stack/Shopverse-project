import React, { useState, useEffect } from "react";
import ProductCard from "../components/ProductCard";
import { apiService } from "../services/api";
import { Product, Category, CartItem } from "../types";
import { useDebounce } from "../hooks/useDebounce";

interface HomeProps {
  addToCart: (item: CartItem) => void;
}

const Home: React.FC<HomeProps> = ({ addToCart }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<Category>("All");
  const [searchQuery, setSearchQuery] = useState("");

  const debouncedSearch = useDebounce(searchQuery, 300);

  const categories: Category[] = [
    "All",
    "Electronics",
    "Fashion",
    "Home",
    "Sports",
    "Beauty",
  ];

  // Load products once
  useEffect(() => {
    const data = apiService.getProducts();
    setProducts(data);
    setFilteredProducts(data);
  }, []);

  // Filter products on category or search change
  useEffect(() => {
    let result = products;

    if (selectedCategory !== "All") {
      result = result.filter((p) => p.category === selectedCategory);
    }

    if (debouncedSearch) {
      result = result.filter((p) =>
        p.name.toLowerCase().includes(debouncedSearch.toLowerCase())
      );
    }

    setFilteredProducts(result);
  }, [selectedCategory, debouncedSearch, products]);

  return (
    <div className="bg-[#F9FAFB] text-[#111827] w-full min-h-screen">
      {/* ================= HERO SECTION ================= */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#2563EB] via-[#4F46E5] to-[#7C3AED]" />
        <div className="absolute inset-0 bg-black/30" />
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-blue-400/30 rounded-full blur-3xl" />
        <div className="absolute top-1/3 -right-24 w-96 h-96 bg-purple-400/30 rounded-full blur-3xl" />

        <div className="relative min-h-[92vh] flex items-center px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-2 gap-14 items-center">
            {/* ===== HERO TEXT ===== */}
            <div className="text-center lg:text-left text-white space-y-7">
              <span className="inline-block px-5 py-2 rounded-full text-sm font-semibold bg-white/15 backdrop-blur border border-white/20">
                🛍️ Premium Online Shopping
              </span>

              <h1 className="text-4xl sm:text-5xl xl:text-6xl font-extrabold leading-tight">
                Elevate Your Lifestyle
                <span className="block mt-3 text-3xl sm:text-4xl xl:text-5xl text-white/90">
                  with ShopVerse
                </span>
              </h1>

              <p className="text-white/85 text-base sm:text-lg xl:text-xl max-w-xl mx-auto lg:mx-0">
                Discover a curated collection of premium products designed for
                modern living — quality, style, and unbeatable value.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start pt-3">
                <button
                  onClick={() =>
                    window.scrollTo({ top: 600, behavior: "smooth" })
                  }
                  className="px-9 py-3.5 rounded-full font-semibold bg-white text-[#3B82F6] hover:bg-gradient-to-r hover:from-blue-500 hover:to-purple-600 hover:text-white transition-all shadow-lg"
                >
                  Shop Now
                </button>

                <button className="px-9 py-3.5 rounded-full font-semibold border border-white/60 hover:bg-white/10 transition">
                  Browse Collections
                </button>
              </div>
            </div>

            {/* ===== HERO IMAGE ===== */}
            <div className="relative flex justify-center lg:justify-end">
              <div className="absolute inset-0 bg-white/10 rounded-[2rem] blur-2xl scale-95" />
              <div className="relative bg-white/10 backdrop-blur-xl border border-white/20 rounded-[2rem] p-4 shadow-2xl">
                <img
                  src="/1.jpg"
                  alt="ShopVerse Hero"
                  className="w-full max-w-xs sm:max-w-sm md:max-w-md lg:max-w-lg xl:max-w-xl object-contain"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ================= SEARCH & CATEGORY ================= */}
      <section className="py-14 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-5 mb-10">
          {/* Search Bar */}
          <div className="flex-1 relative max-w-md w-full">
            <input
              type="text"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full px-5 py-3.5 rounded-2xl border border-gray-200 bg-white text-sm text-gray-800
                   placeholder-gray-400 shadow-sm
                   focus:outline-none focus:ring-2 focus:ring-[#3B82F6]/40 focus:border-[#3B82F6]
                   transition"
            />
          </div>

          {/* Categories */}
          <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-5 py-2.5 rounded-full whitespace-nowrap text-sm font-medium transition-all duration-200
            ${
              selectedCategory === cat
                ? "bg-[#3B82F6] text-white shadow-md shadow-blue-200/50 scale-[1.02]"
                : "bg-white text-[#111827] border border-gray-200 hover:bg-[#EFF6FF] hover:text-[#3B82F6] hover:border-blue-200"
            }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* ================= PRODUCTS SECTION ================= */}
      <section className="py-10">
        <div className="px-4 sm:px-6 lg:px-10 xl:px-16 2xl:px-24">
          <h2 className="text-3xl font-extrabold mb-6">Featured Products</h2>

          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map((product) => (
                <div
                  key={product.id}
                  className="bg-white rounded-2xl border border-gray-200 shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-300"
                >
                  <ProductCard product={product} addToCart={addToCart} />
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-24">
              <h3 className="text-2xl font-semibold mb-2">No products found</h3>
              <p className="text-gray-500 mb-4">
                Try adjusting your search or filters.
              </p>
              <button
                onClick={() => {
                  setSearchQuery("");
                  setSelectedCategory("All");
                }}
                className="px-6 py-3 bg-[#3B82F6] text-white rounded-xl font-semibold hover:bg-gradient-to-r hover:from-blue-500 hover:to-purple-600 transition"
              >
                Reset Filters
              </button>
            </div>
          )}
        </div>
      </section>

      {/* ================= WHY CHOOSE US ================= */}
      <section className="py-16 bg-[#F9FAFB]">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-extrabold mb-12">
            Why Choose ShopVerse?
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { title: "Premium Quality", icon: "✔️" },
              { title: "Verified Sellers", icon: "🛡️" },
              { title: "Fast Shipping", icon: "🚚" },
              { title: "Best Price Guarantee", icon: "💰" },
            ].map((item, i) => (
              <div
                key={i}
                className="bg-white p-6 rounded-2xl shadow hover:shadow-lg transition"
              >
                <div className="text-3xl mb-2">{item.icon}</div>
                <h4 className="font-semibold">{item.title}</h4>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ================= TESTIMONIALS ================= */}
      <section className="py-16 bg-[#F9FAFB]">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-extrabold mb-12">Customer Reviews</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              "Amazing quality and service!",
              "Fast delivery and excellent support.",
              "Highly recommend ShopVerse!",
            ].map((review, i) => (
              <div
                key={i}
                className="bg-white p-6 rounded-2xl shadow hover:shadow-lg transition"
              >
                <p className="text-gray-700 mb-4">“{review}”</p>
                <div className="font-semibold text-gray-900">⭐⭐⭐⭐⭐</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ================= NEWSLETTER ================= */}
      <section className="py-16 bg-[#F9FAFB] text-center">
        <div className="max-w-md mx-auto">
          <h2 className="text-3xl font-extrabold mb-4">Stay Updated</h2>
          <p className="text-gray-600 mb-6">
            Subscribe to receive latest deals and offers.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <input
              type="email"
              placeholder="Enter your email"
              className="px-4 py-3 rounded-xl border border-gray-200 w-full"
            />
            <button className="px-6 py-3 rounded-xl bg-[#3B82F6] text-white font-semibold hover:bg-gradient-to-r hover:from-blue-500 hover:to-purple-600 transition">
              Subscribe
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;

import React from "react";
import { Link } from "react-router-dom";
import { CartItem } from "../types";
import {
  FiShoppingCart,
  FiTrash2,
  FiPlus,
  FiMinus,
  FiArrowRight,
  FiTruck,
  FiShield,
  FiClock,
  FiStar,
} from "react-icons/fi";
import { MdOutlineLocalShipping, MdOutlineVerified } from "react-icons/md";
import { RiSparklingFill } from "react-icons/ri";

interface CartPageProps {
  cart: CartItem[];
  removeFromCart: (id: string) => void;
  updateQuantity: (id: string, delta: number) => void;
}

const CartPage: React.FC<CartPageProps> = ({
  cart,
  removeFromCart,
  updateQuantity,
}) => {
  const subtotal = cart.reduce(
    (acc, item) => acc + item.price * item.quantity,
    0,
  );
  const shipping = subtotal > 0 ? (subtotal > 500 ? 0 : 25) : 0;
  const total = subtotal + shipping;

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
        {/* Hero Section for Empty Cart */}
        <div className="relative overflow-hidden bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 text-white">
          {/* Bubbles/Background Effects - Just like other pages */}
          <div className="absolute inset-0">
            <div className="absolute top-20 right-10 w-72 h-72 bg-gradient-to-br from-blue-500/30 to-purple-500/20 rounded-full blur-3xl animate-pulse"></div>
            <div
              className="absolute bottom-10 left-10 w-96 h-96 bg-gradient-to-br from-purple-500/30 to-pink-500/20 rounded-full blur-3xl animate-pulse"
              style={{ animationDelay: "1s" }}
            ></div>
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full max-w-4xl h-64 bg-gradient-to-r from-blue-500/20 to-purple-500/20 blur-3xl"></div>

            {/* Floating Bubbles */}
            <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-white/40 rounded-full animate-bounce"></div>
            <div
              className="absolute top-1/3 right-1/3 w-3 h-3 bg-white/30 rounded-full animate-bounce"
              style={{ animationDelay: "0.5s" }}
            ></div>
            <div
              className="absolute bottom-1/4 left-1/3 w-2 h-2 bg-white/40 rounded-full animate-bounce"
              style={{ animationDelay: "1s" }}
            ></div>
            <div
              className="absolute top-1/2 right-1/4 w-3 h-3 bg-white/30 rounded-full animate-bounce"
              style={{ animationDelay: "1.5s" }}
            ></div>
          </div>

          {/* Shiny Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-white/10 via-transparent to-white/10"></div>

          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-28 lg:py-36 text-center">
            {/* Premium Badge - Like other pages */}
            <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-gradient-to-r from-white/20 to-white/10 backdrop-blur-md border border-white/30 mb-10 animate-slideInUp">
              <RiSparklingFill className="w-4 h-4 text-yellow-300 animate-pulse" />
              <span className="text-sm font-bold text-white/95 tracking-wider">
                YOUR CART
              </span>
              <div className="w-2 h-2 bg-gradient-to-r from-yellow-300 to-yellow-400 rounded-full"></div>
            </div>

            {/* Main Heading - Like other pages */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 leading-tight tracking-tight animate-slideInUp">
              <span className="relative">
                Your Cart Awaits
                <span className="absolute -top-2 -right-6">
                  <FiShoppingCart className="w-6 h-6 text-yellow-300 animate-spin-slow" />
                </span>
              </span>
              <br />
              <span className="bg-gradient-to-r from-white via-blue-100 to-purple-100 bg-clip-text text-transparent">
                Premium Products
              </span>
            </h1>

            {/* Description */}
            <p
              className="text-base sm:text-lg lg:text-xl text-white/90 max-w-3xl mx-auto leading-relaxed mb-12 animate-slideInUp"
              style={{ animationDelay: "0.1s" }}
            >
              Looks like you haven't added anything to your cart yet. Explore
              our premium collection and find something extraordinary.
            </p>

            {/* Trust Indicators - Like other pages */}
            <div
              className="flex flex-wrap items-center justify-center gap-6 mb-10 animate-slideInUp"
              style={{ animationDelay: "0.2s" }}
            >
              <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20">
                <MdOutlineLocalShipping className="w-4 h-4 text-blue-300" />
                <span className="text-xs font-medium text-white/90">
                  Free Shipping
                </span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20">
                <MdOutlineVerified className="w-4 h-4 text-green-300" />
                <span className="text-xs font-medium text-white/90">
                  Secure Checkout
                </span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20">
                <FiClock className="w-4 h-4 text-purple-300" />
                <span className="text-xs font-medium text-white/90">
                  24/7 Support
                </span>
              </div>
            </div>

            {/* CTA Buttons */}
            <div
              className="flex flex-col sm:flex-row gap-4 justify-center animate-slideInUp"
              style={{ animationDelay: "0.3s" }}
            >
              <Link
                to="/"
                className="group relative px-8 py-4 bg-white text-blue-600 font-bold rounded-xl hover:shadow-2xl hover:shadow-white/20 transition-all duration-300 hover:scale-105"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-white to-white/80 rounded-xl opacity-0 group-hover:opacity-30 blur-xl transition-opacity duration-500"></div>
                <div className="relative flex items-center justify-center gap-3">
                  <span>Continue Shopping</span>
                  <FiArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </div>
              </Link>

              <Link
                to="/categories"
                className="px-8 py-4 bg-transparent border-2 border-white text-white font-bold rounded-xl hover:bg-white/10 transition-all duration-300 hover:scale-105"
              >
                Browse Categories
              </Link>
            </div>
          </div>

          {/* Bottom Wave Transition - Exactly like other pages */}
          <div className="absolute -bottom-1 left-0 right-0">
            <svg
              className="w-full h-12 sm:h-16"
              viewBox="0 0 1200 120"
              preserveAspectRatio="none"
            >
              <path
                fill="rgb(249 250 251)"
                d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z"
                opacity=".25"
              ></path>
              <path
                fill="rgb(249 250 251)"
                d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z"
                opacity=".5"
              ></path>
              <path
                fill="rgb(249 250 251)"
                d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z"
              ></path>
            </svg>
          </div>
        </div>

        {/* Features Section */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20 -mt-2">
          <div className="text-center mb-12">
            <h3 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4">
              Why Shop With Us?
            </h3>
            <p className="text-gray-600 max-w-2xl mx-auto text-lg">
              Discover the benefits of our premium shopping experience
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="p-6 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl border border-blue-100 text-center">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 flex items-center justify-center mx-auto mb-4">
                <FiTruck className="w-6 h-6 text-white" />
              </div>
              <h4 className="font-bold text-gray-900 mb-2">Fast Shipping</h4>
              <p className="text-gray-600 text-sm">
                2-5 business days delivery
              </p>
            </div>

            <div className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl border border-purple-100 text-center">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center mx-auto mb-4">
                <FiShield className="w-6 h-6 text-white" />
              </div>
              <h4 className="font-bold text-gray-900 mb-2">Secure Checkout</h4>
              <p className="text-gray-600 text-sm">Bank-level encryption</p>
            </div>

            <div className="p-6 bg-gradient-to-br from-pink-50 to-rose-50 rounded-2xl border border-pink-100 text-center">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 flex items-center justify-center mx-auto mb-4">
                <FiClock className="w-6 h-6 text-white" />
              </div>
              <h4 className="font-bold text-gray-900 mb-2">24/7 Support</h4>
              <p className="text-gray-600 text-sm">Always here to help</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Hero Section for Cart with Items */}
      <div className="relative overflow-hidden bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 text-white">
        {/* Bubbles/Background Effects - Just like other pages */}
        <div className="absolute inset-0">
          <div className="absolute top-20 right-10 w-72 h-72 bg-gradient-to-br from-blue-500/30 to-purple-500/20 rounded-full blur-3xl animate-pulse"></div>
          <div
            className="absolute bottom-10 left-10 w-96 h-96 bg-gradient-to-br from-purple-500/30 to-pink-500/20 rounded-full blur-3xl animate-pulse"
            style={{ animationDelay: "1s" }}
          ></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full max-w-4xl h-64 bg-gradient-to-r from-blue-500/20 to-purple-500/20 blur-3xl"></div>

          {/* Floating Bubbles */}
          <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-white/40 rounded-full animate-bounce"></div>
          <div
            className="absolute top-1/3 right-1/3 w-3 h-3 bg-white/30 rounded-full animate-bounce"
            style={{ animationDelay: "0.5s" }}
          ></div>
          <div
            className="absolute bottom-1/4 left-1/3 w-2 h-2 bg-white/40 rounded-full animate-bounce"
            style={{ animationDelay: "1s" }}
          ></div>
          <div
            className="absolute top-1/2 right-1/4 w-3 h-3 bg-white/30 rounded-full animate-bounce"
            style={{ animationDelay: "1.5s" }}
          ></div>
        </div>

        {/* Shiny Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-white/10 via-transparent to-white/10"></div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-28">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
            <div className="text-center lg:text-left">
              {/* Premium Badge - Like other pages */}
              <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-gradient-to-r from-white/20 to-white/10 backdrop-blur-md border border-white/30 mb-6">
                <RiSparklingFill className="w-4 h-4 text-yellow-300 animate-pulse" />
                <span className="text-sm font-bold text-white/95 tracking-wider">
                  YOUR CART
                </span>
                <div className="w-2 h-2 bg-gradient-to-r from-yellow-300 to-yellow-400 rounded-full"></div>
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4 leading-tight">
                Shopping Cart
                <br />
                <span className="bg-gradient-to-r from-cyan-300 via-blue-300 to-purple-300 bg-clip-text text-transparent">
                  {cart.length} Items
                </span>
              </h1>

              <p className="text-white/90 text-lg max-w-2xl">
                Review your selected items and proceed to checkout for a
                seamless shopping experience.
              </p>
            </div>

            <div className="text-center lg:text-right">
              <div className="text-3xl sm:text-4xl font-bold mb-2">
                ${total.toFixed(2)}
              </div>
              <p className="text-white/70 text-sm">Total Amount</p>
            </div>
          </div>
        </div>

        {/* Bottom Wave Transition - Exactly like other pages */}
        <div className="absolute -bottom-1 left-0 right-0">
          <svg
            className="w-full h-12 sm:h-16"
            viewBox="0 0 1200 120"
            preserveAspectRatio="none"
          >
            <path
              fill="rgb(249 250 251)"
              d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z"
              opacity=".25"
            ></path>
            <path
              fill="rgb(249 250 251)"
              d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z"
              opacity=".5"
            ></path>
            <path
              fill="rgb(249 250 251)"
              d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z"
            ></path>
          </svg>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20 -mt-2">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Cart Items List */}
          <div className="flex-grow space-y-6">
            {cart.map((item, index) => (
              <div
                key={item.id}
                className="group relative bg-white rounded-2xl p-6 shadow-lg border border-gray-200 hover:shadow-xl transition-all duration-300 flex flex-col sm:flex-row gap-6 items-center animate-slideInUp"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                {/* Product Image */}
                <div className="relative">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-32 h-32 object-cover rounded-2xl shadow-md"
                  />
                  {item.quantity > 1 && (
                    <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 text-white flex items-center justify-center text-sm font-bold shadow-lg">
                      {item.quantity}
                    </div>
                  )}
                </div>

                {/* Product Info */}
                <div className="flex-grow text-center sm:text-left">
                  <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                    {item.name}
                  </h3>
                  <div className="flex flex-wrap items-center gap-2 mb-3">
                    <span className="px-3 py-1 text-xs font-medium rounded-full bg-gradient-to-r from-blue-50 to-blue-100 text-blue-600 border border-blue-100">
                      {item.category}
                    </span>
                    <div className="flex items-center gap-1">
                      <FiStar className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                      <span className="text-sm text-gray-600">4.8</span>
                    </div>
                    <span className="text-lg font-bold text-gray-900">
                      ${item.price.toFixed(2)}
                    </span>
                  </div>

                  <button
                    onClick={() => removeFromCart(item.id)}
                    className="inline-flex items-center gap-2 text-red-500 text-sm font-medium hover:text-red-600 transition-colors"
                  >
                    <FiTrash2 className="w-4 h-4" />
                    Remove Item
                  </button>
                </div>

                {/* Quantity Controls */}
                <div className="flex items-center gap-6">
                  <div className="flex items-center bg-gradient-to-r from-gray-50 to-white border border-gray-200 rounded-2xl shadow-sm">
                    <button
                      onClick={() => updateQuantity(item.id, -1)}
                      className="px-4 py-2 text-xl font-bold text-gray-400 hover:text-blue-600 transition-colors"
                    >
                      <FiMinus />
                    </button>
                    <span className="px-4 py-2 font-bold text-gray-900 text-lg min-w-[60px] text-center">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateQuantity(item.id, 1)}
                      className="px-4 py-2 text-xl font-bold text-gray-400 hover:text-blue-600 transition-colors"
                    >
                      <FiPlus />
                    </button>
                  </div>

                  {/* Item Total */}
                  <div className="text-2xl font-bold text-gray-900 sm:w-32 text-center sm:text-right">
                    ${(item.price * item.quantity).toFixed(2)}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Order Summary */}
          <div className="lg:w-96">
            <div className="sticky top-24">
              <div className="bg-white rounded-2xl border border-gray-200 shadow-xl overflow-hidden">
                {/* Summary Header */}
                <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6">
                  <h2 className="text-xl font-bold flex items-center gap-3">
                    <FiShoppingCart className="w-5 h-5" />
                    Order Summary
                  </h2>
                </div>

                {/* Summary Details */}
                <div className="p-6 space-y-6">
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">
                        Subtotal ({cart.length} items)
                      </span>
                      <span className="text-lg font-bold text-gray-900">
                        ${subtotal.toFixed(2)}
                      </span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Shipping</span>
                      <span
                        className={`text-lg font-bold ${shipping === 0 ? "text-green-600" : "text-gray-900"}`}
                      >
                        {shipping === 0 ? "FREE" : `$${shipping.toFixed(2)}`}
                      </span>
                    </div>

                    {shipping > 0 && (
                      <div className="p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl border border-blue-100">
                        <p className="text-sm text-blue-600 font-medium">
                          🎉 Free shipping on orders over $500!
                        </p>
                      </div>
                    )}

                    <div className="border-t border-gray-200 pt-4">
                      <div className="flex justify-between items-center">
                        <span className="text-xl font-bold text-gray-900">
                          Total
                        </span>
                        <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                          ${total.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Checkout Button */}
                  <Link
                    to="/checkout"
                    className="group relative w-full bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 text-white text-center py-4 rounded-xl font-bold text-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 block"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 rounded-xl opacity-0 group-hover:opacity-30 blur-xl transition-opacity duration-500"></div>
                    <div className="relative flex items-center justify-center gap-3">
                      <span>Proceed to Checkout</span>
                      <FiArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </Link>

                  {/* Continue Shopping */}
                  <Link
                    to="/"
                    className="block w-full text-center py-3 text-gray-600 hover:text-blue-600 font-medium transition-colors"
                  >
                    ← Continue Shopping
                  </Link>
                </div>

                {/* Trust Badges */}
                <div className="border-t border-gray-100 p-6">
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <FiTruck className="w-6 h-6 text-blue-500 mx-auto mb-2" />
                      <p className="text-xs text-gray-500">Fast Delivery</p>
                    </div>
                    <div>
                      <FiShield className="w-6 h-6 text-green-500 mx-auto mb-2" />
                      <p className="text-xs text-gray-500">Secure Checkout</p>
                    </div>
                    <div>
                      <FiClock className="w-6 h-6 text-purple-500 mx-auto mb-2" />
                      <p className="text-xs text-gray-500">24/7 Support</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Discount Banner */}
              {subtotal < 500 && (
                <div className="mt-6 p-4 bg-gradient-to-r from-amber-50 to-orange-50 rounded-2xl border border-amber-200 shadow-sm">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 flex items-center justify-center shadow-md">
                      <span className="text-white font-bold">$</span>
                    </div>
                    <div>
                      <p className="font-bold text-gray-900">
                        Add ${(500 - subtotal).toFixed(2)} more for free
                        shipping!
                      </p>
                      <p className="text-sm text-gray-600">
                        You're almost there!
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Features Section */}
        <div className="mt-16 pt-12 border-t border-gray-200">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="p-6 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl border border-blue-100 text-center">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 flex items-center justify-center mx-auto mb-4">
                <FiTruck className="w-6 h-6 text-white" />
              </div>
              <h4 className="font-bold text-gray-900 mb-2">Fast Shipping</h4>
              <p className="text-gray-600 text-sm">
                2-5 business days delivery
              </p>
            </div>

            <div className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl border border-purple-100 text-center">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center mx-auto mb-4">
                <FiShield className="w-6 h-6 text-white" />
              </div>
              <h4 className="font-bold text-gray-900 mb-2">Secure Checkout</h4>
              <p className="text-gray-600 text-sm">Bank-level encryption</p>
            </div>

            <div className="p-6 bg-gradient-to-br from-pink-50 to-rose-50 rounded-2xl border border-pink-100 text-center">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 flex items-center justify-center mx-auto mb-4">
                <FiClock className="w-6 h-6 text-white" />
              </div>
              <h4 className="font-bold text-gray-900 mb-2">24/7 Support</h4>
              <p className="text-gray-600 text-sm">Always here to help</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartPage;

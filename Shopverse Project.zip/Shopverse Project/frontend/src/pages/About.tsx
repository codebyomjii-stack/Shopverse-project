import React from "react";
import {
  ShoppingBag,
  ShieldCheck,
  Truck,
  Users,
  Zap,
  Heart,
  Star,
  Clock,
  TrendingUp,
  Globe,
  Award,
  CheckCircle,
  ArrowRight,
  Sparkles,
} from "lucide-react";
import { RiSparklingFill } from "react-icons/ri";
import {
  FiArrowRight,
  FiStar,
  FiUsers,
  FiClock,
  FiCheckCircle,
  FiTrendingUp,
} from "react-icons/fi";
import { MdOutlineLocalShipping, MdOutlineVerified } from "react-icons/md";

const About: React.FC = () => {
  return (
    <div className="bg-gradient-to-b from-gray-50 to-white min-h-screen">
      {/* Enhanced Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 text-white">
        {/* Advanced Background Effects */}
        <div className="absolute inset-0">
          <div className="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-blue-500/30 to-blue-400/20 rounded-full blur-3xl animate-pulse"></div>
          <div
            className="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-br from-pink-500/30 to-pink-400/20 rounded-full blur-3xl animate-pulse"
            style={{ animationDelay: "1s" }}
          ></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-gradient-to-r from-blue-600/10 via-purple-600/10 to-pink-600/10 blur-3xl rounded-full"></div>

          {/* Floating Particles */}
          <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-white/40 rounded-full animate-bounce"></div>
          <div
            className="absolute top-1/3 right-1/3 w-3 h-3 bg-white/30 rounded-full animate-bounce"
            style={{ animationDelay: "0.5s" }}
          ></div>
          <div
            className="absolute bottom-1/4 left-1/3 w-2 h-2 bg-white/40 rounded-full animate-bounce"
            style={{ animationDelay: "1s" }}
          ></div>
          <div
            className="absolute top-1/2 right-1/4 w-3 h-3 bg-white/30 rounded-full animate-bounce"
            style={{ animationDelay: "1.5s" }}
          ></div>
        </div>

        {/* Shiny Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-white/10 via-transparent to-white/10"></div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-28 lg:py-36 text-center">
          {/* Premium Badge */}
          <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-gradient-to-r from-white/20 to-white/10 backdrop-blur-md border border-white/30 mb-10 animate-slideInUp">
            <RiSparklingFill className="w-4 h-4 text-yellow-300 animate-pulse" />
            <span className="text-sm font-bold text-white/95 tracking-wider">
              OUR STORY
            </span>
            <div className="w-2 h-2 bg-gradient-to-r from-yellow-300 to-yellow-400 rounded-full"></div>
          </div>

          {/* Enhanced Title */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 leading-tight tracking-tight animate-slideInUp">
            <span className="relative">
              Building The Future
              <span className="absolute -top-2 -right-6">
                <Star className="w-6 h-6 text-yellow-300 animate-spin-slow" />
              </span>
            </span>
            <br />
            <span className="bg-gradient-to-r from-white via-blue-100 to-purple-100 bg-clip-text text-transparent">
              Of Shopping
            </span>
          </h1>

          {/* Enhanced Description */}
          <p
            className="text-base sm:text-lg lg:text-xl text-white/90 max-w-3xl mx-auto leading-relaxed mb-12 animate-slideInUp"
            style={{ animationDelay: "0.1s" }}
          >
            We're redefining online shopping with a modern, secure, and
            <span className="font-semibold text-white"> customer-first </span>
            experience that connects people with premium products at exceptional
            value.
          </p>

          {/* Trust Indicators */}
          <div
            className="flex flex-wrap items-center justify-center gap-6 mb-10 animate-slideInUp"
            style={{ animationDelay: "0.2s" }}
          >
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20">
              <ShieldCheck className="w-4 h-4 text-green-300" />
              <span className="text-xs font-medium text-white/90">
                Secure Platform
              </span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20">
              <Award className="w-4 h-4 text-blue-300" />
              <span className="text-xs font-medium text-white/90">
                Quality First
              </span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20">
              <Globe className="w-4 h-4 text-purple-300" />
              <span className="text-xs font-medium text-white/90">
                Global Reach
              </span>
            </div>
          </div>
        </div>

        {/* Bottom Wave Transition */}
        <div className="absolute -bottom-1 left-0 right-0">
          <svg
            className="w-full h-12 sm:h-16"
            viewBox="0 0 1200 120"
            preserveAspectRatio="none"
          >
            <path
              fill="rgb(249 250 251)"
              d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z"
              opacity=".25"
            ></path>
            <path
              fill="rgb(249 250 251)"
              d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z"
              opacity=".5"
            ></path>
            <path
              fill="rgb(249 250 251)"
              d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z"
            ></path>
          </svg>
        </div>
      </section>

      {/* Enhanced Mission Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-24 -mt-2">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 items-center">
          <div className="order-2 lg:order-1">
            <div className="space-y-6 sm:space-y-8">
              {/* Premium Mission Badge */}
              <div className="inline-flex items-center gap-3 bg-gradient-to-r from-blue-50 to-indigo-50 px-6 py-3 rounded-full border border-blue-100">
                <Zap className="w-5 h-5 text-blue-600 animate-pulse" />
                <span className="text-sm font-bold text-blue-600 tracking-wider">
                  OUR MISSION
                </span>
                <Sparkles className="w-4 h-4 text-purple-500" />
              </div>

              {/* Enhanced Title */}
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 leading-tight">
                Redefining The
                <br />
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  Shopping Experience
                </span>
              </h2>

              {/* Enhanced Description */}
              <div className="space-y-4">
                <p className="text-lg text-gray-600 leading-relaxed">
                  Our mission is to make online shopping{" "}
                  <span className="font-semibold text-gray-900">
                    simple, fast, and reliable
                  </span>
                  . We carefully curate products across multiple categories and
                  ensure a seamless checkout and delivery experience.
                </p>
                <p className="text-lg text-gray-600 leading-relaxed">
                  We focus on{" "}
                  <span className="font-semibold text-gray-900">
                    quality, transparency, and long-term trust
                  </span>{" "}
                  with our customers. Every product is vetted, every transaction
                  is secure, and every delivery is tracked.
                </p>
              </div>

              {/* Enhanced CTA */}
              <div className="pt-6">
                <div className="flex items-center gap-3 text-lg font-semibold text-blue-600 group cursor-pointer">
                  <span>Discover our journey</span>
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-2 transition-transform duration-300" />
                </div>
              </div>
            </div>
          </div>

          {/* Enhanced Feature Cards */}
          <div className="order-1 lg:order-2">
            <div className="relative bg-gradient-to-br from-blue-600 to-purple-600 rounded-3xl p-8 space-y-6 text-white shadow-2xl">
              {/* Glow Effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20 blur-3xl rounded-3xl"></div>

              <div className="relative z-10">
                {[
                  {
                    icon: <ShieldCheck className="w-6 h-6" />,
                    title: "Secure Payments",
                    text: "Bank-level encryption for all transactions",
                    gradient: "from-blue-500 to-cyan-500",
                  },
                  {
                    icon: <Truck className="w-6 h-6" />,
                    title: "Fast Delivery",
                    text: "2-5 business days guaranteed",
                    gradient: "from-purple-500 to-pink-500",
                  },
                  {
                    icon: <ShoppingBag className="w-6 h-6" />,
                    title: "Premium Products",
                    text: "Only trusted brands and sellers",
                    gradient: "from-pink-500 to-rose-500",
                  },
                  {
                    icon: <Users className="w-6 h-6" />,
                    title: "24/7 Support",
                    text: "Always here to help you",
                    gradient: "from-cyan-500 to-blue-500",
                  },
                ].map((item, idx) => (
                  <div
                    key={idx}
                    className="group flex items-start gap-4 p-4 rounded-2xl hover:bg-white/10 transition-all duration-300"
                  >
                    <div
                      className={`flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-r ${item.gradient} flex items-center justify-center shadow-lg`}
                    >
                      {item.icon}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-bold text-lg mb-2 group-hover:text-blue-100 transition-colors">
                        {item.title}
                      </h4>
                      <p className="text-blue-100/80 leading-relaxed">
                        {item.text}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Core Values Section */}
      <section className="bg-gradient-to-b from-white to-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-24">
          <div className="text-center mb-16">
            {/* Premium Values Badge */}
            <div className="inline-flex items-center gap-3 bg-gradient-to-r from-purple-50 to-pink-50 px-6 py-3 rounded-full border border-purple-100 mb-6">
              <Award className="w-5 h-5 text-purple-600" />
              <span className="text-sm font-bold text-purple-600 tracking-wider">
                OUR VALUES
              </span>
              <Sparkles className="w-4 h-4 text-pink-500" />
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
              Principles That
              <br />
              <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Guide Us
              </span>
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              These core values shape every decision and define our commitment
              to excellence.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
            {[
              {
                title: "Trust",
                icon: "🤝",
                text: "Transparent pricing and honest product listings",
                gradient: "from-blue-500 to-indigo-500",
                bg: "from-blue-50 to-indigo-50",
                border: "border-blue-100",
              },
              {
                title: "Quality",
                icon: "⭐",
                text: "Only reliable and high-quality products",
                gradient: "from-purple-500 to-pink-500",
                bg: "from-purple-50 to-pink-50",
                border: "border-purple-100",
              },
              {
                title: "Innovation",
                icon: "⚡",
                text: "Continuously improving the experience",
                gradient: "from-cyan-500 to-blue-500",
                bg: "from-cyan-50 to-blue-50",
                border: "border-cyan-100",
              },
              {
                title: "Care",
                icon: "❤️",
                text: "Your satisfaction is our priority",
                gradient: "from-pink-500 to-rose-500",
                bg: "from-pink-50 to-rose-50",
                border: "border-pink-100",
              },
            ].map((item) => (
              <div
                key={item.title}
                className="group relative bg-white rounded-2xl p-8 text-center border border-gray-200 hover:border-transparent transition-all duration-500 transform hover:-translate-y-2 hover:shadow-2xl"
              >
                {/* Background Glow */}
                <div
                  className={`absolute inset-0 bg-gradient-to-br ${item.bg} rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10`}
                ></div>

                {/* Icon Container */}
                <div
                  className={`inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br ${item.bg} mb-6 group-hover:scale-110 transition-transform duration-500`}
                >
                  <span className="text-4xl">{item.icon}</span>
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-gray-900 mb-4 group-hover:text-gray-800 transition-colors">
                  {item.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">{item.text}</p>

                {/* Bottom Accent */}
                <div
                  className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${item.gradient} rounded-b-2xl transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500`}
                ></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Enhanced Stats Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-24">
        <div className="relative overflow-hidden bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 rounded-3xl p-8 sm:p-12 lg:p-16 text-white shadow-2xl">
          {/* Background Effects */}
          <div className="absolute inset-0">
            <div className="absolute top-0 left-0 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
          </div>

          <div className="relative z-10">
            <div className="text-center mb-12">
              <h3 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-4">
                Numbers That
                <br />
                <span className="bg-gradient-to-r from-cyan-300 via-blue-300 to-purple-300 bg-clip-text text-transparent">
                  Speak Volumes
                </span>
              </h3>
              <p className="text-blue-100 max-w-2xl mx-auto text-lg">
                Our growth reflects our commitment to excellence and customer
                satisfaction
              </p>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center">
              {[
                {
                  value: "10K+",
                  label: "Happy Customers",
                  icon: <Users className="w-6 h-6 mx-auto mb-3" />,
                },
                {
                  value: "5K+",
                  label: "Premium Products",
                  icon: <ShoppingBag className="w-6 h-6 mx-auto mb-3" />,
                },
                {
                  value: "99%",
                  label: "Satisfaction Rate",
                  icon: <Star className="w-6 h-6 mx-auto mb-3" />,
                },
                {
                  value: "24/7",
                  label: "Support",
                  icon: <Clock className="w-6 h-6 mx-auto mb-3" />,
                },
              ].map((stat) => (
                <div key={stat.label} className="group">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20 mb-4 group-hover:scale-110 transition-transform duration-300 mx-auto">
                    {stat.icon}
                  </div>
                  <p className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-2">
                    {stat.value}
                  </p>
                  <p className="text-blue-100 font-medium text-sm sm:text-base">
                    {stat.label}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced CTA Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-24">
        <div className="relative overflow-hidden bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 rounded-3xl p-8 sm:p-12 lg:p-16 text-center text-white">
          {/* Background Effects */}
          <div className="absolute inset-0">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
          </div>

          <div className="relative z-10">
            {/* Premium Badge */}
            <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/20 backdrop-blur-sm border border-white/30 mb-8">
              <Sparkles className="w-4 h-4 text-yellow-300 animate-pulse" />
              <span className="text-sm font-bold text-white/95">
                JOIN OUR COMMUNITY
              </span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6 leading-tight">
              Ready to Experience
              <br />
              <span className="bg-gradient-to-r from-cyan-300 via-blue-300 to-purple-300 bg-clip-text text-transparent">
                The Difference?
              </span>
            </h2>

            <p className="text-lg sm:text-xl text-blue-100 mb-10 max-w-2xl mx-auto leading-relaxed">
              Start your shopping journey today and discover why thousands
              choose us for quality and service.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="/products"
                className="group relative px-8 py-4 bg-white text-blue-600 font-bold rounded-xl hover:shadow-2xl hover:shadow-white/20 transition-all duration-300 hover:scale-105 active:scale-95"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-white to-white/80 rounded-xl opacity-0 group-hover:opacity-30 blur-xl transition-opacity duration-500"></div>
                <div className="relative flex items-center justify-center gap-3">
                  <ShoppingBag className="w-5 h-5" />
                  <span>Start Shopping</span>
                </div>
              </a>

              <a
                href="/categories"
                className="px-8 py-4 bg-transparent border-2 border-white text-white font-bold rounded-xl hover:bg-white/10 transition-all duration-300 hover:scale-105 active:scale-95"
              >
                <div className="flex items-center justify-center gap-3">
                  <span>Browse Categories</span>
                  <ArrowRight className="w-5 h-5" />
                </div>
              </a>
            </div>

            {/* Trust Badges */}
            <div className="flex flex-wrap items-center justify-center gap-8 mt-12 pt-12 border-t border-white/20">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-green-300" />
                <span className="text-sm">Secure Payment</span>
              </div>
              <div className="flex items-center gap-2">
                <Truck className="w-5 h-5 text-blue-300" />
                <span className="text-sm">Fast Delivery</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-purple-300" />
                <span className="text-sm">Quality Guarantee</span>
              </div>
              <div className="flex items-center gap-2">
                <Heart className="w-5 h-5 text-pink-300" />
                <span className="text-sm">Customer Care</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;

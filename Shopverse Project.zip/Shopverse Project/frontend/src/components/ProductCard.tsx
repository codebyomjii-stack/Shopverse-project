import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Product, CartItem } from "../types";
import { FiShoppingCart, FiHeart, FiStar, FiImage } from "react-icons/fi";

interface ProductCardProps {
  product: Product;
  onAddToCart: (item: CartItem) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart }) => {
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [isAdded, setIsAdded] = useState(false);
  const [imgError, setImgError] = useState(false);

  const handleAddToCart = () => {
    onAddToCart({ ...product, quantity: 1 });
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  const discount = Math.floor(Math.random() * 20) + 5;

  // Fallback image function
  const getFallbackImage = () => {
    // Category-based fallback images
    const fallbackImages: Record<string, string> = {
      Electronics:
        "https://images.unsplash.com/photo-1498049794561-7780e7231661?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
      Fashion:
        "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
      "Home & Kitchen":
        "https://images.unsplash.com/photo-1556228453-efd6c1ff04f6?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
      Beauty:
        "https://images.unsplash.com/photo-1596462502278-27bfdc403348?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
      Sports:
        "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
      Books:
        "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    };

    return (
      fallbackImages[product.category] ||
      "https://images.unsplash.com/photo-1556656793-08538906a9f8?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80"
    );
  };

  const imageUrl = imgError ? getFallbackImage() : product.image;

  return (
    <div className="h-full flex flex-col bg-white rounded-lg sm:rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-xl hover:shadow-blue-500/10 transition-all duration-300 group hover:border-blue-300">
      {/* Image Container */}
      <Link
        to={`/product/${product.id}`}
        className="block relative aspect-square xs:aspect-[5/4] sm:aspect-[4/3] overflow-hidden bg-gray-100"
      >
        {imgError ? (
          <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-gray-100 to-gray-200">
            <FiImage className="w-12 h-12 text-gray-400 mb-2" />
            <span className="text-xs text-gray-500 text-center px-2">
              {product.name}
            </span>
          </div>
        ) : (
          <img
            src={imageUrl}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
            onError={() => setImgError(true)}
            loading="lazy"
          />
        )}

        {/* Discount Badge */}
        <div className="absolute top-2 xs:top-3 left-2 xs:left-3 bg-gradient-to-r from-red-500 to-pink-500 text-white px-2 xs:px-3 py-1 rounded-md xs:rounded-full text-xs font-bold shadow-md">
          -{discount}%
        </div>

        {/* Category Badge */}
        <div className="absolute top-2 xs:top-3 right-2 xs:right-3 bg-white/95 backdrop-blur-sm px-2 xs:px-3 py-0.5 xs:py-1 rounded-md xs:rounded-full text-xs font-semibold text-blue-600 shadow-sm">
          {product.category}
        </div>

        {/* Wishlist Button */}
        <button
          onClick={(e) => {
            e.preventDefault();
            setIsWishlisted(!isWishlisted);
          }}
          className={`absolute bottom-2 xs:bottom-3 right-2 xs:right-3 p-1.5 xs:p-2 rounded-full backdrop-blur-sm transition-all duration-300 z-10 ${
            isWishlisted
              ? "bg-red-500 text-white shadow-lg scale-100"
              : "bg-white/80 text-gray-600 hover:bg-white hover:text-red-500 active:scale-95"
          }`}
        >
          <FiHeart
            className={`w-4 h-4 xs:w-5 xs:h-5 ${isWishlisted ? "fill-current" : ""}`}
          />
        </button>

        {/* Quick View Overlay - Hidden on mobile, visible on hover on larger screens */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-300 hidden sm:flex items-center justify-center">
          <div className="opacity-0 group-hover:opacity-100 transition-all duration-300 px-6 py-2 bg-white text-blue-600 font-semibold rounded-lg hover:bg-blue-50">
            Quick View
          </div>
        </div>
      </Link>

      {/* Content Container */}
      <div className="p-3 xs:p-4 sm:p-5 flex flex-col flex-grow">
        {/* Rating */}
        <div className="flex items-center gap-0.5 xs:gap-1 mb-1.5 xs:mb-2">
          {[...Array(5)].map((_, i) => (
            <FiStar
              key={i}
              className={`w-3 h-3 xs:w-4 xs:h-4 ${
                i < Math.floor(product.rating)
                  ? "text-yellow-400 fill-yellow-400"
                  : "text-gray-300"
              }`}
            />
          ))}
          <span className="text-xs text-gray-600 ml-1">({product.rating})</span>
        </div>

        {/* Product Name */}
        <Link
          to={`/product/${product.id}`}
          className="text-sm xs:text-base font-bold text-gray-900 hover:text-blue-600 line-clamp-2 mb-1 xs:mb-2 transition-colors"
        >
          {product.name}
        </Link>

        {/* Description */}
        <p className="text-xs xs:text-sm text-gray-600 line-clamp-1 xs:line-clamp-2 mb-2 xs:mb-3 flex-grow">
          {product.description}
        </p>

        {/* Price Container */}
        <div className="flex items-center gap-1.5 xs:gap-2 mb-3 xs:mb-4">
          <span className="text-lg xs:text-2xl font-bold text-blue-600">
            ${(product.price * (1 - discount / 100)).toFixed(2)}
          </span>
          <span className="text-xs xs:text-sm text-gray-400 line-through">
            ${product.price.toFixed(2)}
          </span>
        </div>

        {/* Add to Cart Button */}
        <button
          onClick={handleAddToCart}
          className={`w-full py-2 xs:py-3 px-3 xs:px-4 rounded-lg xs:rounded-xl font-semibold text-white text-sm xs:text-base transition-all duration-300 flex items-center justify-center gap-2 ${
            isAdded
              ? "bg-gradient-to-r from-green-500 to-green-600"
              : "bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 hover:shadow-lg hover:shadow-blue-500/30 active:scale-95"
          }`}
        >
          <FiShoppingCart className="w-4 h-4 xs:w-5 xs:h-5" />
          {isAdded ? "Added! ✓" : "Add to Cart"}
        </button>
      </div>
    </div>
  );
};

export default ProductCard;

import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { User } from "../types";
import {
  FiShoppingCart,
  FiMenu,
  FiX,
  FiUser,
  FiPackage,
  FiLogOut,
} from "react-icons/fi";
import { HiOutlineSparkles } from "react-icons/hi";

interface NavbarProps {
  user: User | null;
  cartCount: number;
  onLogout: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ user, cartCount, onLogout }) => {
  const [isMobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  const pages = [
    { name: "Home", path: "/" },
    { name: "Products", path: "/products" },
    { name: "Categories", path: "/categories" },
    { name: "About", path: "/about" },
    { name: "Contact", path: "/contact" },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="sticky top-0 z-50 bg-white/98 backdrop-blur-2xl shadow-md transition-all duration-300">
      {/* Subtle gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-blue-50/30 via-transparent to-purple-50/30 pointer-events-none"></div>

      <div className="relative max-w-7xl mx-auto px-2 xs:px-3 sm:px-4 md:px-6 lg:px-8">
        <div className="flex h-14 xs:h-16 sm:h-18 items-center justify-between gap-2 sm:gap-3 md:gap-4">
          {/* LOGO & DESKTOP NAVIGATION */}
          <div className="flex items-center gap-2 xs:gap-3 sm:gap-4 md:gap-6 flex-1 min-w-0">
            {/* LOGO - Optimized for all screens */}
            <Link
              to="/"
              className="flex-shrink-0 flex items-center gap-1.5 xs:gap-2 sm:gap-2.5 text-base xs:text-lg sm:text-xl md:text-2xl font-extrabold tracking-tight group"
            >
              <div className="relative flex-shrink-0">
                {/* Glow effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 rounded-xl blur-md opacity-60 group-hover:opacity-100 transition-opacity duration-300"></div>

                {/* Logo container */}
                <div className="relative bg-gradient-to-br from-blue-50 to-purple-50 p-1.5 xs:p-2 sm:p-2.5 md:p-3 rounded-xl shadow-md border border-blue-100/50 group-hover:shadow-lg transition-all duration-300 group-hover:scale-105">
                  {/* SVG Logo - Responsive sizing */}
                  <svg
                    className="w-4 h-4 xs:w-5 xs:h-5 sm:w-6 sm:h-6 md:w-7 md:h-7"
                    viewBox="0 0 40 40"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    {/* Shopping bag shape */}
                    <path
                      d="M12 12L10 8H6C5.44772 8 5 8.44772 5 9V33C5 33.5523 5.44772 34 6 34H34C34.5523 34 35 33.5523 35 33V9C35 8.44772 34.5523 8 34 8H30L28 12H12Z"
                      fill="url(#logoGradient)"
                      stroke="url(#logoGradient)"
                      strokeWidth="1.5"
                    />
                    {/* Handle */}
                    <path
                      d="M15 12C15 10.3431 16.3431 9 18 9H22C23.6569 9 25 10.3431 25 12"
                      stroke="url(#logoGradient)"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                    />
                    {/* Sparkle/Star */}
                    <circle
                      cx="20"
                      cy="22"
                      r="3"
                      fill="url(#logoGradient)"
                      opacity="0.9"
                    />
                    <defs>
                      <linearGradient
                        id="logoGradient"
                        x1="0%"
                        y1="0%"
                        x2="100%"
                        y2="100%"
                      >
                        <stop offset="0%" stopColor="#3B82F6" />
                        <stop offset="50%" stopColor="#8B5CF6" />
                        <stop offset="100%" stopColor="#EC4899" />
                      </linearGradient>
                    </defs>
                  </svg>
                </div>
              </div>
              <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent whitespace-nowrap group-hover:from-blue-700 group-hover:via-purple-700 group-hover:to-pink-700 transition-all duration-300">
                ShopVerse
              </span>
            </Link>

            {/* DESKTOP MENU - Only visible on large screens */}
            <div className="hidden lg:flex items-center gap-1.5 flex-1 min-w-0">
              {pages.map((page) => (
                <Link
                  key={page.path}
                  to={page.path}
                  className={`relative px-3 xs:px-4 py-2 font-medium text-sm rounded-xl transition-all duration-300 group whitespace-nowrap overflow-hidden ${
                    isActive(page.path)
                      ? "text-blue-700"
                      : "text-gray-700 hover:text-blue-600"
                  }`}
                >
                  <span className="relative z-10 flex items-center gap-1.5 xs:gap-2">
                    {page.name}
                  </span>
                  {isActive(page.path) && (
                    <span className="absolute inset-0 bg-gradient-to-r from-blue-50/80 to-purple-50/80 rounded-xl border border-blue-100/50 shadow-sm"></span>
                  )}
                  <span
                    className={`absolute bottom-1 left-1/2 h-0.5 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 rounded-full transition-all duration-300 transform -translate-x-1/2 ${
                      isActive(page.path) ? "w-4/5" : "w-0 group-hover:w-4/5"
                    }`}
                  ></span>
                  {!isActive(page.path) && (
                    <span className="absolute inset-0 bg-gray-50/0 group-hover:bg-gray-50/50 rounded-xl transition-all duration-300"></span>
                  )}
                </Link>
              ))}
            </div>
          </div>

          {/* DESKTOP ACTIONS - Only visible on large screens */}
          <div className="hidden lg:flex items-center gap-2 flex-shrink-0">
            {/* CART */}
            <Link
              to="/cart"
              className={`relative group p-2 xs:p-2.5 rounded-xl transition-all duration-300 border ${
                isActive("/cart")
                  ? "border-blue-100"
                  : "border-transparent hover:border-blue-100"
              }`}
              title="Shopping Cart"
            >
              <div className="relative">
                <FiShoppingCart
                  className={`w-5 h-5 xs:w-6 xs:h-6 transition-all duration-300 group-hover:scale-110 ${
                    isActive("/cart")
                      ? "text-blue-600"
                      : "text-gray-700 group-hover:text-blue-600"
                  }`}
                />
                {cartCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 xs:-top-2 xs:-right-2 bg-gradient-to-r from-pink-500 via-red-500 to-orange-500 text-white text-[0.65rem] xs:text-xs font-bold px-1.5 py-0.5 xs:px-2 xs:py-1 rounded-full shadow-xl group-hover:scale-125 transition-transform min-w-[18px] xs:min-w-[22px] text-center ring-1 ring-white">
                    {cartCount > 9 ? "9+" : cartCount}
                  </span>
                )}
              </div>
              <span
                className={`absolute bottom-1 left-1/2 h-0.5 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 rounded-full transition-all duration-300 transform -translate-x-1/2 ${
                  isActive("/cart") ? "w-4/5" : "w-0 group-hover:w-4/5"
                }`}
              ></span>
            </Link>

            {/* DESKTOP USER SECTION */}
            {user ? (
              <div className="flex items-center gap-2 xs:gap-3 ml-1 xs:ml-2 flex-shrink-0">
                <div
                  className={`flex items-center gap-1.5 xs:gap-2.5 px-2 xs:px-3 py-1.5 xs:py-2 rounded-xl border shadow-sm hover:shadow-md transition-all duration-300 hover:scale-105 ${
                    isActive("/profile")
                      ? "border-blue-200"
                      : "border-blue-100/60"
                  }`}
                >
                  <div className="relative flex-shrink-0">
                    <div className="w-7 h-7 xs:w-8 xs:h-8 sm:w-9 sm:h-9 rounded-full bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 flex items-center justify-center shadow-md ring-1 ring-white">
                      <span className="text-[0.65rem] xs:text-xs sm:text-sm font-bold">
                        {user.name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div className="absolute -bottom-0.5 -right-0.5 w-2 h-2 xs:w-2.5 xs:h-2.5 bg-green-500 rounded-full border-1 border-white"></div>
                  </div>
                  <div className="hidden md:block min-w-0">
                    <p className="text-[0.65rem] xs:text-xs sm:text-sm font-bold text-gray-900 truncate max-w-[100px] xs:max-w-[120px]">
                      {user.name.split(" ")[0]}
                    </p>
                    <p className="text-[0.6rem] xs:text-xs text-gray-600 font-medium capitalize truncate max-w-[90px] xs:max-w-[110px]">
                      {user.role}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1 xs:gap-1.5">
                  <Link
                    to="/orders"
                    className={`relative p-1.5 xs:p-2 rounded-xl transition-all duration-300 border ${
                      isActive("/orders")
                        ? "border-blue-100"
                        : "border-transparent hover:border-blue-100"
                    } ${
                      isActive("/orders")
                        ? "text-blue-600"
                        : "text-gray-600 hover:text-blue-600 hover:bg-blue-50"
                    }`}
                    title="Orders"
                  >
                    <FiPackage className="w-4 h-4 xs:w-5 xs:h-5" />
                    <span
                      className={`absolute bottom-1 left-1/2 h-0.5 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 rounded-full transition-all duration-300 transform -translate-x-1/2 ${
                        isActive("/orders") ? "w-3/4" : "w-0 group-hover:w-3/4"
                      }`}
                    ></span>
                  </Link>

                  {user.role === "admin" && (
                    <Link
                      to="/admin"
                      className={`relative px-2.5 xs:px-3 py-1 xs:py-1.5 text-[0.65rem] xs:text-xs font-medium rounded-xl transition-all duration-300 border shadow-sm hover:shadow-md ${
                        isActive("/admin")
                          ? "text-white bg-gradient-to-r from-purple-600 to-pink-600 border-transparent text-[0.7rem] xs:text-sm"
                          : "text-purple-600 border-purple-200 hover:text-white hover:bg-gradient-to-r hover:from-purple-600 hover:to-pink-600 hover:border-transparent"
                      }`}
                      title="Admin"
                    >
                      Admin
                      <span
                        className={`absolute bottom-1 left-1/2 h-0.5 bg-gradient-to-r from-white to-blue-100 rounded-full transition-all duration-300 transform -translate-x-1/2 ${
                          isActive("/admin") ? "w-3/4" : "w-0"
                        }`}
                      ></span>
                    </Link>
                  )}

                  <button
                    onClick={onLogout}
                    className="relative p-1.5 xs:p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all duration-300 border border-transparent hover:border-red-100"
                    title="Logout"
                  >
                    <FiLogOut className="w-4 h-4 xs:w-5 xs:h-5" />
                    <span className="absolute bottom-1 left-1/2 h-0.5 bg-gradient-to-r from-red-600 to-red-500 rounded-full transition-all duration-300 transform -translate-x-1/2 w-0 group-hover:w-3/4"></span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 xs:gap-2 ml-1 xs:ml-2 flex-shrink-0">
                <Link
                  to="/login"
                  className={`relative flex items-center gap-1.5 px-3 xs:px-4 py-1.5 xs:py-2 text-[0.65rem] xs:text-sm font-medium rounded-xl transition-all duration-300 border ${
                    isActive("/login")
                      ? "border-blue-200"
                      : "border-gray-200 hover:border-blue-200"
                  } ${
                    isActive("/login")
                      ? "text-blue-600"
                      : "text-gray-700 hover:text-blue-600 hover:bg-blue-50"
                  }`}
                >
                  <FiUser className="w-3.5 h-3.5 xs:w-4 xs:h-4" />
                  <span className="whitespace-nowrap">Login</span>
                  <span
                    className={`absolute bottom-1 left-1/2 h-0.5 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 rounded-full transition-all duration-300 transform -translate-x-1/2 ${
                      isActive("/login") ? "w-3/4" : "w-0 group-hover:w-3/4"
                    }`}
                  ></span>
                </Link>
                <Link
                  to="/signup"
                  className={`relative px-3 xs:px-4 py-1.5 xs:py-2 text-[0.65rem] xs:text-sm rounded-xl bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 text-white font-medium shadow-sm xs:shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-0.5 active:translate-y-0 hover:scale-105 ${
                    isActive("/signup") ? "ring-1 ring-purple-300" : ""
                  }`}
                >
                  Sign Up
                  <span
                    className={`absolute bottom-1 left-1/2 h-0.5 bg-gradient-to-r from-white to-blue-100 rounded-full transition-all duration-300 transform -translate-x-1/2 ${
                      isActive("/signup") ? "w-3/4" : "w-0"
                    }`}
                  ></span>
                </Link>
              </div>
            )}
          </div>

          {/* MOBILE CART & MENU BUTTON - Visible below large screens */}
          <div className="flex items-center gap-1.5 xs:gap-2 lg:hidden flex-shrink-0">
            {/* Mobile Cart */}
            <Link
              to="/cart"
              className="relative p-1.5 xs:p-2 hover:bg-gray-50 rounded-lg transition-all duration-300"
            >
              <FiShoppingCart
                className={`w-5 h-5 xs:w-6 xs:h-6 ${
                  isActive("/cart") ? "text-blue-600" : "text-gray-700"
                }`}
              />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 xs:-top-1.5 xs:-right-1.5 bg-gradient-to-r from-pink-500 to-red-500 text-white text-[0.6rem] xs:text-xs font-bold px-1 py-0.5 xs:px-1.5 xs:py-1 rounded-full shadow-md min-w-[16px] xs:min-w-[18px] text-center">
                  {cartCount > 9 ? "9+" : cartCount}
                </span>
              )}
            </Link>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!isMobileMenuOpen)}
              className="p-1.5 xs:p-2 hover:bg-gray-50 rounded-lg transition-all duration-300"
              title="Toggle menu"
            >
              {isMobileMenuOpen ? (
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg blur opacity-20"></div>
                  <FiX className="w-5 h-5 xs:w-6 xs:h-6 text-gray-700 relative" />
                </div>
              ) : (
                <FiMenu className="w-5 h-5 xs:w-6 xs:h-6 text-gray-700" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* MOBILE MENU - Optimized for all small screens */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-white/98 backdrop-blur-2xl border-t border-gray-200/60 shadow-2xl animate-fadeIn">
          <div className="max-w-7xl mx-auto px-3 xs:px-4 py-4 space-y-1.5">
            {/* Mobile Navigation Links */}
            {pages.map((page) => (
              <Link
                key={page.path}
                to={page.path}
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center gap-2.5 xs:gap-3 px-3 xs:px-4 py-2.5 xs:py-3 rounded-xl font-medium text-sm transition-all duration-300 ${
                  isActive(page.path)
                    ? "bg-gradient-to-r from-blue-50/90 to-purple-50/90 text-blue-700 border border-blue-200 shadow-sm"
                    : "text-gray-700 hover:bg-gray-50 border border-transparent hover:border-gray-200"
                }`}
              >
                <div
                  className={`w-1.5 h-1.5 rounded-full ${
                    isActive(page.path)
                      ? "bg-gradient-to-r from-blue-600 to-purple-600 shadow-sm"
                      : "bg-gray-300"
                  }`}
                ></div>
                <span className="whitespace-nowrap">{page.name}</span>
              </Link>
            ))}

            {/* Mobile Pages: Cart, Orders, Admin */}
            <Link
              to="/cart"
              onClick={() => setMobileMenuOpen(false)}
              className={`flex items-center justify-between gap-2.5 xs:gap-3 px-3 xs:px-4 py-2.5 xs:py-3 rounded-xl font-medium text-sm transition-all duration-300 ${
                isActive("/cart")
                  ? "bg-gradient-to-r from-blue-50/90 to-purple-50/90 text-blue-700 border border-blue-200 shadow-sm"
                  : "text-gray-700 hover:bg-gray-50 border border-transparent hover:border-gray-200"
              }`}
            >
              <div className="flex items-center gap-2.5 xs:gap-3">
                <div
                  className={`w-1.5 h-1.5 rounded-full ${
                    isActive("/cart")
                      ? "bg-gradient-to-r from-blue-600 to-purple-600 shadow-sm"
                      : "bg-gray-300"
                  }`}
                ></div>
                <span>Shopping Cart</span>
              </div>
              {cartCount > 0 && (
                <span className="bg-gradient-to-r from-pink-500 to-red-500 text-white text-[0.65rem] xs:text-xs font-bold px-1.5 py-0.5 xs:px-2 xs:py-1 rounded-full min-w-[18px] flex items-center justify-center">
                  {cartCount > 9 ? "9+" : cartCount}
                </span>
              )}
            </Link>

            <div className="h-px bg-gradient-to-r from-transparent via-gray-200 to-transparent my-2"></div>

            {/* Mobile User Section */}
            {user ? (
              <>
                {/* User Info Card */}
                <div
                  className={`px-3 xs:px-4 py-3 xs:py-4 rounded-xl mb-2 ${
                    isActive("/profile")
                      ? "bg-gradient-to-r from-blue-50/70 to-purple-50/70 border border-blue-200"
                      : "bg-gradient-to-r from-blue-50/50 to-purple-50/50"
                  }`}
                >
                  <div className="flex items-center gap-2.5 xs:gap-3">
                    <div className="w-10 h-10 xs:w-12 xs:h-12 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center shadow-md flex-shrink-0">
                      <span className="text-white text-[0.8rem] xs:text-lg font-bold">
                        {user.name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-gray-900 text-sm xs:text-base truncate">
                        {user.name}
                      </p>
                      <div className="flex flex-wrap items-center gap-1.5 mt-0.5 xs:mt-1">
                        <span
                          className={`px-1.5 py-0.5 text-[0.65rem] xs:text-xs font-semibold rounded-full ${
                            user.role === "admin"
                              ? "bg-purple-100 text-purple-700"
                              : "bg-blue-100 text-blue-700"
                          }`}
                        >
                          {user.role === "admin" ? "Administrator" : "Customer"}
                        </span>
                        <span className="text-[0.6rem] xs:text-xs text-gray-500 truncate max-w-[150px]">
                          {user.email}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* User Actions */}
                <Link
                  to="/orders"
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center gap-2.5 xs:gap-3 px-3 xs:px-4 py-2.5 xs:py-3 rounded-xl text-sm font-medium transition-all duration-300 ${
                    isActive("/orders")
                      ? "bg-gradient-to-r from-blue-50/90 to-purple-50/90 text-blue-600 border border-blue-200"
                      : "text-gray-700 hover:bg-blue-50 hover:text-blue-600"
                  }`}
                >
                  <FiPackage className="w-4 h-4 xs:w-5 xs:h-5 flex-shrink-0" />
                  <span>Order History</span>
                </Link>

                {user.role === "admin" && (
                  <Link
                    to="/admin"
                    onClick={() => setMobileMenuOpen(false)}
                    className={`flex items-center gap-2.5 xs:gap-3 px-3 xs:px-4 py-2.5 xs:py-3 rounded-xl text-sm font-medium transition-all duration-300 ${
                      isActive("/admin")
                        ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-md"
                        : "text-purple-600 hover:bg-purple-50"
                    }`}
                  >
                    <div className="w-8 h-8 xs:w-9 xs:h-9 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0">
                      <HiOutlineSparkles className="w-3 h-3 xs:w-4 xs:h-4 text-white" />
                    </div>
                    <span>Admin Dashboard</span>
                  </Link>
                )}

                <button
                  onClick={() => {
                    onLogout();
                    setMobileMenuOpen(false);
                  }}
                  className="flex items-center gap-2.5 xs:gap-3 w-full px-3 xs:px-4 py-2.5 xs:py-3 rounded-xl text-red-600 hover:bg-red-50 transition-all text-sm font-medium"
                >
                  <FiLogOut className="w-4 h-4 xs:w-5 xs:h-5 flex-shrink-0" />
                  <span>Logout</span>
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/login"
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center justify-center gap-2 px-3 xs:px-4 py-2.5 xs:py-3 rounded-xl text-sm font-medium transition-all duration-300 ${
                    isActive("/login")
                      ? "bg-gradient-to-r from-blue-50/90 to-purple-50/90 text-blue-600 border border-blue-200"
                      : "text-gray-700 hover:bg-blue-50 hover:text-blue-600"
                  }`}
                >
                  <FiUser className="w-4 h-4 xs:w-5 xs:h-5 flex-shrink-0" />
                  <span>Login to Account</span>
                </Link>
                <Link
                  to="/signup"
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center justify-center gap-2 px-3 xs:px-4 py-2.5 xs:py-3 text-sm font-medium rounded-xl transition-all duration-300 shadow-sm xs:shadow-md hover:shadow-lg ${
                    isActive("/signup")
                      ? "bg-gradient-to-r from-blue-700 via-purple-700 to-pink-700 ring-1 ring-purple-300"
                      : "bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                  }`}
                >
                  <HiOutlineSparkles className="w-4 h-4 xs:w-5 xs:h-5 flex-shrink-0" />
                  <span>Create Free Account</span>
                </Link>
              </>
            )}

            {/* Footer */}
            <div className="pt-3 mt-3 border-t border-gray-100">
              <p className="text-[0.65rem] xs:text-xs text-gray-500 text-center px-2">
                © 2024 ShopVerse. All rights reserved.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Gradient border line at bottom - ShopVerse theme colors with opacity fade from center */}
      <div
        className="h-0.5"
        style={{
          background:
            "linear-gradient(to right, rgba(59, 130, 246, 0.2) 0%, rgba(59, 130, 246, 0.5) 20%, rgba(139, 92, 246, 0.8) 35%, rgba(139, 92, 246, 1) 45%, rgba(236, 72, 153, 1) 55%, rgba(236, 72, 153, 0.8) 65%, rgba(236, 72, 153, 0.5) 80%, rgba(236, 72, 153, 0.2) 100%)",
        }}
      ></div>
    </nav>
  );
};

export default Navbar;

import React, { useState, useEffect } from "react";
import {
  HashRouter as Router,
  Routes,
  Route,
  Navigate,
  useLocation,
} from "react-router-dom";

import Navbar from "./components/Navbar";
import Footer from "./components/Footer";

import Home from "./pages/Home";
import ProductsPage from "./pages/ProductsPage";
import CategoriesPage from "./pages/CategoriesPage";
import About from "./pages/About";
import Contact from "./pages/Contact";
import ProductDetails from "./pages/ProductDetails";
import CartPage from "./pages/CartPage";
import Checkout from "./pages/Checkout";
import OrderHistory from "./pages/OrderHistory";
import AdminDashboard from "./pages/AdminDashboard";
import Login from "./pages/Login";
import Signup from "./pages/Signup";

import { apiService } from "./services/api";
import { User, CartItem } from "./types";

// Component that handles scroll to top on route change
const ScrollToTopOnRouteChange: React.FC = () => {
  const location = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  return null;
};

// Component for smooth page transitions
const PageTransition: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const location = useLocation();
  const [transitionStage, setTransitionStage] = useState("fadeIn");

  useEffect(() => {
    setTransitionStage("fadeOut");
    const timer = setTimeout(() => {
      setTransitionStage("fadeIn");
    }, 300);
    return () => clearTimeout(timer);
  }, [location.pathname]);

  return (
    <div className={`page-transition ${transitionStage}`}>
      {children}
    </div>
  );
};

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(apiService.getCurrentUser());
  const [cart, setCart] = useState<CartItem[]>(apiService.getCart());

  useEffect(() => {
    apiService.saveCart(cart);
  }, [cart]);

  const addToCart = (product: CartItem) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + product.quantity }
            : item,
        );
      }
      return [...prev, product];
    });
  };

  const removeFromCart = (id: string) => {
    setCart((prev) => prev.filter((item) => item.id !== id));
  };

  const updateCartQuantity = (id: string, delta: number) => {
    setCart((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          return {
            ...item,
            quantity: Math.max(1, item.quantity + delta),
          };
        }
        return item;
      }),
    );
  };

  const handleLogout = () => {
    apiService.logout();
    setUser(null);
  };

  return (
    <Router>
      <div className="flex flex-col min-h-screen bg-[#F9FAFB]">
        <ScrollToTopOnRouteChange />
        <Navbar
          user={user}
          cartCount={cart.reduce((acc, i) => acc + i.quantity, 0)}
          onLogout={handleLogout}
        />

        <main className="flex-grow">
          <PageTransition>
            <Routes>
              <Route path="/" element={<Home addToCart={addToCart} />} />
              <Route
                path="/products"
                element={<ProductsPage addToCart={addToCart} />}
              />
              <Route path="/categories" element={<CategoriesPage />} />
              <Route path="/about" element={<About />} />
              <Route path="/contact" element={<Contact />} />

              <Route
                path="/product/:id"
                element={<ProductDetails addToCart={addToCart} />}
              />

              <Route
                path="/cart"
                element={
                  <CartPage
                    cart={cart}
                    removeFromCart={removeFromCart}
                    updateQuantity={updateCartQuantity}
                  />
                }
              />

              <Route
                path="/checkout"
                element={
                  user ? (
                    <Checkout cart={cart} user={user} setCart={setCart} />
                  ) : (
                    <Navigate to="/login" />
                  )
                }
              />

              <Route
                path="/orders"
                element={
                  user ? <OrderHistory user={user} /> : <Navigate to="/login" />
                }
              />

              <Route
                path="/admin"
                element={
                  user?.role === "admin" ? (
                    <AdminDashboard />
                  ) : (
                    <Navigate to="/" />
                  )
                }
              />

              <Route path="/login" element={<Login setUser={setUser} />} />
              <Route path="/signup" element={<Signup setUser={setUser} />} />
              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </PageTransition>
        </main>

        <Footer />
      </div>
    </Router>
  );
};

export default App;

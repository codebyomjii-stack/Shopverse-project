import { Product, User, Order } from "./types";

export const SAMPLE_PRODUCTS: Product[] = [
  {
    id: "1",
    name: "Ultra-Slim Laptop Pro",
    description: "High-performance laptop with 16GB RAM and 512GB SSD.",
    price: 1299.99,
    category: "Electronics",
    image:
      "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.8,
    stock: 15,
  },
  {
    id: "2",
    name: "Noise-Canceling Headphones",
    description:
      "Immersive sound quality with industry-leading noise cancellation.",
    price: 299.99,
    category: "Electronics",
    image:
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.7,
    stock: 45,
  },
  {
    id: "3",
    name: "Smartwatch Series 7",
    description:
      "Track your health and stay connected with this sleek smartwatch.",
    price: 399.99,
    category: "Electronics",
    image:
      "https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.5,
    stock: 20,
  },
  {
    id: "4",
    name: "Wireless Bluetooth Earbuds",
    description: "True wireless earbuds with 24-hour battery life.",
    price: 149.99,
    category: "Electronics",
    image:
      "https://images.unsplash.com/photo-1583394838336-acd977736f90?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80", // Alternative URL
    rating: 4.3,
    stock: 60,
  },
  {
    id: "5",
    name: "4K Ultra HD Smart TV",
    description: "55-inch Smart TV with HDR and streaming apps.",
    price: 699.99,
    category: "Electronics",
    image:
      "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.6,
    stock: 25,
  },
  {
    id: "6",
    name: "Premium Cotton T-Shirt",
    description: "100% cotton t-shirt with premium finish.",
    price: 29.99,
    category: "Fashion",
    image:
      "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.4,
    stock: 100,
  },
  {
    id: "7",
    name: "Classic Denim Jeans",
    description: "Slim-fit denim jeans with stretch fabric.",
    price: 79.99,
    category: "Fashion",
    image:
      "https://images.unsplash.com/photo-1542272604-787c3835535d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.5,
    stock: 75,
  },
  {
    id: "8",
    name: "Running Shoes",
    description: "Lightweight running shoes with cushion technology.",
    price: 89.99,
    category: "Fashion",
    image:
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.7,
    stock: 50,
  },
  {
    id: "9",
    name: "Winter Jacket",
    description: "Waterproof winter jacket with thermal insulation.",
    price: 129.99,
    category: "Fashion",
    image:
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.6,
    stock: 40,
  },
  {
    id: "10",
    name: "Casual Dress",
    description: "Elegant casual dress for everyday wear.",
    price: 59.99,
    category: "Fashion",
    image:
      "https://images.unsplash.com/photo-1566174053879-31528523f8ae?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.4,
    stock: 65,
  },
  {
    id: "11",
    name: "Blender",
    description: "High-speed blender for smoothies and soups.",
    price: 79.99,
    category: "Home & Kitchen",
    image:
      "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.3,
    stock: 80,
  },
  {
    id: "12",
    name: "Coffee Maker",
    description: "Programmable coffee maker with thermal carafe.",
    price: 129.99,
    category: "Home",
    image:
      "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.5,
    stock: 35,
  },
  {
    id: "13",
    name: "Non-Stick Cookware Set",
    description: "10-piece non-stick cookware set.",
    price: 199.99,
    category: "Home",
    image:
      "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.6,
    stock: 25,
  },
  {
    id: "14",
    name: "Vacuum Cleaner",
    description: "Cordless vacuum cleaner with HEPA filter.",
    price: 249.99,
    category: "Home",
    image:
      "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.4,
    stock: 30,
  },
  {
    id: "15",
    name: "Air Purifier",
    description: "HEPA air purifier for large rooms.",
    price: 179.99,
    category: "Home",
    image:
      "https://images.unsplash.com/photo-1581094794329-c8112a89af12?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.5,
    stock: 40,
  },
  {
    id: "16",
    name: "Moisturizing Cream",
    description: "Hydrating face cream with SPF 30.",
    price: 34.99,
    category: "Beauty",
    image: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be",
    rating: 4.3,
    stock: 120,
  },
  {
    id: "17",
    name: "Perfume",
    description: "Luxury fragrance with long-lasting scent.",
    price: 89.99,
    category: "Beauty",
    image:
      "https://images.unsplash.com/photo-1541643600914-78b084683601?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.7,
    stock: 55,
  },
  {
    id: "18",
    name: "Hair Dryer",
    description: "Professional hair dryer with ionic technology.",
    price: 59.99,
    category: "Beauty",
    image:
      "https://images.unsplash.com/photo-1522338140262-f46f5913618a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.4,
    stock: 70,
  },
  {
    id: "19",
    name: "Makeup Kit",
    description: "Complete makeup kit with brushes.",
    price: 69.99,
    category: "Beauty",
    image:
      "https://images.unsplash.com/photo-1586495777744-4413f21062fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.5,
    stock: 45,
  },
  {
    id: "20",
    name: "Electric Shaver",
    description: "Wet and dry electric shaver for men.",
    price: 79.99,
    category: "Beauty",
    image:
      "https://images.unsplash.com/photo-1621605815971-fbc98d665033?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.2,
    stock: 60,
  },
  {
    id: "21",
    name: "Yoga Mat",
    description: "Non-slip yoga mat with carrying strap.",
    price: 29.99,
    category: "Sports",
    image:
      "https://images.unsplash.com/photo-1599901860904-17e6ed7083a0?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.4,
    stock: 90,
  },
  {
    id: "22",
    name: "Dumbbell Set",
    description: "Adjustable dumbbell set 5-25 lbs.",
    price: 129.99,
    category: "Sports",
    image:
      "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.6,
    stock: 40,
  },
  {
    id: "23",
    name: "Tennis Racket",
    description: "Professional tennis racket with grip.",
    price: 89.99,
    category: "Sports",
    image:
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAkFBMVEX///8AAACqqqr8/PzCwsKjo6Pk5OR8fHympqbo6OjQ0NDu7u7ExMTLy8ugoKCzs7Pa2tq8vLzd3d2urq7z8/Ps7Oy2traVlZWKioqYmJh1dXVtbW2MjIyCgoJnZ2dUVFRAQEAtLS0UFBReXl45OTkbGxtVVVUODg4lJSVhYWEyMjI8PDxGRkYeHh4TExNMTEzby6umAAAL/klEQVR4nO1dh3bbuBKlCPbem0T3Enud9f//3ZsZkLQKZcvO5hHgwT0RMwbpHFwNgIsBBoymKSgoKCgoKCgoKCgoKCgoKCgorAns6EfGjotWAFZaXmikRuBlbrF0Zf5rsEzv3n5vPvB4cxV5q3AitkbN2N5tZvFSFdh+JWdqNfPsBnTJ0hX8MdB5TLO6gcnrVVtnPjPBqVmcBdXV1etw5947GYfkALXPHSfxvs00rQig1ISPi0auMcu5HfxY0PchG6DKCWdgZ1oMBa6hcYaWATd1+LiJW3OOxsKV/SEiqvy20tBjmuYfMHSwCYfwRWz5tyBbS8Xa2ljzB4+l2hxDHQw3BCMvn/DBa+naKfdND90PiWErpX7oaFM/1LQSxhikquOjbzJNAtAbRPAtzXXHjvO8y/M86nM93oLR9nAho8n1vNPzqid3F9K4EevZb543mxCbYoGtlHyIzkQfWuhDvDX6UMtyHJPeZeqK1O4C6nXAEDobo37I9kcaosqouWaedceHGznAtAQJVtxjxTTSjK477IecoWbxX5GkobIHVAnLy5osSbwoS7I6SZIQjR0YhjMYgY4GPJPG8AhSdCVpqDiTuXGAQpMgQ7hwhnAhhuZgBHni0a0qTpLsHmdwS1f9AkAzy9AbCTbOoR/ykcY/UAsaacLByLC5tm/STG7QGXqBU5lI2++Hc4rPGSYelETYex8Xq/U34GEb5cTQY+y84vt7Iw1+HTgL0pep9LfwguO+03Zm5FyZUUTGNorMGgwTS3a2aXKj5yVmA4bzouNg80v8oSYjF3IfYptkk+KfnbWNPtQ6LjKCA5sakPKxptNIQ4o/craw3U4z76kftvzbeV+u6peAacUzb2n+wViKHvuYte0x5CV8LNV4Cxd7WYNpKdTxdlA/knVUfK6H5ij0qIc1lBr6cCtFPYTpQdbCb++WJvEZQAxRKnrP84IW1LxJPA+oel7teUmARg+fNPL4LcOBB3fwQ6zDBW4lBvz289IsPkdBMRPbG2kuVnwUz/JO+GaKTmjTsR9+Q/F5P3Rx6bFdqO6XoacJ2+jDLxT/RC2AMy5oLFP1C/EP1DDvIl2PbF3Pt7rjRHbu6J0DJT0v0Wu4pZPR6A6V7MDQr7CkxlCYCRxDYTd80uKxlR7Eh5NafNIPrQTjEk/gGCqk0T4uDvshG/shm1lro34YcsUHqobgc1OHAqBTHx6MpdbUD/d8yLgPPYz1u4VqfwloYpnUIWhdC1qHwhi2XPR4SeONeoiGM5TE+fBwpXswJ3oTuJVebza/LTdKLMtzLMutLctKHDdzWwtLXChxLSvM4ScsCWN4Bo0gBaPBW6n/DkGiuEun7Jbiimpe8Uc9/Gyk8UhvyiUqfxEK3oniHys+UMWunC1U/6/hQu2iYx/OK/5ZHwbwb4TLVP8C4EpLp+udiULP1RwNnSs+lIDQ63rbk+KD0ei6g8augftXYMAcYCd0FBzSSje10o9Z23nFd+d86AstiBVNSMZ+yC5XfNTDWiOqhdBzb52WrT/64YHiFweKf7gzM828geq/IgfBuOubhuEuCMO0DsOwh49Re2HYgJG2YehhSQUGlVTRcCs34ZbtkRH8FnmLBpcDvUnxM3dnZaD4cGkzKNHB2KHQ63CpueJnZBjVcCsA41XYaRs0TYxfi8sVf3ak0R42m6tlGFyAnjP8I8VHhuJu0PQzPqQYf1KLw/3DmfiQGD4tU/0LgAxrM+qiKKI1/C0Yke1E0TYyzdamNXzTrO0IbpFhRvCwaTY9lFw5prnrTfO36Az9c/1wJsb3tL0V4bEf/hKZYcP1MC80Nqv405r3uX4IDIt/Re6HNY8LJh8e5GL4J4pPDIfdtTHGpznNdqH6fw1U/Cj0RsUnfQ/qcFR8j88Bqkn6o2FWoDuo+GDEZpjyRCNBkSPD0jUz10p01y3rcjAiy3WT3LXK2nVdbzIqfAaMoIKSXem6YVpi9FQvTeQsgrn48EQPP1d8/DecZap/ATKe9hPP7q59KH5wPNJke4qv8/1HQeHzHc5vzGl4ctT+nGYn9N4MAy17zFNbj3OzqeJqG8d53sd51cVx7NhwQSPqqxxvxVET53GXx3G7y/OYSurqQeiVKO2Jpm24CHGoFlRysE5D+nESH0I/fBU7W4HvOkyr+qeZew7bz9w73scHqr7gm08pDYRnYvyDmfe5nZmExEJcJ5a49xQ2qZHGu8AI7MAwqp1hBL1hGHENFxs++s4IyMhbLIFnnAie6cDQzZ52PsRlqD3i9p9j+X6W+35R+35p5YVfRD6UxEVZtGAksV9SSZL6/FZowKUufN8L76knC8wQt2bK+OeKn/B8I4GB64npt/fxJ8W3dNHTTagjdrSPP8ZKFONPanEQ45+qhX8v9Jq+hqtRmCSKoX075um1ncODfQrtr8jA8J9S+Cj8jyKeuQcllCi8NIkvoA97uB9q8Z1cjFLo4JADt58eoJWWBzE+0pj2va1pOWPMaxvmpYzCr2Cxul+Ia76H+9Wq/nGuPvfhO07ZBJYKQkpxflCB4od2EATpDi69EQRVDXOAHn7IayxBI4ILPuOAEXbwCPxuszSBL0GZbYWb6KXrQ4zvZnkJMT4E80nOS0ovBqP1wajgpxY+ENq7/q70bVrnEd2HtKTo/kzxH8WedXMwGmuaH8X4MQ/vRfcho0Tfwq9oP5TxhdMchg8aXU0wLIONJywHY8iJepDiNALjxxFe9D6GGL+KY70ZQnunn2L80YBbORoU43eN0GtQHwCKMK+5Ky/I3HMPFZ+HFVIAExZsgxSfHa3qf7KPb9MGvuidcMD7sCJ4MGvzT2dte6v6dODtUejIcB/YE6/SuOqgH+Z2FVc29UMwxu5Ht6Iddkgw2jpOG76aLAUYPzfhQStlH2Mpc3EIxZJsOK3OrIDR6MqSkOEK1K+la34pcDkN6vvPWT2ci4C30hzNQww5C/XRDulJXtsHwyTYiLwvOgPGcEkqaCiDFg+KDidK6CBJaoKxwxMlOhpwq9J/C52ROAvM176zs/1TQeMp2WA8JTudCsKHcUtNkoGUwKhj3WqzJ7sOWimWmPDsK5PlIPcIjKJgEsYuGGm8jdD7TWeBM5tNeMFY6m6E3vb9BPT2lvTzd5vAreSRlp8ka6LadFKPT1A/YUgvebmVjh6C0ZYwKH/yiQ9L+hYw7VY+oFdyqv6mo8P5pwz9gL+GaNNL2EYH3HAGz0/+8SoGiEQx8JMmKpyDN3LYdJ4/vuuLr5dazfN4T9zE9a/AuO6PuI8ThvpeplZq0ysGn4nkw9L1/CO4A7vb4e/n29fb8f2Jvx7538Iv438OeqfgncWSfW+SRwNWUDe9lneYIdDkjTLTWRK3vW3jnzr36JWQDlcKqQkyysicPVDI+J74y/+/Uv8pGCvOdzVf0hn3MVpy4lzw16/AhYjijpx4SpBe7yVZYD8PnLrczJT3ksYUp8Dc9JkR0+cuXAFDPpzenzBsV9IL6U3I6C3ruHw1vXB04vGJu3wj8rmK7wLTZPAwzQcYbofKGfjOA4fN/aOvjFLypXqd5xfAEOMwt5knsK2GIaMZ6H5irHVGI2UFY3gS42mPodin7n+Elz3BYCQVvxetz38PXLH5SI3lGe+r6YUcb5vN40TpSe4Ftnl4exGGK/UC21m84yl0zrDd9+dawN+o6HOKD6Knq/8MjAQCGWbrmXMfoqOVQ42OC9+sbSAlGOMA+irphuiXwFU3TB+1NoKfqfg5XnmUiJHh0lX5S2h4YtfUH9cH6ohMu12nViAymo16G5ky2L4HhtuF1ytagTrFzbiLuM5eOCQ6I16Xrspfw5iaIPrxtJ+C0WCKWOeMBhlmA8N86ar8NVgDw9WKxZgjJfAbdv4MjP83UDN7GGvB+hlqq2e4fh8qhvJDMZQfiqH8UAzlh2IoPxRD+aEYyg/FUH4ohvJDMZQfiqH8UAzlh2IoPxRD+aEYyg/FUH6sn+H6d7kVwzWgHxjeLF2RvwTKf+ZY3amuAeVIcE1HnA8QTgxlednsd+FMDNc61Owmhk9reB3GDPqJ4fvSVflLyK6Gt3tdr/TYEzTMwrVcy1qrVigoKCgoKCgoKCgoKCgoKCgoKKwb/wMAAb/8oPvFuwAAAABJRU5ErkJggg==",
    stock: 35,
  },
  {
    id: "24",
    name: "Fitness Tracker",
    description: "Water-resistant fitness tracker with heart monitor.",
    price: 99.99,
    category: "Sports",
    image:
      "https://images.unsplash.com/photo-1576243345690-4e4b79b63288?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.3,
    stock: 65,
  },
  {
    id: "25",
    name: "Basketball",
    description: "Official size basketball with grip texture.",
    price: 34.99,
    category: "Sports",
    image:
      "https://images.unsplash.com/photo-1546519638-68e109498ffc?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.4,
    stock: 85,
  },
  {
    id: "26",
    name: "Bestseller Novel",
    description: "Award-winning fiction novel.",
    price: 14.99,
    category: "Books",
    image:
      "https://images.unsplash.com/photo-1544947950-fa07a98d237f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.7,
    stock: 200,
  },
  {
    id: "27",
    name: "Cookbook",
    description: "International recipes cookbook.",
    price: 24.99,
    category: "Books",
    image:
      "https://images.unsplash.com/photo-1541961017774-22349e4a1262?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.5,
    stock: 150,
  },
  {
    id: "28",
    name: "Children's Storybook",
    description: "Illustrated storybook for kids.",
    price: 12.99,
    category: "Books",
    image:
      "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.8,
    stock: 180,
  },
  {
    id: "29",
    name: "Programming Guide",
    description: "Complete guide to modern programming.",
    price: 39.99,
    category: "Books",
    image:
      "https://images.unsplash.com/photo-1512820790803-83ca734da794?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.4,
    stock: 95,
  },
  {
    id: "30",
    name: "Self-Help Book",
    description: "Personal development and growth guide.",
    price: 18.99,
    category: "Books",
    image:
      "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80", // ✅ Books/Study Image
    rating: 4.3,
    stock: 140,
  },
  {
    id: "31",
    name: "Gaming Console",
    description: "Next-gen gaming console with controller.",
    price: 499.99,
    category: "Electronics",
    image:
      "https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.8,
    stock: 30,
  },
  {
    id: "32",
    name: "Tablet",
    description: "10-inch tablet with stylus support.",
    price: 329.99,
    category: "Electronics",
    image:
      "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.5,
    stock: 50,
  },
  {
    id: "33",
    name: "Digital Camera",
    description: "Mirrorless camera with 24MP sensor.",
    price: 799.99,
    category: "Electronics",
    image:
      "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.7,
    stock: 20,
  },
  {
    id: "34",
    name: "Portable Speaker",
    description: "Waterproof Bluetooth speaker with 20W output.",
    price: 89.99,
    category: "Electronics",
    image:
      "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.4,
    stock: 80,
  },
  {
    id: "35",
    name: "Wireless Keyboard",
    description: "Mechanical wireless keyboard with RGB lighting.",
    price: 79.99,
    category: "Electronics",
    image:
      "https://images.unsplash.com/photo-1544717305-2782549b5136?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.6,
    stock: 60,
  },
  {
    id: "36",
    name: "Leather Handbag",
    description: "Genuine leather handbag with multiple compartments.",
    price: 159.99,
    category: "Fashion",
    image:
      "https://images.unsplash.com/photo-1584917865442-de89df76afd3?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.7,
    stock: 35,
  },
  {
    id: "37",
    name: "Sunglasses",
    description: "UV protection sunglasses with polarized lenses.",
    price: 49.99,
    category: "Fashion",
    image:
      "https://images.unsplash.com/photo-1511499767150-a48a237f0083?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.5,
    stock: 110,
  },
  {
    id: "38",
    name: "Wristwatch",
    description: "Automatic wristwatch with leather strap.",
    price: 199.99,
    category: "Fashion",
    image:
      "https://images.unsplash.com/photo-1523170335258-f5ed11844a49?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.8,
    stock: 25,
  },
  {
    id: "39",
    name: "Formal Suit",
    description: "Tailored formal suit for business occasions.",
    price: 299.99,
    category: "Fashion",
    image:
      "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.6,
    stock: 20,
  },
  {
    id: "40",
    name: "Scarf",
    description: "Cashmere blend scarf for winter.",
    price: 39.99,
    category: "Fashion",
    image:
      "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.3,
    stock: 95,
  },
  {
    id: "41",
    name: "Desk Lamp",
    description: "LED desk lamp with adjustable brightness.",
    price: 34.99,
    category: "Home",
    image:
      "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.4,
    stock: 120,
  },
  {
    id: "42",
    name: "Bed Sheets Set",
    description: "Queen size bed sheets set with 4 pieces.",
    price: 69.99,
    category: "Home",
    image:
      "https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcTF8yvUeyxbZzTROSwnpHxyiizjBBHEvfBS8jDQ5XeciEkRYmBUq61s_cie_Q__baaT9JO76l0djeNbMdm-GF-WBhY0lEwGrd9Q3mHROrto",
    rating: 4.5,
    stock: 70,
  },
  {
    id: "43",
    name: "Cutlery Set",
    description: "Stainless steel cutlery set for 6 persons.",
    price: 49.99,
    category: "Home",
    image:
      "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExMWFhUXGBobGBgYGBggHxgXGhcdGBodFxcZICggHholHhgWIjEiJikrLi4uGh8zODMsNyguLisBCgoKDg0OGhAQGislHSUrKy0tKystLSstLS4tLS0tLSstLS0tLS0tLS0tLS0rKysrLS0rLS0rLS0tLS0tLS0tK//AABEIAOEA4QMBIgACEQEDEQH/xAAcAAAABwEBAAAAAAAAAAAAAAAAAgMEBQYHAQj/xABMEAABAgQDBAYHBgIIBAUFAAABAhEAAyExBBJBBVFhcQYTIjKBkQdCUqGxwfAUI2Jy0eGCkhUzQ1OywtLxFjRzohckY5OzCFRkg+L/xAAZAQEBAQEBAQAAAAAAAAAAAAAAAQIEAwX/xAAoEQEBAAIBBAEDAwUAAAAAAAAAAQIRAwQSITFRE0FhUoHxIjIzNJH/2gAMAwEAAhEDEQA/ALyVGxG/x0+cMJ+1OrZw5sSQ2b8sPkA0JHCjF/H6tCOIlUJSkZmuB2uQN2jl6rv7N4Fl+yPmhUzMqWUqBukEhY17pDFt7w3/AKSPWJCKLWkJVcFJSMyieQCj5CHkwSVHq0IK1i6kqKSkjXNpXhXjDDH4fEyZkvEqQJglq7apZJXkYpPWBg5YllDxj5uHDlNXH99J69pbYu0hO6yxyKCcwssKDgtoaFxpDTpb1nVjKaOHG5QLpIN7j3wyx0xKZuXDIM0zvvEiWUs6SylB6Bsx5ZjSHO1Noo+zqlqWnrJSkJmpQT2SQSyVFyTlDPUvzEdk5Mssbjl9vv8AK3zE3gFFUpGchSmqQA2YUUQ3Is0KCgHH6rDNe1kS5SCtOQuiX1bpBQpScwSpyAGSyi5oIcyZ6FpzoUCkvV3FLu1I7McpZpqFCYPKVpCZTAzsat9fONg6ga0+uMcC46+nDzgJQ1Gb3wAQuFSYKpHLnAQXoLwHQlxBQlog8R00wMuYJRxAKicpUAShBsy5g7IrShLatFllYfM70A+fygbRO0tpJlJqoAmiQTc6C1IpfSXb4TKUUZwVJZSVoV2dSyxQtmJZ7W4TvTbDrloKUnvjsmjAgh8wYuBdhWKZtTG4ZCJhzGasISlL/wB+NRLIYkA9k6M2sfN6nC5cnndjv6a4zD8pjAbQX/WLZKlqBSGzKJNUp3JS5fUmm8RblLFCztQu4aKTJw0lU9K5SiAUEoDJYpCw+UEkiqk66caWmUugIan6VqaWj06LHUtY6u7sPpKUioYPZuHwFTCiF0b53/WEJDVIo/KnPT/aFVJpWlvrjHa4xkEvamv7fW6EjRT6PcfI2HL/AHgAOKKbc3i124WjkvA9gMo60JLaOAAaeLxQWdMIdknRmHF1PpvrBpSswu73cMzcq6/Whp0spTwo1aBL8dWhNQYFmfiEliaaaawAUGFSSKnKdAwFG0F61pCE5BZQu/dcu7tyoeHOFQshwQRc2YEnnz384CA9HexOtbg14tEDHrFeyr+X94ESDp9r3j9Y5AOXYmOicKGOKlvWrtCOU+G+FDGXiAFtJlBClJV2lOOyC6iEbyohnvyjuKwXWoSJq1qBOZQc9wGzJ4M54iHJWB5XYfFrPHZpzAd5n5OB8uPCOHLpsvnf8pYr+3BITmmYRE1E9AqqSlkgGwUFdmrMwFWq8M9rSZkrF4fEYqUlKesSJ86W6pa2ByKWG7JSrK5YAsN0WNeLTLCjlJBuANBZq/FriIjbGDm4lSlylLlUyFJmKCpg1dIOVOoq7k1hjl+r+74jGUQ228Zk2lOR1KsTmWmZLkpqFLMlCAVMD2QADuoLB4se3MdiU4MtMRKxaFSxklGiUzlhCEqcM5qcwsUsLl2AwJwUyZiJK5QlnIjqpigkGW1ECae7MzkkOcqnALXiG6YLTilyZ2Hm5VzFS8PNQpgpB6z7tZSKkJUTUP6se88e/Z6aVg1KUhzMlTC5BMoEJBTQpqouxBD05Qp1Ztpzrx+cVHbmK+xIwUiSiamUmbKzTQAZahmIUJqwXCyTnLhi8WnZ2NE6VLmpcBaQpqa3D6sXDx7StynSZUcU+gc/HdEF0i6VYfCOFqK5o/skkPXVeiPGu4GM62l0kxONExcyaMPhJbdYZbjMo1RLTXNNmqY9lwGcnKBGja+9I+nOEwhyv103+6lsWI9tfdT7zwjPNsdL8VjMyFESpJp1Us0Ov3i7r5UHCLVsjohgxLQeozZkpV96EqUHSCyg2UKD+qwh/M6K4YhkyUIO9CQmvHKz+YjURlGKQxHwjYvQxtJc3CzpS1FXUrSEPdMtSaJfUApU24UsIz3pb0amYcdYO1LoH1TxUws5FaMWBAcFVh9B2OCcVPkkj72UkgcZKi/umnyhfQ07bmzhPlKQQHunmP1tGXbZ6GFaWMxqv2U1feWqS8bGtMQO15GRYUA4X7jq246xiyW7reOVk8KFI6PTnlqXMSctQWAe7mlgTcAedosmDwpS1KXy/IuPhD1k0fxctuLkeUdloNPh9aWiY4zH0tyt9upS5BdmcN+8LJlijU3/AFy+MJFL3Ia4pq3vgSlFLBjYMb0/EL+PPdFZGmy0tffqzefh8dYQn7QloEskliQAWe7l1Vtxiu7W2ysFSc7DMQkJDuNxpVv1iERjSqy0JL1DuCL1Sba0Nnji5OqstmMZ7miIVnSkhWYVtw3K00DQTqAboBq4ffy/2iqYXFK7HbSCgqqCag1oDDXFbcmBRUlZcJDpzFlADVmObR7+TQx62X7LtbxMckX0Jcs3K2l4BNai7ubFvDxiobV6RTcn3akpLJoUvU3BNCWrVhUecxN29I+6aYT1hVLTNUgH7xJYZxuUaOG8NOjHmxyTuiQ6xP4P5v2gRU/+N5X/ANuj/wB1X+mOxvvh3Rf1TAKVJ1ABJrvCQYbzpyRcKTxUFJD61Ib3xH4yXmmLKZiwpQBHaOUEBspG43pWpPCEcNtWclxMSezZwSN1FgMzan9Y+Xz9fycfJcNTw7ePp8csdpTJU+PL6aOGXxNff+8FnbQQkZiAEM6mFJdHcgWS191DqYUmLBFCGIBFXv8AKsd3Bz48uHdHhyYXC6pAoN70oOF/1LwmF10ckC4Jck0jk/GpQsIJZwauHzCtagNFV23trqilaiJgKVJV1dGVmdJbk4JpfgDHPydRjje3D28zzpRiZhQZctRSSoJmAJdWVRYMDVv0NYYYPY+HUhQMjqlpBSSSogEsp0L3oLiteJERO0NtTTifvD1apb5kG5OVwMuoKghT7hSK9jdvrUgy0E1WtSiD3szMCdwANKisTDDl5PEv58vOxZNuYtJQmXiZhmoagVmTMQCkUKpZCZg7tFBxq9TEThul2Jl4ZGFkryoSCBMAZZS7gBXqs5qKsweIBCCrtElROp+ULJTdj9cI+jhhr3VJhKlqYAqUosALqUTQV1JPvjU9odDJBRhMMQVGTMBUoEsphnnkpdjmUEpBagKAN0UjoHK6zaOFSoUEwrYsx6qWuaHHNAjW9lpzT1k+olCBwKvvF+Y6nyjdVJ4fBvpEhK2ZDzAyIkkoaIK5tTZssSlmZlCMpzZyAGZqk0Yu3iRq0YXs7HIwG0JGIQSrDkomoVvw80FCwrigKmJIu8uNI/8AqImEbMlgEgKxSApjcdVNUx3hwD4CMXw0wzcABUnDTinT+qxCSpvBck/+5Fg9WkeI374b4/DZ0EDvXT+YW86jxireifb/ANr2dLzF5kj7qY9zlHYV4oy13gxc0xlVKw+JStGZCiQ5DUcKT2VBT1CwXcGoLjSHCEes97Xt4/VYqHpME/ZuLGMw5PUYtkz0UYTkjvAGgWpAcK3hT3iwbF2rJxUsTpS6UcFnQW7qwPWDjeDcPBZUuF3dT7gB+nh7oHVg7qtuDU0t5RHnaUoJUQQrJ3shfWrWt8jDebtNGdLGihmSu4oKh7A1S/OPHLnwx90NtuYBZKlBRHLKHAIBfM7UfxeKzjZc1CjmAWkLOUpDqy5QwWFOB2iqr2AYRapOPJUUKy5SnM4FCLWOpBD+LXERG1EKlzcqGyTDQrd0KAdr1dgznfujg5uzkvfj6+6WRBJnABUychCE0HYYqBJZ8oTaxqdIiJOKKyaqCgo5QlOZ0DVRJAAq1B8olVoSCozXABOd7E27tXq3wiM2llzPLQEJZqE5iXYlhQXYtR2FoxhJvUjGRLDTSiY3ZLpVUigTRwBd3IZmq9aQiMUkEBaylCUqASxY0JDEsR2jUkak8IYz15TmQAUg9o2zk0atfECG4xjVmJBCWOUlgVAvRy/8MdUw9PPymetR/eS/++BD7/jhHtr8h+kCPTsXsny1GbstmUgsdzU8tP2hlMm4pFDh0zEN3kLS5HJTfOLImtCOPCFFI+G76rF5ul4+W7yjrw5csPSlTsfipzy14Qy5WauYp7YFAFCrpdqFnIq4hzKkK6splnq2rSw3skFmpYNyizTEIykqISA1SwCRvL08TFD6V9NcJLQqXJUcQsAvlUyBudYZz+WnGLj08ww7cIznncruuzpWInO4T1aczzFKQBQMWS6iDQbtDrFZ6VbXwqkmSiTLJDDPLUWYBqkjtPxiuYvGzJqgVksdK38YMjC8Izw9Hjh5vt50yxc0qejPu+HIaCO4LAFakoSCpSlBKQNVKLJAG8kgeMS+x9nImYiVLmKyJWvLm9kqBCCQdM+R+BOrRKysATInS1ICMVhCqYpqEynCZuY+sZSwlQUbJUprV7PSIYbKWMMueDmTLmCWtABeWVdxSvwKLpBFiljeI9SFEMTlG4RfpeNly5kvHLSFYbGJVJxyAHHWgfelhZ6T06sV73ir9MNiKwU9UlRKk0VKmUabKV3VAij6FtRuIJqj+j+aEbRwrWK1I8ZkpcoOeaxGt9HpbTcR+JctXgcPLR8ZavKPPqMUtC0rQWUhSVJ4KSQoe8CPQGy8eiYqXiZf9ViEDwVmUUg7sqzOlnjlESi84MUhzDLAzKQ9EQZ96ddn9bsmYoBzKmS5g8ygnyWqMC2D/wAnjeH2fz61vgTHrDbuzE4nDTsOuiZstSCd2YMCOILHwjzJi9jTsFhcRh5qWmzcWiWEsapw6FLUpJ1SozpMBM+hPbww+0BIUppeJTkY26wdqWefeT/HHodKY8nyMEJOWYknrkkKCnohQLpKNVKBALmlLG8emuie2xjMJJxIoVpGcezMFFp8FA+DRiZ45em8sMsZujdLtgJx2Dm4ZTArT2FexMTVCvAgcw41jzbsTak/Az1N2ZiFFE1BsSlRCkq5EGot8fVaTGF+nHo31WITjZaexO7M1tJqRRR/MkeaeMekrB1hsZKxp64LVLIAzoSlLgh3dQqQ1lGnJmCG0JKMhTInlcsdppgHZLAHLMHOxG7wzzBY9ctQXLLKFN4IJqlQ1SWDiNB2PtTr0IWpWVXsqcjMFZXSXsw4mp5x87qeDHHd8aq7KYmYlckzpSiJqU9qXRiGZQSOQcNuhDFzJy8IyJkmbnS+UryrQrvApzN94C1C3sxIow4WokkODq3aFR3f4b6X1hP+iUmY5SlIDslKAyhq4AZSq0Jt4Rz49ls8efSeVYx0xGIw6MiijEykhC5ZB7e8E+BUDzBbRrggEy1mYVifMJJUADlHqpAtWpPPhE5jMNmmgDMkJI7LAUB0HEb+Ajm0MKZMp5QWlDkuNAXJY6Frt5x1Y3zdT0zq72qMrZ6xNBSTMe4KMpYs5Slzzh1jcIqoylI8PnrE9sHZBWespQqq9wpgQXFfrjD1WzMy2ZRD1d2rTThzvzb0x3lNmMtjO/sqP7weX7QI0v8A4ZR7Cf5f3gQ1mz2ZNSTrrR72A+EU3pL6SMNhyUSEnEzbMkshJ/FM15JfmIzTpB0qxeMzJmzMsomkpFEt+L1lfxExFyUHUU3R1aeiQ2/0jxOMbr53ZNpaCUoH8OtdS5iOl4Y90MXs0KSJIfMQw5fOJ/oxspOIxGVdZSElawHH3aWoCKlSlKSjRsz6RoF2J0dmzZaVBkgmi1EscpY5WqRxto7xOnoZMZxMB4ZSPfmp5Rb8Hh8xdgOADAAUAA0AFANABFm2fgA0Z2ML2tsudIrMQUijKFnJYOdC9nZ9Hiz7cxhQvB7XlpcTgE4iX7U1KSiYhrfeSwsV1SDGmdJcPIRhZ0ydSWhClFWXNlpcJ10pqC2sZ/6McRhMZh5mHy9mYsqVImMpMuakJUkJJqULCFEE26sjnLlqbWGWCwcqXiZmzn/8rjkJmYWZ7KmK5CxxuhWpZL0MDZWAVtHBTdmzgE47A5jJJN0O2TNqjup5GWqLJ056M9dIKJAafIefhgkMWBAnS0txyrA3qAoBELjMeqZLwvSDDJHWIaXjUJ1AISo7mKWrShQo0TEwz78dws0x/Ey1JUUqBSpJKVJNwoFiDxBBi+eizpClzgJx7Ky8gvaYe8gHTMwKT7afxRN+l3owifKTtfB9qXMQlU4AaEUmMLFmSoaMCbGMgShqne/z0j09svVOycYbK7wufaGim0fUaF+ETkvEhow3oh6SEqCZWKJE4FkTSzTE0cTSbTKXsqj1qdPmYlTOD9GsZVZuvEY30yQrGbQnGWgrRIeUCNZjDrWVZxlQg/kb1osHSvpUcHhVzifvD2JKfamkEgkeykAqP5QNYwbC7cxUvOlE9aRMJKxRlE3JB14x5c2GeeFmN09OPLHHLdaLt7Y0pISSzkJs7GmgJcqLk/KlJj0R9JZaMSrAFVJgKk7kzEiqX9opBJ3ZQIyPEbYxK0BCpqikAgBkih4gA++GmBmzJMxE2UopXLUFIUNFAuPfHj0/S3DzldvXm5plNSPYs1wKfT2iL6T7HRjMLNw8ynWJYH2FguhY5KAPnCnRrbaMZhZWJRTrE1TqlYotJ4hTiHswx1Od5ZwnR+euerDqAklCiibMWWCVAsoJ9rgAaitBF52b0Q6vMETQqiQKV/ETfVmPKL30pwBRN65DkTaKZ++AwN6Zk76dk74hZeFfKf6ulmBcD8zAcQONYznjM/FIbzdlrAZJclVXFnLmo0ppeH+CwJAJU2armrGmoY7g43Q6JmEAZgGuTKLnWvbAFvqsL4eUq5WsGnsAaWB+JJPGPKcGO9yNKtgQJiwXKi7qI1csQDejh66xLbY2cJ8pSWCM2viKFL2LVMSSMMEdoHKDchKAHOppTfXjzgiCl64lXNKpYJ4AJSNfHiIzxdPMJfyit7E2b1AUhfZU+pBoKZkAmgPCJxRlgBg50o3Avrv0rC6ly0JLJmZa2lzdTcqCXL3JeprrHFYyWQFFQSkgMVUcajKpmN6GvCPbHHtmgz+0fhP8pgQP6ST7SPL9oEa0MnThWhcIADqYc4cUal+MM1KrUuQLuPdoByj0ZHMxI3GLX0FxCAjEkkAlWHlgnetazlfiUI8WimTFfWn6mJjoahM84nCLWpImy0LSUZQQrDzBNAQ+uVU0/wAMKNc2WmLVhU0inbDnlgFEFQoptSwLtpmBCm4tpFwwq3EZCW2NnJxMibh192bLUg/xAh/AsY8udFtpzdmbQTn7JRM6uck6ALAJPIgKHLjHq6MT9O/QxWb+kZKSQQE4gAWIDJmcmZJ5JOpgLt092jMw8vDbSkJK5cmY85Av1a0lEwEcFNyUHMM0plYDFfaUZV7K2kwmUdEmcsMlZFhKmOQXFCa0AEIdAulsjqMJh8QtJGJkhICqhUxA6paVPTtZGr63FUTnRvo/9mTPwilIm4Bb9VKW5XLC36yUpwypblwXep5xjDWvDV2bdHcDO2biVYJaVTcBiFKOHXlKupWqqpM27IIsWbzMZT6VugxwE7rJIP2Waex/6armWeFyk7qaV37C5JMpEqW4QhISkFSlEJFACpRJPiYq3pIxUn7FMRiFBKVlAS98xWAChNyRVVN0blZeaFBrxsHof6SrnpXhJyipctOeSo3UgFloJN8rpI4ZhoGy6bhmJcVBYjcRQxNdAMZ1G0sLMLsZgQr8s0GUfDtv4Ru+kW702IUDhL5Wncszy/e0ZkEPG2emzZpVhJKwHMuextRK0KBJejOhPnGMqnJRRLKPtnuj8qT3uZpwiT0owlhIBUWBtvPIXMITMW3dDc+9+ifeYAlLWSakm5uS/H5QsNmFrQF09E/Ts4Fa5U/MrDzCDSplzLZgNQRcCtA0bnhNuYabKM6XPlqlp7yswGTVlhTFJ5tHluThik1EW7otjpkhYmSSBMSzblb0LFihTDiLhiBGaNqx+ME+WpEuWuYDZZBRLBFjnUHUxF0JV74ryAEkgjuu4YPmGtORNiS/jF66O7Rl4rDy58vurDsbpIOVSVfiSoFJ4iITpVs/q1pmpolRZTaKZwd9WbwG+IqEzOjsFFauxIqLEZgS7MeF4dJCrmnBL66JKjzv5Q3RM36Xd7uW8a2f91cSpgBZyABrU1aoILPa0RSkiWlRKyXqQCqrN2SBuY0YXIqYcBTMAXdjf3w3kywgBkhrMEszUpwb3Vgm09oy8OgzJhZCQ5oSa0oEgq93k1AeCaCdQG4vWh+X0IC1F6VLef8AsIruzumWGnt1aj/EkhxbV/ryh7L2tLX2QQd7EK0diH4a+Med5sJdWpalMw9n4QIiuul+2r+UwIfW4/mJ3RjycQHu/E6+EFnYkaD3a8IZDnD3YyEGfLTMDpUoBqXNnzUIdntR6x0W6myTd0PhtlT5wCgGQe6pVAr8rB1WNhBJcnEYWcidLAK5SgpJuCwcukVyMWLtRWjtFm2lMUSopzrDgBIYgjMXUTQpGVNQUpJOUJoM0V7FhQzJZKsqMzHshqvkkoftZSaqOrlqRy482Vu76dd4MZNT21PZO0pa0oxMo/dLTUapALsfxSySDvBJr2Qbts3Ex5u6KdI14KaTVUlR7ctwDSykGwWPI2O8bR0d2rLXLEyQsLlEsCLoOqSk1T+Q20dLN0ORf3gqkggggEEMQQGINwQbiGOExgIvDhWKTvHnAedvTLsqXhsciVJQESxJCkpFkhc2YshO4BRW252h30T9Lc6SBKxaTPQAAJgP3oA9oqLLpqWO8mC+mfEdZtNYFcsqUkfylf8AnignDRqehr/SLp6MVJSjZ+Ml4eYrvnEZpawCAwQsgywbuc3IxSJ3o82pO++ZM9/7QYiWt+SyuKn9mJid6L7TxWCmddJmBKQRnSs/drG5STfwruiaEj0v2ZNlTUzZssyjOAUtBBGSe33oFwUqIK0kEghRDuktCTCEDMosRVI1JFQw3O1fjaPQGw8dgtu4FSWYhuslkuuRM9VSCRVNylTMbEXEYV0o6MT8HilSZ9VXSti0xGihXwbT42Ubt05ljF7GxExPaCpCZ6d1AmdTweMDwOySov8AVflHof0bATtlSZaq/dKlF9ySqXUflyxmOC2aEsks6S1QLgsdbuIxtUbs/YoAs9OWnHWJX+hxuB99N484mcLhKVep40fXiYdTJiUFKVXU7HRha2+gYwXSqTuj7Gg/XnDWXgig218R4RajtGUTiEoGcyEgH2c6gcoD3ZiSbRD7Qwsxipk0AOVKfAkaE+Faxy5dVjjydl/69502Vw7l19Fe08kyZhlHszHmy62WGE0A8XSrnnMaJtHCJmy1S1WUG5HQjiDWPP8AsfaSpM2XMSO1LUFipqBRQfikkfxcI9BYPEJmIStJdKkgg7wQ4PkRHVK59M8XKUglKz2kkjxtd3AZiw0jilmpAbKKBwHo9eLP8YsHS3Z+UiekH2Vtu9U+BJB4HhFZR3S9PM30uK8edrwIeoW9AoOasNw1ZuI3AQltCVnSpLXB0BD+FSfGBIcpAqWJD05UF3vS4qKwYqYX4s1AeRb63aRWF4vZkyTNWgqXKUSrKsEhJc72BD2p74h5U+dhplFKQtJBvqzg0oaNXjG77W2CnEBlVpQ8Bvr5ivOsVSd6OVklpyMu5UsE76El2qba6bliKR/xrivaR/LHYu3/AIYo/vP+1Edjy+jh+lVDQuOf0iqUSUd4huVQaeUIBcFmKehuNwagDPzjq1tmXXo9ldIVlypasyy8zN2goJAyuFPfV3ZnG6D4npM4aWCkAdkDKGVqokB3NXYj3mIVWFO6DysK9h4kx5/Rxen1sxXJrDrZG2Z+FX1kiYUKsdQoblINFDmOUdEloTOF1j008mkbD9JcublRik9Sr+8QFGVzWlypHMZuQEX/AAOIzJSpC0rQrurQQpKuSh9DVo86qkGLT6P+ka8FPZTnDTCBNTfKbCYkXKhqB3hTc0sU49J8lSNozM39oiUtP5erCKfxIVFbkyirkL7gN5J0jcvSF0aTjcIJstOedIBXLAP9bLIdSArcQAob24xgMycuYAPV0SmgHhqeJrEgczsWhFEALO890ch63w4GGS1rmF1En4DkLCHUrZx93lElhNmsagw2aG6K46fg56cRIOVabguy0m6F70mnKhuI3nH4bDbcwIXL7M1Nn70qZR0K/CqnMMRGU4XZoAdmq9hUeIre9YsPRfaS8HNE1AJSWC0OO2i9NCupUOJagJiVV29FoUiXNkLBC5cwuk+qFJTTzQo+MQm3MDkxM0Ef2hIBZmUc92tUbrRe3lunGSu0haR1hTqipC2u6XLi7E6iIHpph2npWLLQNbkFvGhTGSICQmtHvfcee+lo7jcLnSafqINKDlq+V/01h0wINK2vS2/X/eCsnlbR+yz8QiehWWeAHFwoesAbhyeNovfR3GyJmHzddLOVPbUS+Vx6z28biD7a6PoxCWUHexYe4g/VIhNmdCggZVklIVnZjdmZRNwwBHj4cnP0mPJ5jr4+puM1UYlQFQCUu6XPqnuvauVn4xrPoo2z1uGMlXeklhxlqqg+edP8Iii4/ZmUOwHz003b+MF6D7V+zY5LkBC/ulGrVIymu5QHv3x1yaclrcsTJC0lKg4IIMZvjpBlTVIVUg0rVSWp40bw4xpaFOHit9MdnFSBNQO0i43puofW6NMqvhJoYvoovrUqLPXUFMOwvM1xbUMRurzbxiFwsx1rLjtMQ5NgnQ0vT6FZKQocuO/SzU8Yy0WA8zprW9LamtI6tJ091fMHnx98FzsLF9w38SBzasKJoASxFna54MfrwqBfs34le79IEddPs+8fpAgPP20cHkZSS6Fd07jqk7iIaAPTyiyz8MJZJUkKlqopO7cR8QdKREYvB5FULpNUK3jjxFjHqybyknd8oMUn6ekGAgKpv+uUEBMtqmsKQQppmJyp3nX8oFTCC8fpLT/Epvcmw98Nh2oAB1EAaE68gKnwhovH6SwU/iPePL2fCvGG+RSy6iSTqb+EPsLs4mJtWp+hXpOpvsU09pAKpBJui65Y35e8OGb2YZdOehCcPizMlBpM51oAplVTOgGwrUVseEQnR6QqVMQtFFJUClQNiLsa7jTnG3mSjaGCYUU2ZD3RMDhq2DunkXjNVjWztnACqQmtArf+LQO2gI4mJBOzyWYE8ABz86W+JiTGFPaSUEGqSCRcEuki7cP0h7JlOKB9amz6OSbXu7PyiKgVSCGpUBwA1AbNmIrRqkM/hDWcogGz6vfyJ+rxZJsgEMHVwpyLiz+IuIisVh1BJB8hpVquBv8AHjeBVn9Gu3lS1nDrcylOoHRCyQPBKiQ+5RGiiYsfS3BFEtJAJlpU4/ADdJ/C4S261A0Z/wBBQBjUIIDKStBB1GUm1vVjVNk4nMZmEnVXLAIzf2slThKuJoUq4jiIIooXwuz/AL8awsg1+qV+vO8OekGyFYddKoJ7JOj+qTv3RHJm+Y4H3EUp9aQVJAgUDUNbX0315CBMWWBolmF7B95b96sYaS1B2IZtXDg8huGr6jdCwB1G+ru2rf7NzgGmOQC7NW708wzikUfbWHZT1ruIc6uxtpxD7o0Jct7nk9dKgNZnFeMV/buAdyzm1XO/XdfxDwStH6B7bGKwktbupsq/zpofOh8YsM2XmBEY16Kdq9Til4Ymk2qPzpBPvSSI2dKnrFRlu3MErD4hvUWSRwVTs+P1aAiZUN5E7z6oapi69K9l9bKLUUKg7jpGd4acUkCoNiGN60Ya0POtYixLBddBQkv4Cvg8KFVyxNLAXG5/P6ENUTQBS3JtNA16PCkpTkOW3cas1DvJtTjEV1/wjzP6wIcuj2U++BAZ5jcKWIOtWJA7I051a1ReKzNkmWFJUl5RNd6TvG438mi6bQwqSWygEaMzqJu1mvuL0uSIisVg2cEUFw1CTo1m4cKtSN7RVMVJSj10FJqFPccrg8N8R0zHVaWkk+0R8E6czE3i+joUp2VTRJBB31IdvP4RyXshuyE5fLf6x/XhF2mkAnCLWXU6lecSOE2WTp+3h42iwYTZgDKIFX7Lpc+B+MT0jZ4ADaADfWpVbc6RbdwjO10ruE2PZgHPu3uQGBvcw/Ts0CzDd8n1HKLJh8IDZ3q9TcEuxtoacecOF4IFNUgaPTUOWfxPjuibXSs4WSQWuaM+rDdvDWFbcjfeg+1TJXkUews6WCuY3j4CK9OwbPfcH0Peu1hxIBfhAw85mrV6fJjvYl9L8gF46abMCVdenuTGExgT2jRKjlqQWAPEDfWuhL6X8a87aC4rF36O4tGLw6pa6kAoV8jz+cVTHYYyZhlrqQdwAINlA8RWgLEEaQQlMKa9kaMC703N3rt+8R2Nl0okkCg9VnLFmPmOUPvBtxbhx3tqPPVOaAmtA7VpbnV2LEORwgqJ6OIybRw9G+8bzQpPhfyjUekmBWpCMRIH/mMOSpF+2k0mSi2i0il2UEnSM2wYCcdhjb75GvG243jYcGp0iCGkibJxuHC09qXMT4jgdygfhGfbW2UrDzMqi6T3CR3hcjnvYcdYsGGxf2HaJwyqSMU8ySdEzaBaPgeSg3dMWXa+zUT0FCvAi6ToRxgjNpEwBjWh0ZmZ613vrTxh3KVQUY7jpTc4qPHXe8I7QwapKuqW2bRRsU2cHyvxfiVEwBrs1yBfwpr74jR29S4HnXcPGG2Jl5wQdx+uB+r2cZiQz2two9Nw+W+0IgqVwGlqhy2UkUG41caViii7aJw81M1FFoUFpZnJBuxrXfWkbv0e2imfIRNTZaQocHuPAuPCMq2zsxCkFr3OX1lC5N3OnlupK+iPa5SZmDWapJWh9UlgsebHxMVlqS0uGjOOl2zjJmZwOwssrcFWCm93lGkxG7d2emdKUki4P0OMQZpLmGlOArYE3Ys3xhyk1odSGpzelWo1XHCGAlLlrVLUe0lxuBToRTUc9RpDyVPYCrE8xSlSH4ilaQaOPu95/wC3/TAhLNO3/H9YEQM58iiXCWFbM1SbE1ox8PNjN2eKFnq45NV3tvPMWo0qJBFUsSqrE94EMxIvTQN8HMJQoGVvsO65ZuReLs0gTszM4KSpm4ioPBr6ndpBjssOSwYEkvRlByXarVv+GtLTy8LvUKntVc7y+YNZrvqHsYJMkgavQb3rSlABvpbjQQEbhcPlABJICnfV2OobR/KF0StSamwUXOZ3ZzragpUizQ56pLADtBi2ZvVILE6kA2GnIwoC9X72ti5sKJ3At+tYgEqWWBcUGmrG4ezMN+5qVU6hk1LgjlZnNGu/h8DhbFhQ39WurWA9/naFJdA1GqaO4NKjiLVe0BG4qSlLPQsNzBhctQN8Yi8dhyKgONSC7G7VFdbWLE6tZUpYvlBO8h2B4hjl0bhDKdKzHv1Ng7g8vMCjRQOg+0zKnpSSWV2S+8DyDUDDjui99J9k9egTED7yW5T+JOqfc44hrExlGOkKlqExDAguDShFQaWqDpVzpGtdGNqpxEhExNlB23GxHgQR4QRnpnCzbizF3D7yd9vGOpIq/m3i96+Fn8IsHTTY2RXXoT2FH7wAB0qJ73I68TxpXJUwbi1Xq29vGCkwP/NYUuP6+UBX/wBRIsLfXjqmy5joEZdKrNwyv/yJJLafeoBceJjSNkFg0KiF9K+xlYjALmS3E/DHr5RF3QHUBvdOYNyh56POlCdoYNE6nWJ7M0blgV8Dcc4sbAhjUG8YRsTFK2NtiZKJP2abMyK3BKzmlqHJwOXKCNm25slE9DKoRVKhdJ/TeNYzrFSJmHmFE3M9SFJSSFB7g2bVqMfONYBeIzbWykT0FKhxBDOk7w8BmuXrFdogpYsjR98xW8EHsJoNc1CJAKJBFam543FXJteC43ArkKyrLv3VVZQA4BwebNRnEElLf31LO78C276uaGxKqEuwub0GloqWOmrweKl4lHqKBI3psqnHwtxi2E2s9WBJaprTwEMtqYPrUqSQDuJIuxDBquzQSxqmzMaibLStBdKkhSTvSoOPrnDoxkXo56TjCrGBxByjN90o2GYnsrewJZtxLbo10KgihdOdmAETANQFciaHwJHmYrktIUbhjXU1000qX42rXQumJT9mmktRCvgw95EZzh10qQHZiH8qB6OG57zBqJDrvw/9qYEN8nFcCIH4Aoz00rY0NjfjxO8wUJL2SQ77yCxJG9nyh3GvijQXJDpZwf3qCSWPGCqNXyk0B4Em5c1CbQCiFAODQaXZr23GtLQTMSTQswIUaUJII94HjHJaTbQF+y4dIq5F7ne1xwgAAEFsp3sGBLXNmLvVnzNwALoyp/C5GpNWZqG7gAl4E5kgWKrC2Yh2ZTlnD79LmOEkJArVyGApY1dmqDYNxdjAWsk5SAzFxRi9uSaOCWNRRhADg4bfYFhu0LNQeAhYTmp4Xq7keZNKeNoKqWq4cVpZ97Eb33Eb6xH4vHpSU9YMqSsAupJbMWALc08IluptLdCzdrffJSpLSVA5D2iQ2UZlAmgOYX4E3LPQsHMpJCgoO4YAkBhUdkji/npCY2Yr7W7goWGTyS5CX5g01A4Q82Rs9CypqKJdKkGqUjiKEEmxd/OOLHqrL/U55zWe4VxmDKgqgfUAWNDlAYZhc8zeF/RttAyps3CqNj1iLVFBMFKXKVN+eE5a1EqlTAOsTRx6yT3Sxq16aVDERGY9SpU2XiZdVSzmI1UjuqSzMHTmSWPlHdLLNx7y7m2zKSlaSCAQoEEGxBFQYzTpHsZWFmBnVKWewalqVSptQLEmsXzY+NStCVJVmSoBSVb0qAUk+IIh1j8EidLVLmB0qFfkRxBqIoyczMpST6qkLfcErSTe1X0jRcKtlkcTGf7b2SuRMVKXUEdlWixYeLXHCLfsnF9alE0esA7aLFFjmFhQiVVokTHjOfSpsFMyYiYUg9YnITxDke4nyi/4ZD1iu+khaOoloJ7apgyh6sAcxHJwPERIGfov6QLWhWDnl50gdlR/tJR7quYcA1+MXwiMbllaZiJ8rszpZdJNARqhbeoobrOCKgRquwtrIxUlM1Dh6KSWzS1jvIWBZQP6ihjSObT2emYkpUHSb/qDoeMUTaOBXh1srtIUCErs24ED1hVtLkcNLIiK2zgAuWtP4SQdxAcEcoCgosw8r8HYGhqNeLQcuzEjm4r+nJ9IaYCdmT4ag7npr5aQ5JpV61oQXIFGdm13G1NINIHpHsFM9PZASRQMGYau/jvZiOIa4DpNtrDASkKRPQLGanMoCwAUCCR+YmLMz3YvQaXqWpXSz2gpfMX3k1y1BbQFmo2tCIGkCrGY/FrCsZMGVJdMlHZQ4N1N3iHo5bXSJORIIBqXF3BofCwvR4cMWsxqwodaO9Nb13czHgPMkBher2rbV2pEBcqtx8k/rAhDq07/APD/AK4EA5MwBjlq9/PUsHd2HuaEAoBilJIL9oOTU5iADQA6O1IVSXU4CcwLAltw1vrXgxpBioByezXe7vS5uK0rAdW71oSpkgbrPQve4DjnBZc4vZQDAkF6FmKfVNwK1FL7kgsdlIzMKmzMSwBoxs2YVfUwhIkpAKC+UAAgA0cucrmrvYeMA/mEAsBWhYEUUKdpyBUNWupu0GzjMEm45lmAcOKPyrw0gsuaGooEChBDUDjU5RcBjThHESzZRoWBAzOSzhkEBxwcnneAOZpZwkneAU8HDGtuFtHiB6SyBNQpEwBb01GW7Es7VBqfOlZ9CsyGSUgasGNxf5NCRwoI8XJddWp3gzW3Hk0BnGGx6pP3M9JKPVUSHCbhjv8AfveLZsnbpqtBTMCh3nCSAKDsqbg5p8o7j9hJmugpIrR+FLWOtq1tFe/8PpZWe0WBcirEHdr7o5uTpsc7t59icwG3ZeIxX3as5CCle4lJGVrBnUrhFgmygQA7g2dmLi5G5vqgiu9H+iiMMtRSFHMQ24NVgQXuQeQEWMLfsgkaqBu1nDmmse+GHZNRqTU0kuheLKAqQq8pTo/6Ky4/lWVDktAi+SJjiMvlzuqmomElk5goAd6WoAKAcOTQKG8oEX3ZeJ0cHcQXBBqCDqCGPjGwvtvZSMRLKFM4qlTd1Wh5bxGWT5eKw0wiVN6uYksuWoJVLWbA5CaOG7QILC8bGIp/pEwackufQKSsJP4kqsPAj3mCxWJnTPaqU5QjCA2zBEw1t3M9DV7wxUJs1ZmYiYqbMIbtMnKAXZKQwSBUsNN8K4RGYl7E9moNXIoAWOgdt7QssF25UN3JrTdRt1niLpzqqWd7by4td3tUO7aPB8JtGfhl9bh1JUo0XKVmyTQBRlswmVoqpa4UKgBIAqeFAdTRxYeFIOLsHBZn0CRorhwBfmIpU/h/Spgsv36Z8hYd0KlLVUUoqWFA+64tEL0g6crxiDJw0tcqSoduYtgtadUplhykGgJNb01hHqk5netg4cl7ksG91NeBRISO0BdnYCjWzAEdm7E0qOUE0TwaQK1YMRwcFqW/3PGHKCwqA/4gzsWHjeE5KahiXJejd4sHZI0r58o6nEs6WD90uwuxNKh6g23axFGKqsDStGoDXQMGL60bQNBVLegBY2Y8PeLUg6nLt2t3dDir2o1hS4F6CEpZGgUUsM3Z71OzU304QBgbk6mpCfMV3anjwjsxLVDClTm8B2TTLelNd8FWkCxAe+rge5hUVcAR3rg2jWOrvqPcODHUQCX2hf8AeI/l/wD7gQem8/yTf9McgAVi5bNZwRYWSFFnHDnyjp1SAObDiQCbE3sGpDOZiE90vmszFt4BIFKEsNYUoGZwxYENS9BSzVox13wC0ySoKDlLtUMKajs6jVy7MRWjIJmhJ7Sg9AHLggUBSAbM93LQph8QFDq1Egt2TYpLu1QXSMooX+cDqFiiVqKQCQEgmtnZDdngBW+rQHcPNzEp7VwCzADVgEgaaAG9tSotKmBShR1oW10cgNq1bWAAENypVCgMAbEXIJcEGgLv8qgQtMxb5SbJJLEmhJfXW/jwgO9YknLlGdgoM7sp7GlC29qOxaDgKNQzEPdjenZNBzG8cwUqBoQlfrZQmva0Llg+6obcI4Flr0IZw/kpLd2rPrWukAvKIAIzMPWJYk1dmVQMDY/79Pg+uUEPZPdT7y1KGgEFB7pFQKBvHV6D61jqFUZ73NnpSnjTxgOy1UYKAo4qlsugDcATXTK8dygVcnQlxU8NX4eOsJiZozjx3VJbWxr+0FLVKm/ioB8as37wBxNZ2atHIo+rKakG2d0gOGATMSpctz20uTLDksUGqkXbK5DsxDMjNLVpZmc3ZyH3WDaatCSlA95gN70PEbzXfrFFtR6RdmhL/akqLdxKZilnhkCcz8xFR250jmbQWlkql4dJJSg99ZsFrAsLsONb0RnoABoBqWar01o7hvGDIOj8aEs3EEu3naBopIlUFBTyTXVnBApTnCz5nGUDk252e+mnCESkGj+9iNzPxg5GUFlADead7jrTQRAsgpYl3ah7zUvvMEmUJDsRcVqVHUCjVJGnKCqq9tCkJO/dYvpUaRycBZyEi7kAAOHD6afOAXJsHIFRR7OGbeXd23wRAA7PaHvTXe5O+xpeEQlTvTM5oaCxfLfXfzhzLsGD+QI0PKzachAFMp71AqBxdnBHjXgIMqU1r7wW11LvxZ7GC4mYSCEmpB7LkWAfMwcWHhEVsfErEtIWO1XOos2YkkgJqzactaR5/WwmXbb5bnHlce5MTJLgEXahsbjXUfveEFy8oZ2VVwEntMXZPmaD9oKhViQkNUnMSxZnc3pvY6PSAEZt2V9Xqxsommn70r6MFAoi5NSPGlWZtN7aUpCZma7zoRUWa+5rEBydIIVg3ANHNcrgGlXJFaU3x1KiNQWIO+oY3TxKnp+wK50/i8v3gQn1x9mX5p/0wIA2H/q1c/1gmF7qeX+VUCBAcmdz+EfOFtrd5P5v8ojkCAdY2/if/jiOw/8AWzf+mf8AGmBAgF5fcR+f5GDYS8v8yf8ACqBAgDGy/wAx+Ajs3TkYECARl2P5lfGCeqOaPiiBAgOybD/qn4KhJHcV+c/EQIEAkLnkfgYdTe5L5j/EI7AgG02/gYeY25/N8lRyBAJTv6xX1vhTG6/mm/KBAgIqd/nH/wAaYlE2HNX+COwIAH/mUflV8BDebaf/ANQf4UwIEfG5/wDbn7O/j/wVyZZPJX+aEFf8v/8As/zQIEfZcCUxlz+Qf41QWV30+H+COQIAsCBAgP/Z",
    rating: 4.6,
    stock: 90,
  },
  {
    id: "44",
    name: "Wall Clock",
    description: "Modern wall clock with silent movement.",
    price: 29.99,
    category: "Home",
    image:
      "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxASEhUQEhIVFRUVFRcVFRAQFhUQEBUQFRUWFhUVFRUYHSggGBolHRUWITEiJSktLi4uGB8zODMtNygtLisBCgoKDg0OGxAQGy0lHSUtLS0wLSsrLS0rLS0uLS0tLy0tLS0vLSstLS0tLS0rLS0tKy0tNS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAAAQMEBQYCBwj/xABJEAACAQIDBAUHCAcGBgMAAAABAgMAEQQSIQUxQVEGEyJhgRQyUnGRkqEjQlNicrHB0QcVM4KisvCDk8LS4eIkNENjc6MWRFT/xAAZAQEAAwEBAAAAAAAAAAAAAAAAAQIDBAX/xAAnEQACAQQBAwQDAQEAAAAAAAAAAQIDERIxIRNBYQQiMoEUQlGRcf/aAAwDAQACEQMRAD8A9XoopagkSilpKEBQKKKAKKWkoSFFFJQC0hpaQ0IEpDS1yaEiUhoNJUkC0UCloAooooApaSlFAFKKSloBaKKKAKSlooBKKKKA7paSlqAJRRRQBRRRQkKKKKAKKKQmqykoq7Jim+EFGWq3bG3sNhVzTyqmmi+dI32UGprD7T/Sc7ErhMNffaTEE2v/AONDqP3qx6k5/BGmEY/JnpVhzosO+vGZ9vbanP7Zox6MSrGPA2zfGobbN2o1ycTiCbXs2Im77fO0Ghq3TqvchlBdj3HIO+k6sc68Nj2dtLemKnNt/V4iXQ8jZqlRbX23ARaeRgPmyBJQfWXUt8adKqtSGUH2PaDGa5rzHZ36UMRH2cXhg3N4Lxt3dhyQT+8K3OwulWDxmkUoL7zE/YmA49k7x3i476jqVIfNceBhGXxZaiiuynKuDWsJxkuDOUXHYUtFBq5UK6rmuqAKKKKAKKKSgCilpKA7paSioAUUUUAUUUUAUUjNamZJbC5NrC5J0AA3k1SpUUFcvCDkzuWUAE3AtqSdAAOJrA7e6aySEw4EX4HEkXH9mp3/AGjpyG403trHy49+qjuuHB9RlI+c31eS+J4AXmw+jioB2RVKdFy90/8AC8ppcRMZszoo8zs8zMzkglnbOxBGjG+vAjX0a2Oy+isQ3AGxsbWNiOB76sdiYBRtLFgAf8tgz4l8YL/AVYdDIFC4kAAWxuJ0AsP2l66DE5w+wUHzarMBsdDtHFoVH/L4JrW3nPjNTz80ewVuQoqoxGxCZZ5kneN54oosyBS0awmQqyZgRm+WfeDw5argpItiZ8c8yiyJB1Dm2kkxkz27+rAIvzmYbwwqfPsRT80VL2bsaaJlJxs0iLf5BkwyRnQgXMcStpe+/eNauLUuDBbR6KRuDdR7Kwu2OhyiQrCwEiZXKhu2im+RtNQbqbbtxr3N4QayfkYO1MQtv/pYU/8AvxgpcGF2J0zxWEYQ40NLGNBOBeZB9YD9oP4vtV6ThcVHMiyRsGVhdXU3UiqbbnR1HBBUVjcFJPsyUlQXgY3kh+9477mHsO48COepR/aHDNY1O0tHp9FNYLFpMiyRsGVhdWHEfh6qeq1KpmvJWcMWIK6pKK1KC0UUUAUlFFAFFFFAVWwekMOLzdWGDJbMri1gb2IIJB3Gre9Z3oamFWH/AIaTrNbyORlkL20zKdVFtw+/U1oAaypOTgnLfghHdFc3pb1oSLXDyWrl5KqtoYy2g3nQDvOgFATVlzEngPiazXSTEtO/kiXyCxmYfOY6iL1WsW53UekKu8fiPJ4CwF2AAUHc0zGy37sx15C/KoPR/ZBGUliTqWJAu7sblyed7nT0q56a6k83paN5eyOPck7F2QFA0rT4bDgVmOje0XlXCwsxzzR4iZ5AAp6uCZY8ot5pJlTUDch4m9W3R7GS+U4vBytn6gxSRSkAOcPiFYqr2ABKvHIt+Khb3NyeowLDDbKVMRLigzFpY4o2U2yBYTIykaXveV768q62TsxYBIFZm6yV5jny6PIbsBYDs8r699TqKgBRUHbU80cLvCueRRdVyl7nllBBPgaiPi8X1KOEUuVkLIUYdpUcx2Ge63IUWNz2uBoC5oqnmxeLVmAjDAOQCFserKLlNi2pzsbkcEOmoNTtnySkHrVCsGsMuqsAq9oa7ib79RQEqoa7NjE7YnXrHjWIm/Z6tGdlFu4yOb/W9VTKKAjYjDgisztrZSuCCKuOknSTB4CLrsVMsa/NU6yOeSINWPq3cbVl9kY3HY+frpIfJcHkITDylhjZWbdK2Rh1Q3aG/HmCJBTbCnbBT9S/7GVtOIjlOgI+q2499jprW6BrEQbOabDdZIxcFplidmLZ8J1z9Q7cGJjCnNvIIN9avujWOZ4srm7xnIxO8281u+4tc8w1c1VYSVRfZtB5LFl1RQKK6E7mItFJRQBRRRQBRRRQGJ/Rvs+NY2nBfrHGR1YZUABuCo+cDfzvWNNa1sOOiZ2jWRS6mzIGGcHvXfXi20HkgxEow5kUKzRl7kyZfNOZ++xPs41XFSQxLDskdj57E382w4WuSbDxIFefH1GCxS0ZqVuD6BDUjPXgWHkli1VpIw637JaPOtyAdLXFwfZW86GY/aDKrN8rAzMM8rHrUsB2lZtWW+ltdx3WrWn6lTljYspXNli8RYVT7OfrcSOSAueV9y/E38KNqYiwNc9DBcTSc3VPdGY/zitqztBmtNXkiZtT5TEJF82JetYfXfMiexRLp9YVotnQZQNKotkpnkml35pSo7liAiI95GPjWpw62q1FYwSE3eTMvsvYeKhGCxAju8AxEU0GZMzYfESZwY2vlzKyRmxIBBbW9q0mAwRWWbEstnlCLl0uIog2RWIuL5nkOnpAcKsENVu0dosHMCoxdk7DIyXBN9SCDltYm5BBt67XKGIwf6SZsJOcNtiAQhmPVY3D5pMKQSbK1xcWHHfxKjfXo+FxMcqLJG6ujC6uhDoyncVYaEVkNu7EedYo8QIm6w9WUIJDN1bNmcDQ/sydLWvpavOptl7W2HL1mBJeBmJbBsTJGeeUb+WoOfdfML1JJ7zRWJ6EfpKwW0LRE9Ridxw0xALMN4ibTPx00bQ6VtqggKKi7PxfWqzWsBJJGO/q3aMn2qayvTf9JOB2deMnr8RwwsJBYNwEjaiPeN9zroDQGxnmVFLuwVVBLOxCqqjeSToBXm21v0ky4qRsHsWITyDSTGygrhIQTbNr5+424G2gest+rdrbcfPjnaDDqbpgUuitbUdZxB72uw1sFBBr0LZexThsmEgKovVu6RrGqoChRTmO8k9YvaNzob0BXdGugypL5Zi5GxeMO/EzaqmtwsMZ0QDgd/LLe1aLbGDxdlSCKGRCD1vXzvh2I4KMsL3B47uVTNnTGIiCQEG3ZkJZlf8AebW/rJ4cwKtEcMLggjmDce2gM7HDiGQ+URwxncqYeR5ly23lmjS3qA4b9dKPDx9ViRykBQ/aF2Qn2OP362+JSstt2HKC/oEP7hzW8bWqs45RaLRdncskNd0zEadrOg7wLVVaQtFFFbGYUlFFAFLSUUB442FxJwcplZgqTqypMcraIyyZM+vzl0HI8aiYbYcj4fypSgGdlCMyozKADdST2jfMLb9Ba9d7Y8qlEUswds0KFTlutjpoRpc2zHj2hT+zdjgyR4adzGSQShBOsliBcGysVyDXdpyrx5cu1vBjYj7N2pMGhw9kkj6xVEEsaSLd31tmFwbnfevUpmCiwsANABoAOAAptNjYcOJhCgcbnCgG9rX9ffvrnGV6FCm6as3c0irFDtefQ1bdBx/wxPpSufuH4VQ7WGhq96EH/hR3O/8ANf8AGnqfgb0fkWeyJFiwrYhrkKss7BdSRd5CB361I2htaaCODFlo3gkaFJkVSGRcQyJHJE9+0AzrcEag3BFrHro5ChijJUEqroCQCQM2VxfgDkF+dhUeTozGwiw0QkXDRzJKyyO5QCJxIkMKMbhS6rcnQKCF36dC0Zs0uNcBGurMLWKp52U6HiOFQ+jMAEXW63k1s3zVGiqCdSAALXvwqfiIyylQ2W/EAHS+oseYuPGjCQhECAkgaAta9vACpIIO1pk8pwkZYBjJI6qSAzBIJFNhxt1gqfjsGkqFGGhFjuv8ag47CYdsTDNImaWLN1clr9X1vY38M1rD1VbVAPH+kX6O4cWrOiNDMpJOIW3akB0Dre7GxBvoe/hVVsL9Ie0tlSLhNpo08O5JwbyhRYEpI1utA0uHswuNdwr0D9IGJxOAwr4rCAyuCM0UhzIA9wZcireQi66XAsL62N/Gj0U2jjM2Mx0j52AyRtbrLk2UMtssS3I7IF9dwqSUXs3Tjau0R5Ds1DAgHy2KzWYs5LOxkH7MFixAW7m2/eK0fRz9H2HwUTTkdfPpfESAXVmIW8SnzTc+cbt38KxEvQzaGBmSXAyMGZgutgQSbdq4yunEgjTkd9fQEezxJEiyNfsrnyfJq7gC5tclRmFwAfbUBnWzNnLEiqBuHx41FXExtj+qDrnjw2YpcZwskg1tvt2B7RVyBbT/AFqkSbDjaDKI1E7YdS03ziiubR+G/wAaEE/a+GDxMCCbAsMpscwBtXeyyDDGQoW6g5VAVQbagAab71IkQMCp3EWNiQbHvGopjCYNYrhS1jbssxcC3K+6gGscHuT1ixxhSSxALZuZLdlVAGumt94trmsPPJNh08oVUmkWTsC6Z41cqJFRiSoZTG1iSVzgGtFtTqWBjmiMiEXsYjiEO+4yqG19Y46X1rObAwT4fDOjKUQSzvDExuYsKZGaGM8rLqF+aDbhQErAvdUPNQfaKmVB2etlReSgexanVzem+L/6bVtoWkoorpMQpKWkoAooooDxXEYvEyYi7FllDjJEt7o4PZRU4WsB+db/AGDhxilXE4mACZGsrEPGxyaqxQ2G8949W4d9EtnkwQyzoGkW5idxeRIj5ozHXnbuIrSgVx0KH7N77MpFDLjSqvGCraQVV4wV1lzMbUG+rHoHL8lInoy38GVbfFWqHtFd9MdD8TkxLRndImn201A9hf2VlXV4M0pO0kbzo2bJInFJpAf7Q9cPhKKvFNZ3Zb5cSy30mjBHISxGx8WV18IjV+DV6UrwTImrSY8DXV6o8Tt1Y1WYoxhaVYutUgkM8ohVinoZyFuNdb2tVyDWpQi4jCEyCQBdyhrs63Ckst1GjWO71nfuqdEoUBRuAsOOnjXN66BoCLj8P1gsd1UmO2cqiKP0547f2ZM5+EJrSmqvF64mFLeassvqZerjHwmf2GoBKTBrxFTUFhauFru9AdVVy7JDTGcrEXK5M5jYv1fols/4VZXovUAUUhNITVP0q2s2Fws86KGkjhllVG835NCxLW1yiw8SBpegLVzVPto/JOPSXIPW/YHxYVZCS6g8wD8L1T7XftIneXPEWGgHtII+warOWMWy0VdpHEG/wqTUfDDeafrL06tAvVd5C0UUlbmQUUUUAUUUUBwBXQFAFLUAakqsxgq0kquxQoDO49KzmIkaKRZV3owYDnY6jxFx41q8YlZ7aMN6A2jzZ0SeLtFcssfC+mq34ZlZkPLMa0WHxiOEKXIkUurBTbL2Tqdyt2tx10PI15z0L2na+Fc82jJ5b2T8fE8q12zMR1T9UfMkYmM8EmbVkPc5uw+tmF+0ornpPCTg/o3n7o5IpIoz5Ou1cOdHcTybOY58O0hezKik/J4oMd40Mg1W+o9AqBFhYgxcRoHJzFwihi1rXJte9uNSw1dRgPA10DVRtDbkEDBH60sVzWhw+IxNlJIBJhjYLqDv5U9sna8OIDmIv2GyOJYpcOyvlV7FZUU+a6ndxFSCyvVbBdsVKeCxxIO5y0rP8DF7KnlqrdkG5mk9Od//AFBYD8YT7aAthS3rjNRmoDu9F6bLVTzdJMOrmMicsGykx4TFyR5gbECRIihsdLg20qAXWasv032bI+ExrJNNmfDSqIEWJ1Y9UwWNQYy5zEnQNe7G1q0l6KAg7PDLHGrNJJdbmSQRrl7I0YKFty0U99VEk2dmk9KwX/xjzfbct+8Rwqw21if+iDv1kPJDuT1nj3X3ZhULDLc35ffXLWeUlBG1NYrJkqNbACnBXIpa6ErKyMm7i0Ul6L1JAUXpL0lAdUVzRQHdFFFQBuSoGJqe9QpxQFRiVqnxkNX0yVAnhqQZPFRMrB1JDKbhhvBG41sdj7TTFxEMAHAtIm6x4MvEDS4PAjmKpsXhqqPlIXEsZsw9hHFSOINZVaea8l4Txfg9P2XjjcQynt7klNh1qjWx5SAbxuNsw4hbZWrFbL2pFiktazC2aMntAg6MpGu+xDDUG241dYbaLJ2ZbsvCUC7Lw+UUb/tDxAtc1p1v1lstKHeOi2x2NEUbSkE5RcKvnM25UW/zmJCjvIpNkYcxRBWIZzd5GF7NM5LSEX1y5iQBwAA4UwFEtmbKyK6yRFGLKwCgqzaW0Ykgajsqd+6YHrouZEhpABc/0KrNjzqmGSWQhAUErljYBpPlGv8AvOaXais8MiKbMyMqsdwZlIB8L1SdJXPXbPjvlibFHMdCOsTDytALHQnOARe/aVTbSgNXDPmF7MOWcZSRzynUeogHupzNWd2fNiI8W+HkkM0LxddFI4QSRurhHiYooDKcyspIvo4JNhV3noB7NWR2v5dgo5MWuKEsaO0j4NoERTC8pZkjkU5+tAbQkkEgaC+mozVXYnZaPY9psjB1jlkcwh1NwzLftWOoDXAIUi1gRALjdUTaO0OrGVbGQ7gdQo1Gdu7fYcTpuBIhYrao3RWP/dOqgfV9Lhru9drVWoCxNtbm7MdSTzJ4n/SsKlW3tjyzWFO/L0dRIWNrk31Z21JJ3knn/W4VYqABYU1EgUWH+tdZqtSp4q72ROeXC0OXpb03mpb1qZnd6L1xmqo6Q7aGHXKusjA5VtmsBvcrxty3nXlUSkoq7JjFydkTdo7UhgF5Gtu7I1bU2BtwHebCqaTpUDbItuGVvPzg9qM8A1tRvBrHyyOWMjtmzXJZu32SdftxHlvWm3v+GW+p5IW5jercd1cU68nrg7YUIrfJsf8A5F/3j/cN+VJWO8pP0kv93/toqmc/6X6cP4euXovTUz2YimzPXoHnDzGosopmfaUStlZwCRezG2m696hY7bkaECzPcZi0RRlUcCbsN+u6+6oyS2Sk2SZEqLLHUWDpHBIAyrIVIBByjiAd178RUmBlk7a7m1HA23aima7EuLWyHNBVbicJWhaKo8sFWKmPmwrKwdCVYahl0Iq52b0m3JiBlP0qjsH7Q+afh6qkz4Sq3E7Pvwqk6cZ7LRk46NVh5R58T2za3Qgo3eR5p9e/vqdHtNho6X+tEbeJVjoPUzV51Hh5YjeJ2TmB5p9anQ1Y4fpDOukkYb6yEofYbg/CscKkPi7o0yhLZvV2hEd7hf8AyAx/FgL0s8cEyGN8kiEg5bhhcEEEciCLgjUEA1kYOkUR3h0+0t/5b1KG1IW+cD6wfxFT1ZrcR04vTNJhVWNQWyq5ADEyNLuvp1knaYC5tfmeddnHxemDzCfKHxC3tWdTFR/Nt4D8qeDs27+vbTqzeojpxW2Wsu1PQT95zlW3MAXPgbVX4jEM/ntm+oBaP3ePiT3V1HhCd5qVHEq7h40xqT27IXhHXJHjw7Nq2g5calCw0FIWrgtWsKcYaKSk5bHM1GamS9AarFR/NS5qYDV1mqQO5q852tjOtnkdt2bKuuWwU2S/ok6kMOJsa9CVq8xaSzMuYaMRY5DuJBHn7jyNc/qHwkdHp1yxwuL8d50As2Yb2A4SDiNzDnTWdRwFra+jlPEfUJ9005nU6XH8N+7XrL3HA76QgE8b77gDQ8SO3oTx4HlXGdgmvKT+8X86KXqF9BPc/wB1JQHpW15MrDvH3VXtiqXpNiLOq8l++35VStPXoNnmWIjSdZjZHPmxxogP1jdn+BWqkS/Jzz8XLEHuUtk/hK0/gJcsOIxFtWeRu8lPk19oQVGxPYw4Uekq+u2RD/Ka5JctvykdkeEl4ZY7JhyRqOAuf3e0w+Fq1exYbRIOOUe22vxvWcENo8n1RGPHKgrS7MxWYyJp8mR69QDV6HLbM6+kiYyUy8dOljXYrqOUgvDTD4arPLSGOrApnwVNHZw5Ve9VSiGgKNdljlUqHZa8qtlip1UoCFDgVHCpiRAV3SE0AE02xpWNNk0AFqbZqGNMs1QyTotShqZvSg1BI+GroGmQa7U1JA4DXm+24XjxMq3Ni5cW6w9l+0LWuONvCvRwaoelexDiEDxgGVBoDYZ03lLkaHiPHnWdWOUTSlPGRk1LW3nxEn4iuWUntX+7x1sDaoKTZeyVykaEbjv3MOHqqahB/rQd5tx5CuNo7Uznrvs+6PzorrL3t/DRUEmq25is87nlp7N/xvVPj8UEjdzuVST6gLmhpCdTvOp9dQsZ28sfpuq2PFSwL/whq62cKQ/iIjHhYoSdWMaseeXtOT68p9tMYkX8nTg7Zm7gwZj8WFPdI5flFQfMQm31m0H3fGiRR5Si8Ejb3tAv3H2VzaivtnT3f0i2J8wc3B90FvvAp/BiZJ3mRcykAMp0zDKNx51HTV0HIE+Olv5TWj2Yuh9f4VrQXt+zGu/cNQ7RU7+yeKm9OeXJcBTmPJQWPw3VZmFT80H1iojRhSQABflXQkc49GxIuRY8q7ApkPXYkq4HAKp+l23PIcK+JyZ8pUBb5RdmCgsbGw15VaiSuZQrAqwBBFirC4I5EHfQFf0V22MZh0xGULcsCFOZcymxytYXHhVxmrLbRwUuG+XwQ0GsuE/6brbUxD5r6bgLHuO9nZXTiCY2IKnlfte4dTr6OaqOaT5LqDaujWlq5JqpwWPDuWDaEjLoQbW0uDu8auQ4Yanx9e61VVS7JdNoZZqbY0xPiMpy8eXL11Jw6ZtDzt46+zS1Wc0nYhQexljTRNOYxcht7OdOwopsLXPLjajmkFBsiUorjHzRxas6qPrG2vIc6o9o9KoYzYAse/sH1hD2vaAO+oc4rZKhJ6R30s6SrgURymcyOEAzCNRpckuQbVc7KxqzxRzKCBIiuA28Bhext66pMHs5sV8pjEDJe8eHcXS3B3Q6X5A303k8NHGoAsNByGgtVou6uVkrOw6K7ArgV2KsVKza+wYZ+0RlfhIBc/vDj9/fWcl6OzxnSNZBwKEi37twf631t6KpKlGRpGpKJg/I5v8A8z/3RoreUVn+PEv15HnjGmNnrnxUYtoitJfk1si+0O/sqsbakp+i9p/zU3g9ryxSO6xI5dVW5lEYAXMRYWN9WPsFVlynYmCs7ssZJesxJPOVR4IRf4A1LwgvPK3CyKPXdif5hWXw20JY3DZEazMfPCsbgi5Oo41a7K2uFDl0IZpC1lZGAXIgGpI4g8KynF9v4awf9/ppsI15T6reoix/x/CtNs09k+v8BXnEW23D5kVdRqHbXNmbdlO7KE+NX2zulbKtmiUm97rKoXcBuIvW1OyikYVU3Js3sbaVC2hoQedUI6XtwgXxnQfhTGL6USPb5KNbcTL1l/AKLe2tckZ4svQ9LnrNjb8nox+8fzoG3pfRj941OaGDNNnpOsrN/r+T0E940fr+T0E940yRODNIXrFdLOiTSM+JwpCyMD1kRvkluLEjWyta+hFibbtSbA9IJPo0941w3SR/o1941DaeyYqS5R5+u2p8O3VsHjZDYx/s2sBobNofWNDffar7Z3TycCzSK265dL3JNjqpNv67qsNrbSgxC5Z8PG9txJOZe9WAuPCsZtDYkVyYZMgJvkkDSWOuiuACBrxBPfWPTXY2VRvaNfB0vJfOyKxZiey4tlubGx3DTdqdPbZQ9N2XdAdCFNrFj5ouBfUaj4cL15QyTKbZb23FMxFjwGZdONEc8wP7N+O9FYb78u4VXCS0y2UXtHqG0OljlnkyAMgCmMsMpFyQym9iN1zfdaoR6YSMWswFyoAQF7hgNdACCMw0429uFjWVrrltpcMRaxyro3Z5jgKudk7LTfM5e+uSO69rT57KdNOAFRg33LZRXYcxO2JZnCgvK+cZVW+YgFdCBfMNbm/I8K13Rfoyy2mxCqG85YQNFf0n4E8hwsOO7nZm04IBlhwqLzIYl2tp2mK3bxNWC9JW+g/jP+WtYQiuWZTnJqyNEBXYrOjpG/0H8Z/y12OkL/Qfxn/LWuSMcGaIV0Kzq9I2+gPvn/LTi9IzxhPv/wC2pyRGLNBRXlX6we7Wk+e2lwbdo6UeXSfSH4Vg/Uc6N16fjZ6pSV5b5bJ6fxH5UU/I8D8fyYeeYoLuhUbgbnfTX6xXh+NWXSGPsL9v/CahQQAndU2QTbG/L1NPr1jAFYyQdQQDa1Q5oBmP9cK1mycN8jH9gfdU4ohzZn8k30Tew0FZvoj7D+VavyajyamJGbMsFm+jPumuurk+jf3K1Hk1KMNTEnMyhjl+jf3TSdXL6D+4a13k9L5NSwzMgY5fo390/lSdVJ9E/un8q2Iw1Hk9LDIx4jl+jf3T+VKEfjG/gh/Kth5PR1FLDIyFm+jk9w/lSEyfRv4o35VrjBSGGosMjIXk+jf+7b8q6Dt6EnuH8q1ZhrgxVNhkZZmb0H8Vt+FciRvQf2f6Vpmjrgx0GRnOub0X92jrm9F/drRdXSZKDIoDim5Nb1U3+sBzPt/1q+xSdhvsn7jWKKbqlIjItv1j9Y/D86djx7NuLH1a/dUePBDKKuujGDAMlhwT/FSxN7FacQ/JvYaQ4huTeANbVcLTyYWmJGRg/KH9F/ZSV6F5JRU4jMyG3/MX7f4GoWH3j1D7hRRVGWiMz+c39cK2Oxf2Ef2B91FFXRSRNpDRRQgBS0UUAopaKKgC0UUUAUUlFAcmuTRRQk4NNNRRQDLVwaKKgHNJRRQDGM8x/st9xrGDeKKKsgXUXmD+uVXvRjfJ6k/xUUVES0tGiWno6WirmQ7RRRQg/9k=",
    rating: 4.3,
    stock: 85,
  },
  {
    id: "45",
    name: "Plant Pots Set",
    description: "Ceramic plant pots set of 3 different sizes.",
    price: 39.99,
    category: "Home",
    image:
      "https://images.unsplash.com/photo-1485955900006-10f4d324d411?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.4,
    stock: 65,
  },
  {
    id: "46",
    name: "Lipstick Set",
    description: "Set of 6 matte finish lipsticks.",
    price: 44.99,
    category: "Beauty",
    image:
      "https://images.unsplash.com/photo-1586495777744-4413f21062fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.6,
    stock: 55,
  },
  {
    id: "47",
    name: "Face Serum",
    description: "Vitamin C face serum for glowing skin.",
    price: 29.99,
    category: "Beauty",
    image:
      "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAQERAOEBASEBESDxAREA8PEQ8QDw8QFhEWFhQRFhMYKCggGBolGxMTITEhJTUrLi4vFx8zOD8tNygtLi0BCgoKDg0OGxAQGi0iIB03Ky43LSs1Ny8tLS0vNjA3Ky0tNTUtMy41LSstLS0rLS0rMi0tLSstLS0vLS03Ky4tLf/AABEIAQMAwgMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABAcDBQYBAgj/xABIEAACAQIEAgUIBQcKBwAAAAAAAQIDEQQSITEFEwYiQVFxByMyYYGRsbJyc4KhwhQkNEKiweEVUlNUYmOSs8PRFjNEZHSDk//EABoBAQADAQEBAAAAAAAAAAAAAAABAwUEAgb/xAAvEQEAAgECAgYJBQAAAAAAAAAAAQIDBBEhMxIiMkFR8AUTMWFxgZGhsRQVI1Lx/9oADAMBAAIRAxEAPwC8QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPJSS3dvE9NNzXOcm326LuXcBuIyT2dz0i0e8kpgegAAAAAAAAAAAAAAAAAAAAAAAAAAAAPJHPUH12dCznaHpshMNvT3JcdiHTJkdiUPQAAAAAAAAAAAAAAAAAAAAAAAAAAAPJbPwAj1cbTV+ur22uarD5Lt5lvpqisPKJUyVMPNaOOIxLT7rViHwnF8/iuGlLrWnQSza6KS7yErtp1YW9KP8AiR7PiNGDUZVYJvZZlcqXpxBU+MKpFJXhFaJLanHu8TYKtzZqb1vUXxJQtOnNSV07o+iNw5ebRJAAAAAAAAAAAAAAAAAAAAAAAAAHktn4Hp5LZ+AFHeVJ2VJ/9xi/81nPdBsRfiOF+upL9s6Pyorq0/8AycV88mcb0Iq24hhZd1ek/wBtEDvPKdLLxKD/ALP+nEk8AeaEX/efvNR5WcQv5S0e0KevjFG06IPNRi/72XzEi2MB6CJBHwXoIkAAAAAAAAAAAAAAAAAAAAAAAAAAfM5qKcm7JJtt7JLdlddJenFSUpUsMnCmtHVs8816v5vxPF7xWOKrNmrijeyB5Tq8I1+oq1RKK5kKM21zNdcr6t0rdxX8cRBzXUxUXl0XKpZr339HY3rx7k7Ne2ehDxde0qbja/X7mrWOPp2meLDy6y1rzt+UTiGKhdzX5XL0evKlRXd3xRLwGPlJxUI4yC1eZtUYK2v6lr3McMS2nmeinDay0zE9Yl7pJ79qbFrTs8/qrd/5XbwZ0+RS5XoZFbrOTv23bu2733JpTHA+kuIw8s1Nys31qU4twl7OzxRanAeNQxdPPFZZK2eD3i/3o6ceWLcJ9ra0+orlj3tmAC50gAAAAAAAAAAAAAAAAAAAADnunGLdPCtL9eWV/Rs2/gl7StakYpvJJyjp1mrNuyvp2a3O/wDKK/MQ+m/lK/ZnaqevsxPSE75dvBJo4SMoSlzEpJN5Xs7evsNXP/mw9UJfFElkdrzsfoS+KKas+0xO20GLjeEvC5vOD8IVeEputGnZ2UWszem71VkabFLqS+i/gZaT0XgN+HExzEW60bpGIo5JShdSytq62frN30QxSpYqlCMm1UhaaataTusvrs1F39Zz+dJpNq72Tau/BGw6Ou2Mw/04r9tDFO14dmnnbJEwtsAGu3wAAAAAAAAAAAAAAAAAAAAByHlHfmqS/tT+CK8liVmULO9t+rb3XuWB5SH5uj41PwnDSRmanmSwdfzp+TfKWGyWlys0qcYxeWCy3oRSbdvSU3Jt76x12I1sMvybNyVOlFyq3yPmebqNRvC7ms0IJ7+lG25q3iZ/zuy2y2tFfCEfcR6uIm5pOTtKM01pZ3mpvTxSYi/uUTnjwb2nDDJPO6bjBVKds1N8xRrRarZtbXi2ut2J20vbLiHRV3SWHlai3FN4fK5LELMrLVvl30e627TRVsVO0pZtetK9l6XVd/2I+4+4YqbjZy31ei3cXF/dKXvIm8dEjNHs2fHKTak91tq7e1du7NhwR2xeG+sj88SHAk8If53hvrF80SrHPXhZg7cLgABsvoQAAAAAAAAAAAAAAAAAAAABxnlIfUo/+z8Jw7eiO38pPoUft/hOIkZep5jB13On5MmChFycp2ywi21LNaUtoxeXWzbV7diZ5jMC04OnCVRZ6r5kYykuU6cJU81tnrK+2t+4y8Lo8x1KOVOdSlLlaJyVWFppJ9l1GUfXmJmNVCMJygqUcuMq0Kcnh6dWVSMMPFJKTXUbacsy7ZMVjhu56Ui1fPnwRMZhoqNfqWpKlUdOveXWaj1He+VuTsnFbXe1mffFcOqc3GNOUIKpOMW6coJxT0tJyebTt0NhxDAwlRywhTdSdPA04cumozpVK1NNzqTVs0Zart1fYReOYWnHlzoxpxh5yj5mVOUW6c+rOTg2s0oSptp67k2rtWVl8e0Tw87tfEkcL/SsP9YvmiRWrppOzatfu9Zn4PBrEYZN3fM3d+9d5Tj7UJwduFyAA2X0IAAAAAAAAAAAAAAAAAAAAA4zykehR+3+E47DYOpVuqcczjHNLWKsu/U7LykehS+3+A5zgOPp0XU5mZKcFFOCzNNST713GbniJy8WLqa1tqJi07RwZI8GmrSVCvFqSeaCk9L9jTetre88eBq04yUKWOjdSsqdPFRUqjSUc8Vo1pK/iu43MOkOFUszqNrmZ3CdKaTdpx1aT1UXTX2Pdlo9JsC6dWnzlJyqynpCqt6jmlJqGlu55r7PQsitPFMY8HdePs5+GCrK75ONT1hdUsQpKnFLI1l7VppssiMsOCvLkjhsXZLqqUJqKlor2fqRt1x3CtSUq8OtCinKNGto4OGZKLp7dV9tttD18eweVU+ddKFm+VW1lyZ0/Ratbr39Ww6FNttyMeH+0fZzWN4ZWopznSlTg5uMXLv1aj37L7jFwz9Jw/1i+KN1x7i1CpQVGlKc3+UKq5Sg4q3KcXv23NNwv9Jw/wBYvjE59qxkjZ4rWtcsRWd4XAADWbgAAAAAAAAAAAAAAAAAAAAA47yjrzdL7f4Tga9aMXGLveW1k3tbe22695YPlFXmqf2/wnDNUrLPCUpJ3i1OMbexxepm6nmcWHro/mn5MCi3olf1LUxwoZdk1fx+4n0q1GLzLmxav/RTWqs97G1fN6rzVd7pcrDu7k3F3Wdb6o8Vjdx1xRPe5/I+5+5hKxv3CrHNNur6CbfJw+kd1pzNNyDjKtKUrVJVXKF4O1OjHZvTSTW9xamyZxdHv+qFElcKX51hvrF80THN09Mkaj9cqkFb7Ki7+9Gbg36XhvrI/NErxx14X4I68LeABsvoAAAAAAAAAAAAAAAAAAAAAByflDXmYeM/gv8AY4GfYWB5QV5iH0pfKV/LYzNVzGJr+bPwh7hcRkbeSE/VNXRlljo6eZp6Si9rXs02tO+33shXT2s0/amCuJln9OY4Qm0cbGMUuTFtK2Zu8n3Zm937v3nxXxin1eTCGzzx3k9br7/uIwQm0yn1lpZle2lvb3E/gKvi8N9ZH54kGBsOjy/PMN9NfMjzi7cOvT9uFsgA2W+AAAAAAAAAAAAAAAAAAD5ckY54mK3ZmsfLpp9iA5PptVjXw7hTqKNRO8cy0ejW/tKoxEsdFqOVS78jg0y/54Sm94RfsRgnwjDy3o034xRVfFFp3c+XTUycZfn+VfFx05U/ZCy+B8Sx+JW8Knshf9xfkujuDf8A01L/AAo+f+G8H/V4e48eo+H0ck+ja+f9UL/KOIf6lT/5/wADJDFYpuyhV9tP+Bey6N4P+gh7j6XR7B/1en7Yj1HwP22vio91sWrJRm/sJL3tI6voThqvPhWxDUYw11cXJvsSS9ZZUODYaO1CmvCKM8MFTW0IrwSJrgrE7r8Ojrjnffcp4uEtmZlNM8VKK7EfSRe7HoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/9k=",
    rating: 4.5,
    stock: 80,
  },
  {
    id: "48",
    name: "Electric Toothbrush",
    description: "Rechargeable electric toothbrush with timer.",
    price: 59.99,
    category: "Beauty",
    image:
      "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw8PDxANDQ0PDQ0NEA8NDQ4NDQ8NDQ0NFRUWFhURFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMsNygwLysBCgoKDg0OGBAPFS0dFR0rLSstLS0rLSstLS0rKystLS0rLS0rKy0tKy0tLSstLSsrLS0rKy0rKysrLS0tKy0rK//AABEIAPsAyQMBEQACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAABgQFAQIDCAf/xABJEAACAQEEBAkHCQUHBQAAAAAAAQIDBAURMRIhcYEGBxMyMzRBUXIiJGGRsbKzFiNzdJKTocHSUmOiwvAUNUJDU4PRZJSjpOH/xAAaAQACAwEBAAAAAAAAAAAAAAAAAQIEBQMG/8QAMBEBAAECBAQFAwQCAwAAAAAAAAECAwQRMTMFMkFxEhQhYYEiNFETI0KxkfAVUsH/2gAMAwEAAhEDEQA/AEY33nAMACAEAAAAAAAAwBsCDDA2kxHCPUIS60p/BvrdLZV+FMUFe25Pld6okoUK+ikvDn+olDlXzLHgt0u4jd5XXDbh4o8x7ys0eklK9O3ay3RoyL7jdmb2BXoMO2q9oSlR1UFXnPaNzNNw9Gjhc1XcNyJF49gUJXlVidFTMjnRcABkCAAAAAAAAGAAA8wxSGrA2kiMpQj1CMutKfwc61S2VfhTFCN7kk913qRKFGvopLdz2Shwr5lnwW6XcQu8rthtw70uY95WaXSSneiz2suUaMm+j3dm9gVlh9GarzCTo6qKpzt43M13F0aONzVew3I73gKg76pwOimSDougAAAAAAAAAAAAAAMMRwwwNpIjKUI9QjLrSn8HOtU9lX4UwhG9ySeK+SHChXpCltvOZKNHGrmWvBbpdxC7yu2F3JO9LmPeV2l0kp3p27y3SybyLYM2FRWI9BWyYxT1Uk+cCEaGu4V82jhc1X8NH0Q73gFsX1UdFMjnRdAAAAAAAABgAGAwMBAAGANhiOGkhSlCPUIS6wn8HetU9lX4UwhC9tydqz1IcKFekKa185k4cZ1W/BbpXsIXeV3wu5J2p8x7ytGrRnQp3n27WW6dGTeRLE9b2BUdnQWh6mBflSyzGh0Nlx9FHYV7mrRw3JDteA6CvKs6KmRHOi2AIAAAABkABgAGBAYAaZd90Wi0OKoUKk1KXJ8potUYyzwlUfkx1d7IVV006p0W6qtIbX1ctexyjC0RS003TnCcalOaWp4Si8NWrFelCou016OlyzVby8XVVyJShDhUIS6wncHutU9lb4UwhC9t1HWrkiUM+vSFNaecyTj1XHBXpXsIXeVYwu5J2p8x7yt1aU6FS9O3ay3ToyL6FZO0KhZ0YtD1MBPVTvMbn0Ntxr5qOwr3NWlh+SHW8UOgr6qOioSDotgCAAAAMMgAAYEAAZAPpPF/SVOhGei5aUKlVONPCSk2489NvDCGGCSK12nP1z65LNqvwzEZZ+maDw2fKWKTcXF0bZT0NJNPRnSlpLWk8MUnuOduPDemPzC1dnxYfOekvn0i2oQj1CMutKdwe6zT2VvhTCEL23Uc6r8lbCVOrNuT6KivmyTlC54K9K9hzu8qzhdyex1hzHvK3VpToVLz7drLdLJvoNkeYVI2Z9GtqepjKZ1VLzGXQ33F0UdhWuczTw23DpeWY6EL6qOioRzotsjAAAAAAAMgGGIAYAgbOBN+0bM40qinGpVrKmqsYwdOFGpoxenrxaT8rLsOF6iZiZWbFcRMQsOMvGjGFlclNzrzqzlFaKXJxUYxw/3H6ivhfrrmtcxsfp26aPl8+kXWbCPUFLrSm8H+s09lb4UxQjf26jjWfkk6dWXdn0VNbMlKFK74K9K9hyu8qzhdyex0hzHvK3VpdJKd6du8t0si+gWXNkqkLLW1vUBTKreYH0OFw9FHYVrnM0sNyQ6XjmiVtDEKk6qeZIJrrIAAAAAAAAAAAAAAYxw192sUnE+p341usU33ytPvQM/AaVNTiX8OxDkX2bDhURGXWEy4Os09lb4UxQhf26jfVfknSlk3Z0VdXMcild8Fulew5XeVZwu5PY5x5j3lfq0uhVvPt3lqlk34V1nzJS5W3O1sk55+qu7ROvQ4XF0UdhWuatHDT+3De8s0StueIVJ0U8yUTXwAAAAABAAAMAAAAAKOOrv1CnQ6fWYg9cbEfnaX0lrXqdIz8BpU1OJfwIEjQZsOFQhLpSmXD1mnsrfCmEaoX9ursbanNOlLIudFZVzA6dF3wW6R7Dnd5VnC7knOPMe8rdWl0Kt5du8s0su8raGbJy40OdqJOXVA7ROvQ33H0cdhXuar+Hn6Ib3lmSoQxCpOmSnmSiTRZAACAAAAAAAAAAABLuijylps9PPlK9Gn9qcV+ZC5OVEz7OlqM66Y9ztxqU8VGp+zaq8PtJP+Qz8BPrVDW4lH0Uy+cyNJkQ4TIy6QmXCvOIeGt8KYo1Qv7dXY11MjrSyLnRXVVrElTou+C3SPYc73KsYXck4x5j3lfq0ukla8+3eWaWXeVtF6ycuNEudpJOfVCWZF06G65ejjsONeq/h+SG15Z7h0aIX1RgdFMmDaQAgAAAAAAAwAAAAQMfF5ZeVvSyRwxUJyrS9HJwlNP7Sj6yvipytStYOnxXoNXGFS07FVn/pWqnUeySlD2zRQwU5XO8NXiNOdrP8AEvl0kazDhwmiMukJlw9Zh4a3wphCF/aq7GmeR1hjV9ECpmJOld8F1849hzu8qxhdyTlSpuUGopt68liVZqiJ9ZatNFVUT4YzUNvuu0SyoVHsi2dovW/+yldwd+dKJVqui0xxbs1bD6OT9hL9a3P8ocPJYiIzm3KutS1tPU1qfoZ26KeUxOUoaWsHSdDdcq+bjsOFeq9h+SGbxz3Do0Qvqo6KhKG0QAABkAwBMjAAAAAAAzrxZ3Xap1K9rstSlSdCnyTlWg5xk6ibwXc1op78O0p4u5RERTVGebQwFqqqqaonJbVbkvO0UbRQq2yy1I1MG4ws0oSlKPlKKblqxaWsqW7tqmqJimY+Wnfs13KJp8T5hJPtWD7U9TT7jVee0caiIy6Ql3D1iHhrfCmEOeI2qjPLI7Qxqp9UKpmJ1jQxcDKHKWhU8tLVuOGIq8NGa5w+jx3/AAvo14KFBKnBYYJGLVMzOcvX0UxTGUQqZ22QJtYXhJNPU8O/WgCr4Z2WlWs/9rhFQq03FVEv8cG1HXsbX4l3B3ZirwTpLF4vhaarf6sR9Uf0Q45mm83OhuuXo47DhXqv4fkhm8c9w6NEL6qOioSRtEAGQIDAAAAAAAMgAAfaOLWx8jdHKYYStM6tZ+vk4/hBPeY2Mqzuz7N7AUeG1Hu62atozb7G8GVmg+UcM7IqNvtMIryZT5aOyolP2ya3G3Yq8VuJecxVHgu1QX5o6S5QmXF1mHhrfCmEOeI2qjM8jrDGlCnmJ1g2cXdKTtUZJYqHlTeK1J6va0VMZOVtp8Jpmb8zHQ78IOk3IyHq4UVQZuTAOd89Rr/7fxIljC7sM/if2tf+9SFDM2XkJ0N1y9HHYV7mrQw/JDN4Zjo0Qv6qvA6KpHG0GQIDAAAAyAAAAQAAA9AXPS5O6rLDustDHa4Jv8WYN6c7lU+70+HjKimPZSp63tILBA4yY4W2D/astCT24zX8prYPb+WFxGMr3wT6hYlTpS7hXnMPDW+FMI1QxG1UZnkdmJ1Q5ZkXeDZxeTatUUm0papJPVJLXgyrjIibbS4TVMX8vydeEHSbkY71kKKoM3NgHK+35jX20/iRLGE3YZ3FPtavj+yJDM2XkJN9zL5uOwr16tLD7cMW/PcSo0cr2qswJq5HGvAYABkAAIAAAZAAAAD0JZ/7vs/1eh8OJ5+5zS9Ta5Y7F9du0UOxD4yet0vqtL36pq4Pb+WFxHd+CdURalTpTLi6zDw1vhzFGsIYjaqMjyOzERJ5idoNXF8vO4f12Mq4zbaPCfuDrwg6TcjGeuhRzGbmwDhfvUa22l78SzhN2GdxX7Wr4/sjwzNh5CdDfdHRx2FevVo4fbhrb89xKjRzvaqwmrkca8BhkAAIAAAABkAAAGHoWivMLP8AQUPhxPPV80vVWuWOxeXbtFDqQ+MjrdL6rS9+qauC2/lhcR3fgoTLUqUJdw9Zj4K3w5CjWEMRtVGR5HdidUSWZF2jQ18Xq87jsfsKuM2pafCN858IOk3IxnrYUdQZubAOF/dRq+Kn78S1hN2Gbxb7Wr4/skQzNeHkZ0Nt09HHYivXq0bHJDFuzewlRo53tVaScCOSXQMACAAAAAZAAAAAYAz8Ib1ttG1RdKrUU4Qs0KNNSk4yjyVPRp6GTUscu1vvONu1bqsxnH5zXartyMR6TPQ+x7cVg8dazwZizq9DGhE4yF53S+qUvfqmrguT5YXEt6OxQmWpUqUq4usx8NX4chRrCN/aqMjyOzE6orzIu0Gzi9XncdjKmN22nwff+Dhf/SPcZD1sKSoBuQw4391Gr4qfvos4PdhmcW+1nvBJhma8PIzobLq6OOxFevVpWOSGttzZKjRzvaq4k4kckuAZAAADIAAAAAAAAwD0B/Z6Ts1nqOnTdeNnpKNR04uqoaCxSlhilr/Ewaqqs5jP0eot00zlOXqpO17SDuReMhedUfqlP36prYLb+WDxLejt/wCyT5lqVKEq4esR8FX4chRrCOI2qjHI7QxZRXmJ0g28XvWo7GU8ZttXg+/8G+/uke4yHrIUlQDcRhxv/qNTx0/eRZwm7DM4v9rPeCVDM2HkJ0Nl2cyOxFavVpWZ+iGlszewlTohd1V5JXI5NdZAAAAAAAAAAAAABh6Ca+YofVqfsgefnr3ept6R2UXa9pF2I3GT1mh9Vh79Q1sFyT3YPEt2OxNmWpUYS7g6xHwVfckRjWCv7VRjmd2NOqK8xJwbuL3rUdj9hTxu21eDb/wbb96RmQ9YpagG4jDjwg6lPx0/aWsHusvjH2094JcMzXeRnQ03c/JWxFevVo2eWGtrzY6ULuqvJuBJJLoAACZAwBMAYAAAAIAb0I6Xm9CeGpWanHHVjlF4fh+BgVTq9TbjRQ9r2kXYjcZPWLP9Wj78zVwXJPdhcT3I7EyZalRhLuDrMfBV9yQo1gr+1UZKh2hjVaorzEkbeLxedR8MvYVMbttbg2+bL9fzjMh6tSzA3JjDjwi6lL6Sn7WWsHusvjH2094JdPM13kZ0NF381bEcK9WhZ5WtqetjpQuaq/Em4Eoa8yBAAABo4t7up2i8aarRU6dGFS0SjJaUZaKwjivRKUXuK2Lrmm36az6LuBoiu769PVUX3bo1pVLW4RjGc3oKnSVKMYOT0McMFLBNLHt7y5Ys002olxv513piPT27K0i4gQAAAHop9Uo/RUvcR56rWXq7ekFt5vaDoRuMnp7P9WXvzNTBck92HxLcjsS5luVCEzg/1mPgq+4xRrBXtqoyVTtDGr5kR5glBv4u+tLwyKWN22twbe+DVfnSMyHq1PNDNpgMIvCR+Z7asPZItYPc+GVxj7b5gmQzNd5KTPYH5K2HCrVoWuVrau0dKFxAJOBKJLzIEAAAzdxXVlG8HBvB1rNXpR8Xkz9kGVMbEzbz/Er/AA6Y/VynrBat1kcKbs1VYTp6ClGU03gsGsMHlhg95pW7lNVr0lUr8VvET7ZouJwcwBsAQEb0RKov7NShrx5ClL0YaKRgVR193qLdX8fYvvN7ROpF4y+ns/1de/I08FyyxeJbkdiVNlyVCEzg/wBZj4anusjGsFf2pMlU7QxatUWWYJm/i660vBL8injdtrcG3vg1X2/nGZL1SomBtZL2gEHhP1NfTQ9ki5gtz4ZPGft/mCdTzNZ5OdDNYX5K2HCrVoW+VraXmOlC5qg4knEk4kl0YgBiBjEAY+Lv+86Hojan/wCvVKuM2pW8BH79Kv4T9ctC7qjXqSROxt0oYveq7qvE7K7GIAYgYbz2AHoupFchT1a+RprHtwwRg1de70tvm+Ctb60oYOOGueEsc9DBt4a8/XsY6KYnPN1rmY0J3Gc/nrN9A1/EzQwXLLI4lzwR5stSoRCbwdfnMfBU91ijUr+1JkrP2HeGNVqhuWsScQb+LmXna8EvyKmM22rwff8Ag2Xz0jMh6lUzGbWW/wDD0gEDhU8LHH01o+7IuYLc+GRxnYjuTab1mq8rVHoZbC/JWw41L1vlFo7RwhcQCTiR+UDNpeEaYZjwsaYsx4WNMMx4TXxY+VeMH+zRtMv/ABSX5lXGT+2u4Cn96FXwuejbrSv3mPrin+Z0sT+3S54qn96rup9M7Zq/hGmGY8I5QMx4WHU1PYxZn4XpStHzem+3k4L+FGFVL0lFPX2J17p/NvXgq8HLByWrWtbSwS78dXrO1nr2F2NO5P40pYVbN9FP3kW8JP0yzeIRnVBEnULUypRSncHJ+cx8FT3WKmfqc8TH7UmK0VCxmx8s5QXVI5u0UHXixjKVqc0sYQg1OWKwi5c1b9GXqKmMqjwZdZafCKKv1pmI9Ig3Xw/nGZT0yrkMNZfntAKvhlPCx0/TXiv4JlzB889mTxjZjuSqVXWacS81VR6GW7q6cVsIS7W5+l2ryzCEa0HEk5KX5BXh/wBP99L9JT8zQ9H5Spj5BXh+4++l+kPM0DylQ+QV4fuPvZfpDzNA8nUPkFeH7j72f6Q8zQPKVGji64K2qyWypXr8loKyV4rQnKUtOTglqaXZiV8ReprpyhZwtibdecqvhVwQtdotlWvR5Lk6nJuOnUlGWKpxi9Si+1M6Wr9NNERKOIw1VVyZhU/IO399D72f6SfmaXHylQ+Qdv76H3s/0h5mkeUqHyDt/fQ+8n+gPM0jylTEuAluweuz5P8AzJ/oDzNIjCVZvvVrWFGC7oRXqSM2WtToSr4imo45qopQ8rRxmk8Fl5Tf7OrHvR1tTlMlcjPJRcYHB6vbJWaVB01oU5qfKSlHFtrDDCL7jrYuRRE5quJtTXMZFF8ALc/8dm+8qfoO3mKXCMPUm3NwEt1Ospudmw0ZrVUq464tfsDpxFMS5YjC1V25pjquZcDrW/8AHQ+3U/QdfN0e6hHC7sdY/wB+HB8BbZ/qWf7dT9BGcVQ6xw+57GngDwftVktDlUq03RnB6cKcptymsdB64rLGXrOF+9RXT7rmBw1y1cmZn6ZXt7dIym11ZIA0l+eGSXsAI9/3RO2WaFKnKMJRqqo3LHDBRmsNXiR3sXIomZUsdZm7RFMfku0+AlpT6al6p/8ABbjFR+GVPD6p6rGzcELTH/Pp/ZkOcVT+HL/i640qSfk1aO2tT+zIfmqfwJ4Zcn+cf4c/kxX/ANan9mQebp/CP/FV/wDeP8GPEzXohihBnFDDIBYXXDya0u6no+t//CEpU6q+UcvUODr1aOJJBq8BhgAxOjNryabfpyQ/QZSZLZaIyprBTxwWrk5v2LA5TDtBamp4tqnUz7KVT/gZtLVTqSUMKctUcGn5L9ROlyrj1R2pR1NNP0jmEHSz1HpbmKCq0SnXa7CSGbCtYZDNMsNt0ZKWGK7dgpjM6aspF5xxelF4p6zmtROarmgNpotgFlZ3oxwZOIcK6s5dFVQ3N1jUQE1nUGTTTFkHHRIZu40AzA0EGYHJx7vxDMJ130ouNSOMo6k9U2sUUcVhIvzFXjqpmPxMx/TvaueDpmi2mxU1hrm28c6kgwuFizM1eKapn09ZmUr97xxEZRDnGhBd++TZezVm6pR/phmMnSlTipRfdJP8QzPIx1KMf2Vu1EM04VdqtGhjgtW0WaStq3pLJRX4jNrTtjlnFe38x5llDerhJLHDMcShVEMUaUMezJjzQqj0d+Th3IlmhlDV0afcheKTyh1s9ng3gl6hTVJxTEutpslOS0ZJ7pyi/WmQmZdojJWzuGzvPlv+7tK/nFmbehclng8VGb8detU96TDOSlInQiuzVtOkS5VUxDVUo9xLNDJIjTj3BmWTEqa7gzLJpya7h5jJF0Tm7DRADRADQAJV3LCUl3wl+T/IjJ0uVri9JehAKtXDkmSLJq6Uh5hhUpduIZjJdRttSMI6dOU8FnDByw9Kf5HOXSFXa7zpvNVY+KzV1+OjgCSpq22ljqdR7KFZ+yIZhmz2tz6KhXl2YyoVKCX3ij+AyTKtOerSWDw7NaJRMIS1oUp6XaNCrRLVKQ0WVSYGmWGD0tzI1aJU6ulaOtkHSHPREYSAhVjqROEKnNIkg7RQBhjzRya4CPJwUSLoNEAzogGdEA72NeWtkl/CxScNa68p7vYAloMmUAbRWtbUI1w0RTcJgHFyAMAHG0rUtoylxpZjhCXYkiw0I0ixvXhvFJ0istbIptMAMYAGKuSJQhU5JEkHZRAmjQwxoizCPgRTCQGzgAAB2svPjtCRDWtzmBtQIAAASoW2SWEkpenJiyOEicdWIknB/wBagDSpPR7McQJwnNvP1IZMUswgp0diSLUAkWTPcKdDp1Zq5si6NADAAVMkOEKnNEkXVATWQwwLMIwkwgDIDIAHWzc+O0UnDFXNjiBLTAABDIAMmQC0lzVsQkkSTAOVozWwZS4sCbU89wQJ0dSSDURpFkz3CnQ41Zq5sSbQAADFXJbxwjLmhoOyGGsgDUQRhJBAbIBkA62Tnx3+xgGk1ntftJRyk1IpAAAAALSXNWxCNEqfmAc7TmhlLiwJtTz3AJ0dRogA7WXMU6HGrNXNiTaAAAYqZLeOEamiGi6oCayGGhEP/9k=",
    rating: 4.7,
    stock: 90,
  },
  {
    id: "49",
    name: "Nail Polish Set",
    description: "Set of 10 different colors nail polish.",
    price: 24.99,
    category: "Beauty",
    image:
      "https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.3,
    stock: 110,
  },
  {
    id: "50",
    name: "Hair Straightener",
    description: "Ceramic hair straightener with temperature control.",
    price: 69.99,
    category: "Beauty",
    image:
      "https://images.unsplash.com/photo-1522338140262-f46f5913618a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80",
    rating: 4.4,
    stock: 60,
  },
];

// Featured Products (8-10 products select करें)
export const FEATURED_PRODUCTS: Product[] = [
  SAMPLE_PRODUCTS[0], // Laptop
  SAMPLE_PRODUCTS[1], // Headphones
  SAMPLE_PRODUCTS[7], // Running Shoes
  SAMPLE_PRODUCTS[11], // Coffee Maker
  SAMPLE_PRODUCTS[16], // Perfume
  SAMPLE_PRODUCTS[21], // Dumbbell Set
  SAMPLE_PRODUCTS[25], // Bestseller Novel
  SAMPLE_PRODUCTS[31], // Gaming Console
  SAMPLE_PRODUCTS[37], // Wristwatch
];

// Sample Users
export const SAMPLE_USERS: User[] = [
  {
    id: "u1",
    name: "John Doe",
    email: "john@example.com",
    role: "user" as const,
    createdAt: new Date().toISOString(),
  },
  {
    id: "u2",
    name: "Jane Smith",
    email: "jane@example.com",
    role: "user" as const,
    createdAt: new Date().toISOString(),
  },
  {
    id: "u3",
    name: "Admin User",
    email: "admin@example.com",
    role: "admin" as const,
    createdAt: new Date().toISOString(),
  },
  {
    id: "u4",
    name: "Robert Johnson",
    email: "robert@example.com",
    role: "user" as const,
    createdAt: new Date().toISOString(),
  },
];

// Sample Orders
export const SAMPLE_ORDERS: Order[] = [
  {
    id: "ord-001",
    userId: "u1",
    items: [
      { productId: "1", quantity: 1, price: 1299.99 },
      { productId: "6", quantity: 2, price: 29.99 },
    ],
    totalAmount: 1359.97,
    status: "delivered",
    shippingAddress: "123 Main Street, New York, NY 10001",
    paymentMethod: "credit_card",
    createdAt: "2024-01-15T10:30:00.000Z",
  },
  {
    id: "ord-002",
    userId: "u2",
    items: [
      { productId: "2", quantity: 1, price: 299.99 },
      { productId: "8", quantity: 1, price: 89.99 },
    ],
    totalAmount: 389.98,
    status: "processing",
    shippingAddress: "456 Oak Avenue, Los Angeles, CA 90001",
    paymentMethod: "paypal",
    createdAt: "2024-01-20T14:45:00.000Z",
  },
  {
    id: "ord-003",
    userId: "u1",
    items: [
      { productId: "11", quantity: 1, price: 79.99 },
      { productId: "12", quantity: 1, price: 129.99 },
      { productId: "16", quantity: 1, price: 34.99 },
    ],
    totalAmount: 244.97,
    status: "shipped",
    shippingAddress: "123 Main Street, New York, NY 10001",
    paymentMethod: "credit_card",
    createdAt: "2024-01-25T09:15:00.000Z",
  },
  {
    id: "ord-004",
    userId: "u3",
    items: [
      { productId: "31", quantity: 1, price: 499.99 },
      { productId: "32", quantity: 1, price: 329.99 },
    ],
    totalAmount: 829.98,
    status: "pending",
    shippingAddress: "789 Pine Road, Chicago, IL 60601",
    paymentMethod: "credit_card",
    createdAt: "2024-01-28T16:20:00.000Z",
  },
];
